<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <meta name="keywords" content="Vortex Truckers privacy policy, trucking company data protection, freight shipping privacy, logistics data security, driver information policy">
    <meta name="description" content="Vortex Truckers LLC's Privacy Policy outlines how we protect client and driver data in our freight shipping and logistics operations. Read our compliance standards.">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.webp">
    <title>Vortex Truckers LLC | Privacy Policy </title>
    <link rel="canonical" href="https://vortextruckersco.com/privacy-policy" />
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon_logistics.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/sass/styles.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- Start header -->

        <?php include('header.php'); ?>

        <!-- end of header -->

        <!-- start wpo-page-title -->
        <section class="wpo-breadcumb-area">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>Internation Truckers</h2>
                            <h3>Privacy Policy</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end page-title -->

        <!--start of wpo-service-single-page -->
        <section class="wpo-service-single-page section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-12 order-lg-2">
                        <div class="service-single-wrap">
                            <div class="video-wrap">
                                <div class="video-content">
                                    <h2>Privacy Policy</h2>
                                    <p>At <strong>Vortex Truckers LLC</strong>, we are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy outlines how we collect, use, disclose, and safeguard your data when you engage with our services, visit our website, or interact with us. By using our services, you agree to the terms of this policy.</p>

                                    <h3>1. Who We Are</h3>
                                    <p>Vortex Truckers LLC is a logistics and freight transportation service provider based in the United States. We specialize in reliable trucking, dispatch, and freight solutions. Our registered office in <strong>15442 Ventura Blvd., Ste 201-1361, Sherman Oaks, California 91403 USA</strong>. Contact us at <strong>support@vortextruckersco.com</strong> or <strong> +1 909 639 4727 </strong>. For data protection purposes, we are the Data Controller of your information.</p>

                                    <h3>2. Information We Collect</h3>
                                    <ul>
                                        <li><strong>Personal Information:</strong> Name, email, phone, address.</li>
                                        <li><strong>Employment & Driver Data:</strong> CDL, experience, ID documents.</li>
                                        <li><strong>Service Data:</strong> Dispatch logs, freight details.</li>
                                        <li><strong>Financial Information:</strong> Bank details for payments.</li>
                                        <li><strong>Communication Data:</strong> Emails, call records.</li>
                                        <li><strong>Technical Data:</strong> IP address, browser, device info.</li>
                                    </ul>

                                    <h3>3. How We Use Your Information</h3>
                                    <ul>
                                        <li>To deliver freight and dispatch services.</li>
                                        <li>To process payments and verify identity.</li>
                                        <li>To respond to inquiries and send updates.</li>
                                        <li>To comply with legal regulations and protect from fraud.</li>
                                        <li>To improve our website and service offerings.</li>
                                    </ul>

                                    <h3>4. How We Share Your Information</h3>
                                    <ul>
                                        <li>With carriers and logistics partners.</li>
                                        <li>With secure third-party services like cloud storage and payroll.</li>
                                        <li>With legal authorities when required.</li>
                                        <li>During business transfers (e.g., mergers or acquisitions).</li>
                                    </ul>
                                    <p>We never sell or rent your personal data.</p>

                                    <h3>5. How We Protect Your Data</h3>
                                    <ul>
                                        <li>Encryption of sensitive data.</li>
                                        <li>Access control and employee training.</li>
                                        <li>Regular security audits and updates.</li>
                                    </ul>
                                    <p>While we strive for complete security, no system is 100% secure. If a high-risk data breach occurs, we will inform you and relevant authorities as required.</p>

                                    <h3>6. Data Retention</h3>
                                    <ul>
                                        <li><strong>Active clients:</strong> Data is stored during service and 6 years after.</li>
                                        <li><strong>Inactive clients:</strong> Data retained for up to 2 years.</li>
                                        <li><strong>Legal obligations:</strong> May extend retention beyond stated periods.</li>
                                    </ul>

                                    <h3>7. Your Rights</h3>
                                    <p>You have the right to access, correct, delete, or limit your data. You can also object to certain processing or request data portability. To exercise any of these rights, contact us at <strong>support@vortextruckersco.com</strong>.</p>

                                    <h3>8. Cookies and Website Tracking</h3>
                                    <p>We use cookies to enhance site functionality and collect analytics. You can manage your cookie preferences through your browser. Disabling cookies may affect some site features.</p>

                                    <h3>9. International Transfers</h3>
                                    <p>If data is transferred outside the U.S., we use legally approved safeguards such as standard contractual clauses to ensure your data is protected.</p>

                                    <h3>10. Third-Party Links</h3>
                                    <p>Our site may contain links to external websites. We are not responsible for their privacy policies. Please read their policies before submitting any data.</p>

                                    <h3>11. Marketing Communications</h3>
                                    <p>With your consent, we may send updates and service offers. You can opt out anytime via the unsubscribe link in emails or by contacting us directly.</p>

                                    <h3>12. Policy Updates</h3>
                                    <p>This Privacy Policy may be updated to reflect legal or operational changes. The latest version will always be available on our site with the last updated date.</p>

                                    <h3>13. Contact Us</h3>
                                    <p>If you have questions or want to exercise your rights, please contact us at:</p>
                                    <ul>
                                        <li><strong>Email:</strong> support@vortextruckersco.com</li>
                                        <li><strong>Phone:</strong> +1 909 639 4727</li>
                                    </ul>
                                    <p>You may also contact the appropriate data protection authority if you believe your data has been mishandled.</p>

                                    <h3>14. Our Commitment</h3>
                                    <p>At <strong>Vortex Truckers LLC</strong>, your trust matters. We handle your personal information with transparency, care, and the utmost respect to ensure it supports your experience with our trucking and logistics services.</p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--end of wpo-service-single-page -->

        <!-- start of wpo-get-touch-section -->
        <section class="wpo-get-touch-section-s2 section-padding pt-0">
            <div class="container">
                <div class="text-center ">
                    <h1>Fill Up The Form to Get Quote</h1>
                </div><br>
                <div class="row justify-content-center">

                    <div class="col-12">
                        <form method="post" action="contactaction">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-12">
                                    <input id="name" name="name" class="fild" type="text" placeholder="Your Name" required>
                                    <div id="nameError" class="error-message"></div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-12">
                                    <input id="email" name="email" class="fild" type="email" placeholder="Email Address" required>
                                    <div id="emailError" class="error-message"></div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-12">
                                    <input id="phone" name="phone" class="fild" type="text" placeholder="Your Number" required>
                                    <div id="phoneError" class="error-message"></div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-12">
                                    <input id="subject" name="subject" class="fild" type="text"
                                        placeholder="Enter your Subject" required>
                                    <div id="subjectError" class="error-message"></div>
                                </div>
                                <div class="col-12">
                                    <textarea id="message" name="message" class="fild fild-textarea"
                                        placeholder="Write Message" required></textarea>
                                    <div id="messageError" class="error-message"></div>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="theme-btn">Send Us Messages <i
                                            class="ti-angle-right"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-get-touch-section -->


        <!--start of wpo-map-section -->
        <section class="wpo-map-section">
            <h2 class="hidden">Contact map</h2>
            <div class="wpo-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3172.71877275444!2d-118.4702548!3d34.15424469999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c297ecb5c14b41%3A0xf3fee99834259df2!2sThe%20Rodin%20Building%2C%2015442%20Ventura%20Blvd%20201%201361%2C%20Sherman%20Oaks%2C%20CA%2091403%2C%20USA!5e1!3m2!1sen!2s!4v1744116245831!5m2!1sen!2s" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </section>
        <!--end of wpo-map-section -->

        <!-- start of wpo-site-footer-section -->

        <?php include('footer.php'); ?>

        <!-- end of wpo-site-footer-section -->



    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>


</html>