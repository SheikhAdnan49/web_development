<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.webp">
    <meta name="keywords" content="trucking services, freight shipping, LTL trucking, full truckload, refrigerated transport, flatbed shipping, logistics solutions, Vortex Truckers services">
    <meta name="description" content="Vortex Truckers LLC provides reliable freight shipping services - LTL, full truckload, refrigerated & flatbed transport. Get competitive rates and 24/7 tracking for your cargo.">
    <title>Vortex Truckers LLC | Services </title>
    <link rel="canonical" href="https://vortextruckersco.com/services" />
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon_logistics.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/sass/styles.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- Start header -->

        <?php include('header.php'); ?>

        <!-- end of header -->

        <!-- start wpo-page-title -->
        <section class="wpo-breadcumb-area">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>Internation Dispatching</h2>
                            <h3>Services</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end page-title -->

        <!-- start of wpo-service-section-s3 -->
        <section class="wpo-service-section-s3 section-padding">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-12">
                        <div class="wpo-section-title">
                            <h2>Vortex Truckers LLC</h2>
                            <h3>Transport & Logistics Services You Can Trust</h3>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="service-btn">
                            <a href="https://vortextruckersco.com/services" class="theme-btn">All Services</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="service-slider-s2">
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-1.svg" alt="Dry Van Dispatching Icon">
                    </div>
                    <div class="content">
                        <h2>Dry Van Dispatching</h2>
                        <p>Reliable dispatch solutions for dry vans, ensuring fast and efficient load handling across the U.S.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-2.svg" alt="Reefer Load Dispatch Icon">
                    </div>
                    <div class="content">
                        <h2>Reefer Load Dispatch</h2>
                        <p>Specialized in temperature-controlled freight with 24/7 monitoring for perishable goods delivery.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-3.svg" alt="Power Only Dispatch Icon">
                    </div>
                    <div class="content">
                        <h2>Power Only Dispatch</h2>
                        <p>Let us handle the trailers. We offer dispatch for power-only loads that get you moving fast and smart.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-4.svg" alt="Flatbed Dispatching Icon">
                    </div>
                    <div class="content">
                        <h2>Flatbed Dispatching</h2>
                        <p>Expert load matching for flatbed trailers, including oversized and heavy-haul cargo solutions.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-5.svg" alt="Billing & Documentation Icon">
                    </div>
                    <div class="content">
                        <h2>Billing & Documentation</h2>
                        <p>We handle invoicing, rate confirmations, BOLs, and broker setup—saving you time and money.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
            </div>
        </section>

        <!-- end of wpo-service-section-s3 -->

        <section class="wpo-service-single-page section-padding">
            <div class="container">
                <div class="row">


                    <div class="col-lg-12 col-12 order-lg-2">
                        <div class="service-single-wrap">
                            <div class="video-wrap">
                                <div class="video-content">
                                    <h2>What is Vortex Truckers LLC</h2>
                                    <p>Vortex Truckers LLC Is an independent dispatch house based in 15442 Ventura Blvd., Ste 201-1361, Sherman Oaks, California 91403 USA.</p>
                                    <p>A Dispatcher is the link between Broker & Carrier. Here is a list of things a
                                        dispatcher does for the client</p>
                                    <ul>
                                        <li>Load Information</li>
                                        <li>Negotiation</li>
                                        <li>Documentation</li>
                                        <li>Communication</li>
                                    </ul>

                                    <h3>What does Vortex Truckers LLC</h3>
                                    <p>We specialize in helping carriers to find the top paying freight loads
                                        for their trucks. Our dispatchers negotiate the highest rates and
                                        inform the carrier for options to make the final decision.</p>
                                    <p>We help our carriers move more freight safely and cost effectively
                                        every day! In addition, we bring a great deal more to the table than
                                        just dispatching. We work with Carrier, as their partner, to provide the
                                        tools they need to keep their trucks loaded and profitable.</p>
                                    <p>A dedicated dispatcher is assigned to every relationship, becoming
                                        a single point of contact. That dispatcher knows carrier's
                                        transportation business intimately and always looks out for carriers
                                        business's best interest</p>


                                    <h2>Types of Equipment we work with</h2>

                                    <ul>
                                        <li><strong>Power only: AKA</strong> Bob tail semi - Freightliner</li>
                                        <li><strong>Dry Van:</strong> 48ft - 53ft</li>
                                        <li><strong>Reefer:</strong> 48ft - 53ft</li>
                                        <li><strong>Flat Bed:</strong> 48ft - 53ft</li>
                                        <li><strong>Step Deck:</strong> 48ft - 53ft</li>
                                        <li><strong>Box Truck:</strong> 26ft - 28ft</li>
                                    </ul>



                                    <h3>Categories of Drivers</h3>
                                    <p>There are two types of Drivers Legal miles allowed in a day 600 miles or 11hr a day!:</p>
                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h4><i class="fas fa-satellite-dish"></i> 1 - Solo driver.</h4>
                                                <p>Miles in a day: 600 legal miles, 50-55 miles in an hour.</p>
                                            </div>
                                            <div class="col-md-6">
                                                <h4><i class="fas fa-robot"></i> 2- Team Driver.</h4>
                                                <p>Miles in a day 1,200 legal miles, 50-55 miles in an hour.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <h3>Things required from the driver</h3>

                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h4><i class="fas fa-satellite-dish"></i> 1- Copy Of CDL</h4>
                                                <p>Commercial Drivers License</p>
                                            </div>
                                            <div class="col-md-6">
                                                <h4><i class="fas fa-robot"></i>2- Truck & Trailer Number</h4>

                                            </div>
                                        </div>
                                    </div>
                                    <h3>ELD Device</h3>
                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">

                                                <p>An Electronic Logging Device is a piece of electronic hardware attached to a commercial
                                                    motor vehicle engine to record driving hours. The driving hours of commercial drivers are
                                                    typically regulated by a set of rules known as the hours of service in the United States.</p>
                                                <p>A driver has to take rest for a few hours to start driving again, in team drivers, the driver
                                                    switch with their CDL</p>
                                            </div>
                                            <div class="col-md-6">
                                                <img src="assets/images/service/eld-device.webp" alt="device" />

                                            </div>
                                        </div>
                                    </div>

                                    <h3> Power Only</h3>
                                    <p>Power only is the truck itself, Without any trailer attached to it.</p>
                                    <p>Two types of power only:</p>
                                    <ul>
                                        <li><strong>Day Cabs </strong> and <strong> Sleeper Cabs </strong> (Day Cab needs to pick up at loads in the morning and come back at home)</li>
                                        <li>Two load options, <strong> load out </strong> ( trailer for 5-7 days) & Tow Away (Hook & tow ) </li>
                                        <li>Any trailer can be attached to it, i.e. Dry van, Reefer, Step Deck & Flatbed.</li>
                                    </ul>



                                    <br>
                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h2> Dry Van</h2>
                                                <p>Dry Van can be 48 ft to 53 ft.</p>
                                                <ul>
                                                    <li>Swing Door DV or Roll Up Doors</li>
                                                    <li>Vented DV is very Rare.</li>
                                                    <li>Average $ per mile: $2 to $3 per mile</li>
                                                    <li>Weight: limit 45,000 lbs.</li>
                                                </ul>
                                                <p>Average weekly gross:</p>

                                                <ul>
                                                    <li><strong> Local: </strong> $7,000.</li>
                                                    <li><strong> All 48 states: </strong> $10,000 - $12,000.</li>
                                                </ul>
                                                <h4>Accessories:</h4>
                                                <ul>
                                                    <li>Strap for DV to hold floor-loaded Commodities.</li>
                                                    <li>E Tracks = used to Hold Commodities Two Types Vertical and Horizontal.</li>
                                                    <li>Dunnage.</li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <img src="assets/images/service/dry-van.webp" alt="dry van" />

                                            </div>
                                        </div>
                                    </div>


                                    <br>
                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="assets/images/service/reefer.webp" alt="reefer" />

                                            </div>
                                            <div class="col-md-6">
                                                <h2>Reefer Temperature Control</h2>
                                                <ul>
                                                    <li>Reefer can be 48ft to 53ft</li>
                                                    <li>Weight limit 45000 lbs.</li>
                                                    <li>Average $per mile: $2.5 to $3.5</li>
                                                </ul>
                                                <p>Average weekly gross:</p>

                                                <ul>
                                                    <li><strong> Local: </strong> $8,000 </li>
                                                    <li><strong> All 48 states: </strong> $13,000 - $14,000</li>
                                                </ul>
                                                <h4>Accessories: </h4>
                                                <ul>
                                                    <li>Strap - hold floor loaded Commodities</li>
                                                    <li>E Tracks - used to Hold Commodities Two Types Vertical & Horizontal </li>
                                                    <li>Dunnage.</li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                    <br>

                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h2>Flat Bed</h2>
                                                <ul>
                                                    <li>Flat beds 48 ft or 53 ft.</li>
                                                    <li>Max weight is 48000 lbs .</li>
                                                    <li>Average $ per mile $2.5 to $ 3.5 .</li>
                                                    <li>In north, Mountains areas max weight: 38000 lbs to 40000 lbs.</li>
                                                </ul>
                                                <p>Average weekly gross:</p>

                                                <ul>
                                                    <li><strong> Local: </strong> $6,000- $7,000 .</li>
                                                    <li><strong> All 48 states: </strong> $10,000 - $11,000 </li>
                                                </ul>
                                                <h4>Accessories:</h4>
                                                <ul>
                                                    <li>Straps.</li>
                                                    <li>Tarps.</li>
                                                    <li>Chain & Binder.</li>
                                                    <li> Dunnage.</li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <img src="assets/images/service/flat-bed.webp" alt="flat bed" />

                                            </div>
                                        </div>
                                    </div>

                                    <br>
                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="assets/images/service/step-deck.webp" alt="step deck" />
                                            </div>
                                            <div class="col-md-6">
                                                <h2>Step Deck</h2>
                                                <ul>
                                                    <li>Step Deck are 48ft - 53ft.</li>
                                                    <li>Max weight is 48000 lbs. </li>
                                                    <li>Average $ per mile: $2.5 - $ 3.5 .</li>

                                                </ul>
                                                <p>Average weekly gross:</p>

                                                <ul>
                                                    <li><strong> Local: </strong> $6,000- $7,000 .</li>
                                                    <li><strong> All 48 states: </strong> $10,000 - $11,000 .</li>
                                                </ul>
                                                <h4>Accessories:</h4>
                                                <ul>
                                                    <li>Straps.</li>
                                                    <li>Tarps.</li>
                                                    <li>Chain & Binder.</li>
                                                    <li> Dunnage.</li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>


                                    <br>
                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h2>Box Truck' 26ft</h2>
                                                <p>There are two kinds of Box trucks, also known as Straight
                                                    trucks. </p>
                                                <ul>
                                                    <li>Box Truck can range from 14ft to 28ft.</li>
                                                    <li><strong> Door types: </strong> Swing / Roll up .</li>
                                                    <li><strong> Weight limit: </strong> 10,000 lbs. .</li>
                                                    <li>Average $ per mile: $1.3 - 1.9 .</li>
                                                    <li>Good load is for $2.00 per mile</li>
                                                </ul>
                                                <p>Average weekly gross up to $5,000 - $5,500</p>


                                                <h4>Accessories:</h4>
                                                <ul>
                                                    <li>Pallet jack .</li>
                                                    <li>Lift gate.</li>
                                                </ul>
                                                <p><strong> Requirements in order to work with us </strong> Box Truck has to haul in all <strong> 48 states </strong> & has to be to <strong> 26ft - 28ft.</strong> </p>
                                            </div>

                                            <div class="col-md-6">
                                                <h4 class="text-center">Dry Box Truck</h4>
                                                <img src="assets/images/service/box-truck.webp" alt="box truck" />
                                            </div>
                                        </div>
                                    </div>

                                    <h2>Commodities</h2>
                                    <div class="tech-features">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h4> Dry Van</h4>
                                                <ul>
                                                    <li>Clothing</li>
                                                    <li>Furniture</li>
                                                    <li>Electronics</li>
                                                    <li>Household goods</li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <h4> Flat bed</h4>
                                                <ul>
                                                    <li>Building & Construction Materials</li>
                                                    <li>Backhoes & cranes</li>
                                                    <li>Logs</li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <h4> Step deck</h4>
                                                <ul>
                                                    <li>Building & Construction Materials</li>
                                                    <li>Backhoes & cranes</li>
                                                    <li>Logs</li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <h4> Reefer Van</h4>
                                                <ul>
                                                    <li>Meat</li>
                                                    <li>Medicines</li>
                                                    <li>Fresh fruits and vegetables</li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <h4> Box Truck</h4>
                                                <p>The best freight uses for a box truck include less-thantruckload (LTL) freight. Types of LTL </p>
                                                <ul>
                                                    <li>Parcel delivery</li>
                                                    <li>Furniture hauling</li>
                                                    <li>Food delivery</li>
                                                    <li>Households goods</li>
                                                    <li>Appliances</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>


                                    <h2>Types of hauls</h2>

                                    <ul>
                                        <li><strong> Short haul: </strong> Any trip within 600 miles.</li>
                                        <li><strong> Long Haul: </strong> Any trip over 1,200 miles.</li>
                                        <li><strong> Round Trip: </strong> A trip to a place and back usually over the same route.</li>
                                        <li><strong> Tri Haul: </strong> A trip with multiple pickups and drop off locations</li>
                                        <li><strong> Dedicated Lanes: </strong> running back & forth on the same route.
                                            i.e CA - TX - TX-CA</li>
                                    </ul>

                                    <h2>Payment</h2>
                                    <p>There are three payment methods:</p>

                                    <ul>
                                        <li><strong> Standard payment : </strong> Carrier gets paid in 30 days.</li>
                                        <li><strong> Quick pay From Broker via Voided check: </strong> Carrier gets paid by the broker in 48 - 72 hours by deducting 7- 9% from the total amount.</li>
                                        <li><strong> Factoring company Financial Institute via NOA: </strong> Carrier gets paid by the factoring company in 48 - 72 hours
                                            deducting 2 - 3% from the amount.</li>
                                    </ul>

                                    <h2>Our Services</h2>

                                    <ul>
                                        <li>Negotiating top paying rates (depends upon the market rate. The best rates we can get).</li>
                                        <li>Setup paperwork (agreement between broker and carrier).</li>
                                        <li>Fax, email, and documentation: provide docs, when the driver is not in reach.</li>
                                        <li> Credit checks grades (A , B , C) will be checked by MCN (Motor carrier number).</li>
                                        <li>Request quick pay.</li>
                                        <li>Requesting fuel advances.</li>
                                        <li>Request insurance certificates.</li>
                                        <li>Driver director assistance (No GPRS, no internet, send direction through call).</li>
                                        <li>Factor setup assistance.</li>
                                        <li>Collection assistance (Carrier wants bills handled i.e. POD, invoice, & rate con)</li>
                                        <li>Unused truck order assistance - <strong> TONU </strong> - (truck order not used).</li>
                                        <li>Layover charges assistance (e.g. if the truck goes to the PU and load starts after 6 hours).</li>
                                        <li>Lumper fee: charged to the carrier when a shipper utilizes third-party workers to help load or
                                            unload the trailer contents</li>
                                    </ul>
                                    <h2>Driver Friendly Load - DFL</h2>
                                    <p>These are the major factors that make up the best freight option for any
                                        carrier, a DFL includes the following.</p>
                                    <ul>
                                        <li>Maximum rate ( $ per mile).</li>
                                        <li>Minimum weight .</li>
                                        <li>Minimum Dead Head ( from origin and drop off ) .</li>
                                    </ul>



                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <!-- start of wpo-funfact-section-s2 -->
        <section class="wpo-funfact-section section-padding-1">
            <div class="container">
                <div class="titel-image">
                    <h1>Trucking</h1>
                    <h3>Dispatching solutions that exceed industry standards</h3>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="500"></span>+</h2>
                            <h3>Active trucks dispatched</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="15"></span>k+</h2>
                            <h3>Loads booked monthly</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="99"></span>%</h2>
                            <h3>On-time dispatch rate</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="24"></span>/7</h2>
                            <h3>Dispatch support</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- end of wpo-funfact-section-s2 -->

        <!-- start of wpo-service-section -->
        <section class="wpo-service-section section-padding">
            <div class="container">
                <div class="row align-items-end">
                    <div class="col-lg-7 col-12">
                        <div class="wpo-section-title">
                            <h2>Professional Dispatch Services</h2>
                            <h3>Truck Dispatching Solutions<br>That Keep You Moving</h3>
                        </div>
                    </div>
                    <div class="col-lg-5 col-12">
                        <div class="service-all-btn">
                            <a href="https://vortextruckersco.com/services" class="theme-btn">All Dispatch Services</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid g-0">
                <div class="service-slider owl-carousel">
                    <div class="service-card">
                        <img class="image" src="assets/images/service/1.webp" alt="24/7 Dispatch Operations">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>01</span>
                                <h2><a href="https://vortextruckersco.com/services-details/24-7-dispatch">24/7 Dispatch Support</a></h2>
                                <p>Round-the-clock dispatching services to keep your trucks moving and loads booked</p>
                                <a href="https://vortextruckersco.com/services-details/24-7-dispatch" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/2.webp" alt="Load Board Management">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>02</span>
                                <h2><a href="https://vortextruckersco.com/services-details/load-board">Load Board Management</a></h2>
                                <p>We actively monitor all major load boards to find you the most profitable freight</p>
                                <a href="https://vortextruckersco.com/services-details/load-board" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/3.webp" alt="Fleet Management Solutions">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>03</span>
                                <h2><a href="https://vortextruckersco.com/services-details/fleet-management">Fleet Management</a></h2>
                                <p>Comprehensive dispatch solutions for fleets of all sizes to maximize efficiency</p>
                                <a href="https://vortextruckersco.com/services-details/fleet-management" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/1.webp" alt="Owner-Operator Support">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>04</span>
                                <h2><a href="https://vortextruckersco.com/services-details/owner-operator">Owner-Operator Support</a></h2>
                                <p>Dedicated dispatch services tailored for independent truckers and small fleets</p>
                                <a href="https://vortextruckersco.com/services-details/owner-operator" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/2.webp" alt="Route Optimization">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>05</span>
                                <h2><a href="https://vortextruckersco.com/services-details/route-optimization">Route Optimization</a></h2>
                                <p>Smart routing solutions to minimize deadhead miles and maximize profits</p>
                                <a href="https://vortextruckersco.com/services-details/route-optimization" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/3.webp" alt="Paperwork Management">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>06</span>
                                <h2><a href="https://vortextruckersco.com/services-details/paperwork-management">Paperwork Management</a></h2>
                                <p>We handle all the documentation so you can focus on driving</p>
                                <a href="https://vortextruckersco.com/services-details/paperwork-management" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-service-section -->

        <!--start of wpo-cta-section -->
        <div class="wpo-cta-section">
            <div class="">
                <div class="cta-wrapr">
                    <div class="wpo-section-title">
                        <h2>Vortex Truckers LLC</h2>
                        <h3>Reliable Dispatch & Logistics Services Nationwide</h3>
                        <a href="https://vortextruckersco.com/contact" class="theme-btn">Contact Support</a>
                    </div>
                    <div class="contact-info">
                        <div class="item">
                            <div class="icon">
                                <i class="flaticon-phone-call"></i>
                            </div>
                            <div class="text">
                                <span>Call for Inquiry</span>
                                <a href="tel:+19096394727">
                                    <p>+1 909 639 4727</p>
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="icon">
                                <i class="flaticon-email"></i>
                            </div>
                            <div class="text">
                                <span>Send Us Email</span>
                                <a href="mailto:support@vortextruckersco.com">
                                    <p>support@vortextruckersco.com</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--end of wpo-cta-section -->

        <!-- start of wpo-features-section-s2 -->
        <section class="wpo-features-section-s2">
            <div class="top-wraper">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-12">
                            <div class="wpo-section-title">
                                <h2>Vortex Truckers LLC</h2>
                                <h3>Logistics Features We Provide</h3>
                            </div>
                        </div>
                        <div class="col-lg-6 col-12">
                            <div class="f-btn">
                                <a href="https://vortextruckersco.com/services" class="theme-btn">All Services</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-wraper">
                <div class="container">
                    <div class="bottom-content">
                        <div class="row">
                            <div class="col-lg-4 col-12">
                                <div class="item">
                                    <div class="icon">
                                        <i class="flaticon-distribution-center" aria-hidden="true"></i>
                                    </div>
                                    <div class="content">
                                        <h3>Dispatch Management</h3>
                                        <p>We handle all load bookings, rate negotiations, and paperwork for you.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12">
                                <div class="item">
                                    <div class="icon">
                                        <i class="flaticon-customer-support-1" aria-hidden="true"></i>
                                    </div>
                                    <div class="content">
                                        <h3>24/7 Support</h3>
                                        <p>Round-the-clock dispatch support to keep your trucks moving nationwide.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12">
                                <div class="item">
                                    <div class="icon">
                                        <i class="flaticon-delivery-box" aria-hidden="true"></i>
                                    </div>
                                    <div class="content">
                                        <h3>Cargo Insurance Assistance</h3>
                                        <p>We guide you through getting cargo insurance for safe, secure shipping.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- end of wpo-features-section-s2 -->



        <!--start of wpo-map-section -->
        <section class="wpo-map-section">
            <h2 class="hidden">Contact map</h2>
            <div class="wpo-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3172.71877275444!2d-118.4702548!3d34.15424469999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c297ecb5c14b41%3A0xf3fee99834259df2!2sThe%20Rodin%20Building%2C%2015442%20Ventura%20Blvd%20201%201361%2C%20Sherman%20Oaks%2C%20CA%2091403%2C%20USA!5e1!3m2!1sen!2s!4v1744116245831!5m2!1sen!2s" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </section>
        <!--end of wpo-map-section -->

        <!-- start of wpo-site-footer-section -->

        <?php include('footer.php'); ?>

        <!-- end of wpo-site-footer-section -->



    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>


</html>