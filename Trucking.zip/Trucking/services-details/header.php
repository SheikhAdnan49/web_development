<!-- start preloader -->
<div class="preloader">
    <div class="vertical-centered-box">
        <div class="content">
            <div class="loader-circle"></div>
            <div class="loader-line-mask">
                <div class="loader-line"></div>
            </div>
            <img src="../assets/images/preloader.webp" alt="preloader image">
        </div>
    </div>
</div>
<!-- end preloader -->
<header id="header">
    <div class="topbar">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-lg-5 col-12">
                    <ul class="contact-info">
                        <li><a href="mailto:support@vortextruckersco.com">
                            <i class="ti-email"></i><span>support@vortextruckersco.com</span></a>
                        </li>
                        <li>
                            <a href="tel:+19096394727 ">
                                <i class="flaticon-call"></i><span> +1 909 639 4727 </span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-7 col-12">
                            <div class="contact-into">
                                <div class="language-selector">
                                    <select id="languageSelect">
                                        <option value="en" data-icon="../assets/images/language/1.svg">English</option>
                                        <option value="sp" data-icon="../assets/images/language/2.svg">Spanish</option>
                                    </select>
                                    <div class="custom-select-wrapper">
                                        <div class="custom-select"></div>
                                        <div class="custom-arrow"><i class="flaticon-down"></i></div>
                                    </div>
                                    <div class="custom-options"></div>
                                </div>
                                <div class="pryment-selector">
                                    <select>
                                        <option value="usd">USD</option>
                                        <option value="aud">AUD</option>
                                    </select>
                                </div>
                                <ul class="social-media">
                                    <li><span>Follow Us :</span></li>
                                    <li><a href="#"><i class="flaticon-facebook-app-symbol"></i></a></li>
                                    <li><a href="#"><i class="flaticon-linkedin-big-logo"></i></a></li>
                                    <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    <li><a href="#"><i class="flaticon-vimeo"></i></a></li>
                                </ul>
                            </div>
                        </div>
            </div>
        </div>
    </div>
    <!-- end topbar -->
    <div class="wpo-site-header">
        <nav class="navigation navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-3 col-3 d-lg-none dl-block">
                        <div class="mobail-menu">
                            <button type="button" class="navbar-toggler open-btn">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar first-angle"></span>
                                <span class="icon-bar middle-angle"></span>
                                <span class="icon-bar last-angle"></span>
                            </button>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="https://vortextruckersco.com/"><img src="../assets/images/logo.webp"
                                    alt="logo"></a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-1 col-1">
                        <div id="navbar" class="collapse navbar-collapse navigation-holder">
                            <button class="menu-close"><i class="ti-close"></i></button>
                            <ul class="nav navbar-nav mb-2 mb-lg-0">
                                <li><a href="https://vortextruckersco.com/">Home</a></li>
                                <li><a href="https://vortextruckersco.com/about">About </a></li>
                                <li><a href="https://vortextruckersco.com/services">services </a></li>
                                <li><a href="https://vortextruckersco.com/privacy-policy">Privacy Policy </a></li>
                                <li><a href="https://vortextruckersco.com/contact">Contact</a></li>
                            </ul>
                        </div>
                        <!-- end of nav-collapse -->
                    </div>
                    <div class="col-lg-3 col-md-2 col-2">
                        <div class="header-right">
                            <a href="tel:+19096394727 " class="call">
                                <div class="icon">
                                    <img src="../assets/images/call.svg" alt="call image">
                                </div>
                                <div class="text">
                                    
                                    <h4>+1 909 639 4727 </h4>
                                </div>
                            </a>
                            <div class="header-search-form-wrapper">
                                <div class="cart-search-contact">
                                    <button class="search-toggle-btn"><i
                                            class="fi flaticon-search"></i></button>
                                    <div class="header-search-form">
                                        <form>
                                            <div>
                                                <input type="text" class="form-control"
                                                    placeholder="Search here...">
                                                <button type="submit"><i
                                                        class="fi flaticon-search"></i></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="close-form">
                                <a class="theme-btn" href="https://vortextruckersco.com/contact">Get an quate <i
                                        class="flaticon-next"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end of container -->
        </nav>
    </div>
</header>