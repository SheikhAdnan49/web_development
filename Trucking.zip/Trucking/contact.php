<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.webp">
    <meta name="keywords" content="Vortex Truckers contact, freight shipping quote, trucking company phone number, logistics support, dispatch contact, trucking services near me">
    <meta name="description" content="Contact Vortex Truckers LLC for reliable freight shipping & logistics solutions. Call, email, or request a quote today for fast, professional trucking services.">
    <title>Vortex Truckers LLC | Contact Us </title>
    <link rel="canonical" href="https://vortextruckersco.com/contact" />
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon_logistics.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/sass/styles.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- Start header -->

        <?php include('header.php'); ?>

        <!-- end of header -->

        <!-- start wpo-page-title -->
        <section class="wpo-breadcumb-area">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>Internation Trucking</h2>
                            <h3>Contact Us</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end page-title -->

        <!--start of wpo-contact-page -->
        <section class="wpo-contact-page section-padding">
            <div class="container">
                <div class="office-info">
                    <div class="row">
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="office-info-item">
                                <div class="office-info-icon">
                                    <div class="icon">
                                        <i class="fi flaticon-location-1"></i>
                                    </div>
                                </div>
                                <div class="office-info-text">
                                    <h2>address line</h2>
                                    <p>15442 Ventura Blvd., Ste 201-1361,<br>
                                        Sherman Oaks, California 91403 USA</p>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="office-info-item active">
                                <div class="office-info-icon">
                                    <div class="icon">
                                        <i class="fi flaticon-phone-call"></i>
                                    </div>
                                </div>
                                <div class="office-info-text">
                                    <h2>Phone Number</h2>
                                    <p>+1 909 639 4727</p>
                                    <p> <br> </p>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-4 col-md-6 col-12">
                            <div class="office-info-item">
                                <div class="office-info-icon">
                                    <div class="icon">
                                        <i class="fi flaticon-email"></i>
                                    </div>
                                </div>
                                <div class="office-info-text">
                                    <h2>Email</h2>
                                    <p>support@vortextruckersco.com</p>
                                    <p> <br> </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="wpo-get-touch-section section-padding">
                <div class="container">
                    <div class="row justify-content-end">
                        <div class="col-lg-7 col-12">
                            <div class="wpo-section-title">
                                <h2>Reliable truck dispatching service</h2>
                                <h3>Let’s Work Together</h3>
                            </div>
                            <form method="post" action="contactaction">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <input id="name" name="name" class="fild" type="text" placeholder="Your Name" required>
                                        <div id="nameError" class="error-message"></div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <input id="email" name="email" class="fild" type="email" placeholder="Email Address" required>
                                        <div id="emailError" class="error-message"></div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <input id="phone" name="phone" class="fild" type="text" placeholder="Your Number" required>
                                        <div id="phoneError" class="error-message"></div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <input id="subject" name="subject" class="fild" type="text" placeholder="Enter your Subject" required>
                                        <div id="subjectError" class="error-message"></div>
                                    </div>
                                    <div class="col-12">
                                        <textarea id="message" name="message" class="fild fild-textarea" placeholder="Write Message" required></textarea>
                                        <div id="messageError" class="error-message"></div>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="theme-btn">Send Us Messages <i class="ti-angle-right"></i></button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="shape">
                    <svg width="100%" height="100%" viewBox="0 0 579 909" fill="none">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M358.873 909L277 382L87.7578 760V909H358.873Z"
                            fill="#1C7991" />
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M0.703125 909L465.828 0L304.102 569.065L207.458 909H0.703125Z" fill="#FF7236" />
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M579.001 0L304.154 571.371L466.229 0H579.001Z"
                            fill="#124855" />
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M369.718 0L280.523 361.342L465.827 0H369.718Z"
                            fill="#1C7990" />
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M364.445 446.031L443.443 909H358.413L304.154 571.128L364.445 446.031Z" fill="#FFCB37" />
                    </svg>
                </div>
            </div>

        </section>
        <!--end of wpo-contact-page -->
        <!-- start of wpo-funfact-section-s2 -->
        <section class="wpo-funfact-section section-padding">
            <div class="container">
                <div class="titel-image">
                    <h1>Trucking</h1>
                    <h3>Dispatching solutions that exceed industry standards</h3>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="500"></span>+</h2>
                            <h3>Active trucks dispatched</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="15"></span>k+</h2>
                            <h3>Loads booked monthly</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="99"></span>%</h2>
                            <h3>On-time dispatch rate</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="24"></span>/7</h2>
                            <h3>Dispatch support</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- end of wpo-funfact-section-s2 -->




        <!--start of wpo-map-section -->
        <section class="wpo-map-section">
            <h2 class="hidden">Contact map</h2>
            <div class="wpo-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3172.71877275444!2d-118.4702548!3d34.15424469999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c297ecb5c14b41%3A0xf3fee99834259df2!2sThe%20Rodin%20Building%2C%2015442%20Ventura%20Blvd%20201%201361%2C%20Sherman%20Oaks%2C%20CA%2091403%2C%20USA!5e1!3m2!1sen!2s!4v1744116245831!5m2!1sen!2s" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </section>
        <!--end of wpo-map-section -->



        <!-- start of wpo-site-footer-section -->

        <?php include('footer.php'); ?>

        <!-- end of wpo-site-footer-section -->



    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>

</html>