<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.webp">
    <meta name="keywords" content="Vortex Truckers, about us, trucking company, freight shipping, logistics, truck drivers, reliable transport">
    <meta name="description" content="Vortex Truckers LLC: A trusted trucking & logistics company with expert drivers and dependable freight solutions. Learn about our mission and fleet.">
    <title>Vortex Truckers LLC | About Us </title>
    <link rel="canonical" href="https://vortextruckersco.com/about" />
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon_logistics.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/sass/styles.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- Start header -->

        <?php include('header.php'); ?>

        <!-- end of header -->

        <!-- start wpo-page-title -->
        <section class="wpo-breadcumb-area">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>Internation Logistics</h2>
                            <h3>About us</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end page-title -->

        <!-- start of wpo-about-section -->
        <section class="wpo-about-section">
            <div class="shape">
                <img src="assets/images/about/ab5.webp" alt="Truck dispatching network">
            </div>
            <div class="side-img">
                <img src="assets/images/about/ab4.webp" alt="Vortex Truckers LLC fleet">
            </div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-12">
                        <div class="about-left">
                            <div class="image-1">
                                <img src="assets/images/about/ab1.webp" alt="Dispatch team working">
                            </div>
                            <div class="image-2">
                                <img src="assets/images/about/ab2.webp" alt="Truck dispatching operations">
                            </div>
                            <div class="image-3">
                                <img src="assets/images/about/ab3.webp" alt="Fleet management system">
                            </div>
                            <div class="image-4">
                                <img src="assets/images/about/shape.webp" alt="shape">
                            </div>

                            <div class="since">
                                <div>
                                    <h2 class="odometer" data-count="2010">00</h2>
                                    <p>Years in Dispatch</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="about-content">
                            <div class="title">
                                <h2>Reliable truck dispatching service</h2>
                                <h3>Dispatch & Fleet Management<br>We Keep Your Trucks Moving</h3>
                            </div>
                            <div class="sub-content">
                                <span>Vortex Truckers LLC is North America's premier truck dispatch service — we optimize your fleet operations and maximize profitability through our 24/7 dispatch solutions and load management expertise.</span>
                            </div>
                            <h4>Operating nationwide with specialized services across all transportation sectors.</h4>
                            <ul>
                                <li>24/7 Dispatch Support for owner-operators and fleets</li>
                                <li>Load optimization and backhaul solutions</li>
                                <li>Paperwork management and compliance assistance</li>
                                <li>Real-time tracking and communication</li>
                            </ul>

                            <div class="author-btn">
                                <div class="author">
                                    <div class="image">
                                        <img src="assets/images/about/profile.webp" alt="Vortex Truckers LLC CEO">
                                    </div>
                                    <div class="text">
                                        <img src="assets/images/about/signature.webp" alt="CEO Signature">
                                        <span>CEO & Lead Dispatcher</span>
                                    </div>
                                </div>
                                <div class="about-btn">
                                    <a href="https://vortextruckersco.com/about" class="theme-btn">
                                        Our Dispatch Services
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-about-section -->
        <!-- start of wpo-funfact-section-s2 -->
        <section class="wpo-funfact-section-s3">
            <div class="container">
                <div class="wraper">
                    <div class="row g-0">
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="item">
                                <i class="flaticon-warehouse"></i>
                                <h2><span class="odometer" data-count="560">00</span></h2>
                                <p>Main Warehouses</p>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="item">
                                <i class="flaticon-truck"></i>
                                <h2><span class="odometer" data-count="100">00</span>%</h2>
                                <p>Supply Engineers</p>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="item">
                                <i class="flaticon-globe"></i>
                                <h2><span class="odometer" data-count="3">00</span>m+</h2>
                                <p>Countries Covered</p>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="item">
                                <i class="flaticon-order"></i>
                                <h2><span class="odometer" data-count="30">00</span>+</h2>
                                <p>Total Services</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-funfact-section-s2 -->

        <!-- start of wpo-service-section-s3 -->
        <section class="wpo-service-section-s3 section-padding">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-12">
                        <div class="wpo-section-title">
                            <h2>Vortex Truckers LLC</h2>
                            <h3>Transport & Logistics Services You Can Trust</h3>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="service-btn">
                            <a href="https://vortextruckersco.com/services" class="theme-btn">All Services</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="service-slider-s2">
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-1.svg" alt="Dry Van Dispatching Icon">
                    </div>
                    <div class="content">
                        <h2>Dry Van Dispatching</h2>
                        <p>Reliable dispatch solutions for dry vans, ensuring fast and efficient load handling across the U.S.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-2.svg" alt="Reefer Load Dispatch Icon">
                    </div>
                    <div class="content">
                        <h2>Reefer Load Dispatch</h2>
                        <p>Specialized in temperature-controlled freight with 24/7 monitoring for perishable goods delivery.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-3.svg" alt="Power Only Dispatch Icon">
                    </div>
                    <div class="content">
                        <h2>Power Only Dispatch</h2>
                        <p>Let us handle the trailers. We offer dispatch for power-only loads that get you moving fast and smart.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-4.svg" alt="Flatbed Dispatching Icon">
                    </div>
                    <div class="content">
                        <h2>Flatbed Dispatching</h2>
                        <p>Expert load matching for flatbed trailers, including oversized and heavy-haul cargo solutions.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
                <div class="service-card-s2">
                    <div class="icon">
                        <img src="assets/images/service/icon-5.svg" alt="Billing & Documentation Icon">
                    </div>
                    <div class="content">
                        <h2>Billing & Documentation</h2>
                        <p>We handle invoicing, rate confirmations, BOLs, and broker setup—saving you time and money.</p>
                    </div>
                    <div class="top-shape">
                        <img src="assets/images/service/top-shape.svg" alt="Top Shape Decoration">
                    </div>
                    <div class="bottom-shape">
                        <img src="assets/images/service/bottom-shape.svg" alt="Bottom Shape Decoration">
                    </div>
                </div>
            </div>
        </section>

        <!-- end of wpo-service-section-s3 -->

        <!-- stert of wpo-process-section -->
        <section class="wpo-process-section section-padding">
            <div class="container">
                <div class="process-wrap">
                    <div class="row">
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="process-item">
                                <div class="top-contnent">
                                    <img src="assets/images/process/1.webp" alt="process 1">
                                    <div class="item-shape">
                                        <img src="assets/images/process/item-shape.svg" alt="item shape">
                                    </div>
                                    <div class="text">
                                        <span>Step - 01</span>
                                    </div>
                                    <div class="shape-1">
                                        <svg width="158" height="89" viewBox="0 0 158 89" fill="none">
                                            <g opacity="0.15">
                                                <path d="M0.0332031 30.3796L157.05 0L157.354 43.7086L30.269 88.9426"
                                                    fill="#868686" />
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="shape-2">
                                        <svg width="48" height="17" viewBox="0 0 48 17" fill="none">
                                            <path
                                                d="M47.3549 0.599976L22.8851 16.5564L0.691406 12.5793L47.3549 0.599976Z" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2>Request a Quote</h2>
                                    <p>
                                        Contact Vortex Truckers LLC for a customized freight quote. Our team will assess your shipping needs and provide competitive rates.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="process-item">
                                <div class="top-contnent">
                                    <img src="assets/images/process/2.webp" alt="process 2 image">
                                    <div class="item-shape">
                                        <img src="assets/images/process/item-shape.svg" alt="item shape">
                                    </div>
                                    <div class="text">
                                        <span>Step - 02</span>
                                    </div>
                                    <div class="shape-1">
                                        <svg width="158" height="89" viewBox="0 0 158 89" fill="none">
                                            <g opacity="0.15">
                                                <path d="M0.0332031 30.3796L157.05 0L157.354 43.7086L30.269 88.9426"
                                                    fill="#868686" />
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="shape-2">
                                        <svg width="48" height="17" viewBox="0 0 48 17" fill="none">
                                            <path
                                                d="M47.3549 0.599976L22.8851 16.5564L0.691406 12.5793L47.3549 0.599976Z" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2>Schedule Pickup</h2>
                                    <p>
                                        Once you approve the quote, we'll arrange for pickup at your location with our reliable fleet of trucks and professional drivers.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="process-item">
                                <div class="top-contnent">
                                    <img src="assets/images/process/3.webp" alt="process 3">
                                    <div class="item-shape">
                                        <img src="assets/images/process/item-shape.svg" alt="item shape">
                                    </div>
                                    <div class="text">
                                        <span>Step - 03</span>
                                    </div>
                                    <div class="shape-1">
                                        <svg width="158" height="89" viewBox="0 0 158 89" fill="none">
                                            <g opacity="0.15">
                                                <path d="M0.0332031 30.3796L157.05 0L157.354 43.7086L30.269 88.9426"
                                                    fill="#868686" />
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="shape-2">
                                        <svg width="48" height="17" viewBox="0 0 48 17" fill="none">
                                            <path
                                                d="M47.3549 0.599976L22.8851 16.5564L0.691406 12.5793L47.3549 0.599976Z" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2>Safe Transport</h2>
                                    <p>
                                        Your cargo is transported with the highest safety standards. We provide real-time tracking so you can monitor your shipment.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="process-item">
                                <div class="top-contnent">
                                    <img src="assets/images/process/4.webp" alt="process 4">
                                    <div class="item-shape">
                                        <img src="assets/images/process/item-shape.svg" alt="item shape">
                                    </div>
                                    <div class="text">
                                        <span>Step - 04</span>
                                    </div>
                                    <div class="shape-1">
                                        <svg width="158" height="89" viewBox="0 0 158 89" fill="none">
                                            <g opacity="0.15">
                                                <path d="M0.0332031 30.3796L157.05 0L157.354 43.7086L30.269 88.9426"
                                                    fill="#868686" />
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="shape-2">
                                        <svg width="48" height="17" viewBox="0 0 48 17" fill="none">
                                            <path
                                                d="M47.3549 0.599976L22.8851 16.5564L0.691406 12.5793L47.3549 0.599976Z" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2>On-Time Delivery</h2>
                                    <p>
                                        Vortex Truckers LLC guarantees timely delivery of your goods. Our team ensures proper unloading and completes the process.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="border-shape">
                        <svg width="1014" height="93" viewBox="0 0 1014 93" fill="none">
                            <path
                                d="M1 50.9659C56.3481 18.4898 187.969 -31.1736 271.668 29.9813C376.292 106.425 467.026 98.4469 528 77.5C594.713 54.5817 761.5 15.5 831.5 24C901.5 32.5 936.5 57 1013.5 75"
                                stroke="#C4CDD3" stroke-width="1.5" stroke-dasharray="2 2" />
                        </svg>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-process-section -->

        <!-- start of wpo-funfact-section-s2 -->
        <section class="wpo-funfact-section section-padding">
            <div class="container">
                <div class="titel-image">
                    <h1>Trucking</h1>
                    <h3>Dispatching solutions that exceed industry standards</h3>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="500"></span>+</h2>
                            <h3>Active trucks dispatched</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="15"></span>k+</h2>
                            <h3>Loads booked monthly</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="99"></span>%</h2>
                            <h3>On-time dispatch rate</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="24"></span>/7</h2>
                            <h3>Dispatch support</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- end of wpo-funfact-section-s2 -->

        <!-- start of wpo-features-section-s2 -->
        <section class="wpo-features-section-s2">
            <div class="top-wraper">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-12">
                            <div class="wpo-section-title">
                                <h2>Vortex Truckers LLC</h2>
                                <h3>Logistics Features We Provide</h3>
                            </div>
                        </div>
                        <div class="col-lg-6 col-12">
                            <div class="f-btn">
                                <a href="https://vortextruckersco.com/services" class="theme-btn">All Services</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-wraper">
                <div class="container">
                    <div class="bottom-content">
                        <div class="row">
                            <div class="col-lg-4 col-12">
                                <div class="item">
                                    <div class="icon">
                                        <i class="flaticon-distribution-center" aria-hidden="true"></i>
                                    </div>
                                    <div class="content">
                                        <h3>Dispatch Management</h3>
                                        <p>We handle all load bookings, rate negotiations, and paperwork for you.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12">
                                <div class="item">
                                    <div class="icon">
                                        <i class="flaticon-customer-support-1" aria-hidden="true"></i>
                                    </div>
                                    <div class="content">
                                        <h3>24/7 Support</h3>
                                        <p>Round-the-clock dispatch support to keep your trucks moving nationwide.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12">
                                <div class="item">
                                    <div class="icon">
                                        <i class="flaticon-delivery-box" aria-hidden="true"></i>
                                    </div>
                                    <div class="content">
                                        <h3>Cargo Insurance Assistance</h3>
                                        <p>We guide you through getting cargo insurance for safe, secure shipping.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- end of wpo-features-section-s2 -->

        <!-- start of wpo-get-quate-section -->
        <section class="wpo-get-quate-section section-padding">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-12">
                        <div class="left-content">
                            <div class="wpo-section-title">
                                <h2>Professional Dispatch Services</h2>
                                <h3>Dispatching solutions<br>tailored to your needs</h3>
                            </div>
                            <div class="quat">
                                <p>Our dispatch services consider factors like load optimization, route efficiency, cost-effectiveness, and 24/7 availability to maximize your trucking business's performance and profitability.</p>
                            </div>
                            <ul class="get-item">
                                <li>
                                    <i class="flaticon-logistics"></i>
                                    <h3>Regional & Long-Haul<br>Dispatch Coverage</h3>
                                </li>
                                <li>
                                    <i class="flaticon-nanotechnology"></i>
                                    <h3>Real-Time Load Tracking<br>& Communication</h3>
                                </li>
                            </ul>
                            <ul class="quate-item">
                                <li>
                                    <i class="flaticon-check"></i>
                                    <h3>Dedicated Dispatch Agent</h3>
                                </li>
                                <li>
                                    <i class="flaticon-check"></i>
                                    <h3>Paperwork & Compliance Management</h3>
                                </li>
                            </ul>
                            <a href="https://vortextruckersco.com/about" class="theme-btn">Why Choose Our Dispatch</a>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="quote-form">
                            <div class="title">
                                <h3>Dispatch Service Inquiry</h3>
                            </div>
                            <form method="post" action="queryaction">
                                <div class="row">
                                    <div class="item col-lg-12">
                                        <label>Contact Information</label>
                                        <input class="form-control" type="text" name="name" id="name"
                                            placeholder="Your Name" required>
                                    </div>
                                    <div class="item col-lg-6 col-12">
                                        <input class="form-control" type="email" name="email" id="email"
                                            placeholder="Email" required>
                                    </div>
                                    <div class="item col-lg-6 col-12">
                                        <input class="form-control" type="text" name="phone" id="phone"
                                            placeholder="Phone" required>
                                    </div>
                                    <div class="item col-lg-12">
                                        <label>Dispatch Needs</label>
                                        <select name="service" id="service" class="form-control" required>
                                            <option value="">Select Service Type</option>
                                            <option value="owner-operator">Owner-Operator Dispatch</option>
                                            <option value="fleet">Fleet Dispatch Services</option>
                                            <option value="hotshot">Hotshot Dispatch</option>
                                            <option value="reefer">Reefer Dispatch</option>
                                        </select>
                                    </div>
                                    <div class="item col-lg-6 col-12">
                                        <label>Fleet Size</label>
                                        <select name="fleet-size" id="fleet-size" class="form-control" required>
                                            <option value="">Number of Trucks</option>
                                            <option value="1-5">1-5 Trucks</option>
                                            <option value="6-10">6-10 Trucks</option>
                                            <option value="11-20">11-20 Trucks</option>
                                            <option value="20+">20+ Trucks</option>
                                        </select>
                                    </div>
                                    <div class="item col-lg-6 col-12">
                                        <label>Primary Haul Type</label>
                                        <select name="haul-type" id="haul-type" class="form-control" required>
                                            <option value="">Select Haul Type</option>
                                            <option value="dry-van">Dry Van</option>
                                            <option value="flatbed">Flatbed</option>
                                            <option value="reefer">Reefer</option>
                                            <option value="specialized">Specialized</option>
                                        </select>
                                    </div>
                                    <div class="item col-12">
                                        <ul>
                                            <li>
                                                <input type="checkbox" id="24-7">
                                                <label for="24-7">24/7 Dispatch Needed</label>
                                            </li>
                                            <li>
                                                <input type="checkbox" id="backhaul">
                                                <label for="backhaul">Backhaul Assistance</label>
                                            </li>
                                            <li>
                                                <input type="checkbox" id="compliance">
                                                <label for="compliance">Compliance Support</label>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="item col-12">
                                        <input class="theme-btn" type="submit" value="Get Dispatch Quote">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="left-bg">
                <div class="img1">
                    <img src="assets/images/get1.webp" alt="Truck dispatch operations">
                </div>
                <div class="img2">
                    <img src="assets/images/get2.svg" alt="Dispatch communication">
                </div>
                <div class="img3">
                    <img src="assets/images/get3.svg" alt="Route optimization">
                </div>
            </div>
            <div class="rigth-bg">
                <img src="assets/images/get4.webp" alt="Vortex Truckers LLC dispatch team">
            </div>
        </section>
        <!-- end of wpo-get-quate-section -->

        <!--end of wpo-map-section -->



        <!-- start of wpo-site-footer-section -->

        <?php include('footer.php'); ?>

        <!-- end of wpo-site-footer-section -->



    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>


<!-- Mirrored from wpocean.com/html/tf/logistika/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 04 Apr 2025 11:27:05 GMT -->

</html>