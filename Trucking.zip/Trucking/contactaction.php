<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Sanitize input
    $name = htmlspecialchars($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $phone = htmlspecialchars($_POST['phone']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = nl2br(htmlspecialchars($_POST['message']));

    // Email details
    $to = "support@vortextruckersco.com";
    $email_subject = "New Contact Form Submission: $subject";
    $email_message = "
    <html>
    <head>
    <style>
        body { font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #FCB650; color: white; text-align: left; }
    </style>
    </head>
    <body>
    <table>
        <tr><th colspan='2'>Client Information - Vortex Truckers LLC</th></tr>
        <tr><td><strong>Name:</strong></td><td>$name</td></tr>
        <tr><td><strong>Email:</strong></td><td>$email</td></tr>
        <tr><td><strong>Phone:</strong></td><td>$phone</td></tr>
        <tr><td><strong>Subject:</strong></td><td>$subject</td></tr>
        <tr><td><strong>Message:</strong></td><td>$message</td></tr>
    </table>
    </body>
    </html>";

    // Headers
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8\r\n";
    $headers .= "From: no-reply@yourdomain.com\r\n";
    $headers .= "Reply-To: $email\r\n";

    // Send email
    if (mail($to, $email_subject, $email_message, $headers)) {
        echo "<script>alert('Your message has been sent successfully!');  window.location.href=''; </script>";
    } else {
        echo "<script>alert('Failed to send message. Please try again later.');  window.location.href=''; </script>";
    }

} else {
    header("Location: https://vortextruckersco.com/");
    exit;
}
?>
