<?php 
opcache_reset();                                  
?>