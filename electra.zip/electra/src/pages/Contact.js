// src/pages/Contact.js
import React from "react";
import { Helmet } from "react-helmet";

function Contact() {
  const handleSubmit = (e) => {
    e.preventDefault();

    // You can collect data here if you want:
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    console.log(data);

    alert("Form submitted!");

    setTimeout(() => {
      window.location.reload();
    }, 500);
  };
  return (
    <>
      <Helmet>
        <title>Contact ElectraGrid | Get Your Electrical Project Started</title>
        <meta
          name="description"
          content="Get in touch with ElectraGrid for all your electrical solutions. Contact us today!"
        />
        <meta
          name="keywords"
          content="Contact, ElectraGrid, Electrical Solutions, Energy Management, Customer Support"
        />
        <meta name="author" content="ElectraGrid Team" />
        <meta property="og:title" content="Contact Us - ElectraGrid" />
        <meta
          property="og:description"
          content="Get in touch with ElectraGrid for all your electrical solutions. Contact us today!"
        />
        <meta
          property="og:image"
          content="https://www.electragrid.com/img/logo.png"
        />
        <meta property="og:url" content="https://www.electragrid.com/contact" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Contact Us - ElectraGrid" />
        <meta
          name="twitter:description"
          content="Get in touch with ElectraGrid for all your electrical solutions. Contact us today!"
        />
        <meta
          name="twitter:image"
          content="https://www.electragrid.com/img/logo.png"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="canonical" href="https://www.electragrid.com/contact" />
      </Helmet>

      {/* <!-- Navbar & Hero Start --> */}
      <div className="container-fluid header-top">
        <div className="container d-flex align-items-center">
          <div className="d-flex align-items-center h-100">
            <a href="#" className="navbar-brand" style={{ height: "125px" }}>
              <h1 className="text-primary mb-0">
                <i className="fas fa-bolt"></i> ElectraGrid
              </h1>
              {/* <img src="img/logo.png" alt="Logo" /> */}
            </a>
          </div>
          <div className="w-100 h-100">
            <div
              className="topbar px-0 py-2 d-none d-lg-block"
              style={{ height: "45px" }}
            >
              <div className="row gx-0 align-items-center">
                <div className="col-lg-8 text-center text-lg-center mb-lg-0">
                  <div className="d-flex flex-wrap">
                    <div className="border-end border-primary pe-3">
                      <a href="/contact" className="text-muted small">
                        <i className="fas fa-map-marker-alt text-primary me-2"></i>
                        Find A Location
                      </a>
                    </div>
                    <div className="ps-3">
                      <a
                        href="mailto:example@gmail.com"
                        className="text-muted small"
                      >
                        <i className="fas fa-envelope text-primary me-2"></i>
                        example@gmail.com
                      </a>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 text-center text-lg-end">
                  <div className="d-flex justify-content-end">
                    <div className="d-flex border-end border-primary pe-3">
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-facebook-f"></i>
                      </a>
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-twitter"></i>
                      </a>
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-instagram"></i>
                      </a>
                      <a className="btn p-0 text-primary me-0" href="#">
                        <i className="fab fa-linkedin-in"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="nav-bar px-0 py-lg-0" style={{ height: "80px" }}>
              <nav className="navbar navbar-expand-lg navbar-light d-flex justify-content-lg-end">
                <a href="/" className="navbar-brand-2">
                  <h1 className="text-primary mb-0">
                    <i className="fas fa-bolt"></i> ElectraGrid
                  </h1>
                  {/* <img src="img/logo.png" alt="Logo" /> */}
                </a>
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarCollapse"
                >
                  <span className="fa fa-bars"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarCollapse">
                  <div className="navbar-nav mx-0 mx-lg-auto bg-white">
                    <a href="/" className="nav-item nav-link">
                      Home
                    </a>
                    <a href="/about" className="nav-item nav-link">
                      About
                    </a>
                    <a href="/services" className="nav-item nav-link">
                      Services
                    </a>
                    <a href="/blog" className="nav-item nav-link">
                      Blog
                    </a>
                    <a href="/project" className="nav-item nav-link">
                      Projects
                    </a>
                    <a href="/contact" className="nav-item nav-link  active">
                      Contact
                    </a>
                    <div className="nav-btn ps-3">
                      <button
                        className="btn-search btn btn-primary btn-md-square mt-2 mt-lg-0 mb-4 mb-lg-0 flex-shrink-0"
                        data-bs-toggle="modal"
                        data-bs-target="#searchModal"
                      >
                        <i className="fas fa-search"></i>
                      </button>
                      <a
                        href="/contact"
                        className="btn btn-primary py-2 px-4 ms-0 ms-lg-3"
                      >
                        {" "}
                        Get Solution
                      </a>
                    </div>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Navbar & Hero End -->

        <!-- Modal Search Start --> */}
      <div
        className="modal fade"
        id="searchModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-fullscreen">
          <div className="modal-content rounded-0">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Search by keyword
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body d-flex align-items-center bg-primary">
              <div className="input-group w-75 mx-auto d-flex">
                <input
                  type="search"
                  className="form-control p-3"
                  placeholder="keywords"
                  aria-describedby="search-icon-1"
                />
                <span
                  id="search-icon-1"
                  className="btn bg-light border nput-group-text p-3"
                >
                  <i className="fa fa-search"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Modal Search End -->*/}

      {/* <!-- Header Start --> */}
      <div className="container-fluid bg-breadcrumb">
        <div
          className="container text-center py-5"
          style={{ maxWidth: "900px" }}
        >
          <h4
            className="text-white display-4 mb-4 wow fadeInDown"
            data-wow-delay="0.1s"
          >
            Contact Us
          </h4>
          <ol
            className="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown"
            data-wow-delay="0.3s"
          >
            <li className="breadcrumb-item">
              <a href="/">Home</a>
            </li>
            <li className="breadcrumb-item active text-primary">Contact Us</li>
          </ol>
        </div>
      </div>
      {/* <!-- Header End --> */}

      {/* <!-- Contact Start --> */}
      <div className="container-fluid contact bg-light py-5">
        <div className="container py-5">
          <div className="row g-5">
            {/* LEFT COLUMN - CONTACT INFO */}
            <div className="col-lg-6 wow fadeInLeft" data-wow-delay="0.2s">
              <div>
                <h4 className="text-primary">Contact Us</h4>
                <h1 className="display-4 mb-4">
                  Connect With ElectraGrid Today
                </h1>
                <p className="mb-5">
                  Have a question, need a quote, or want to explore innovative
                  electrical solutions? Our team is ready to help you power your
                  projects with efficiency and expertise.
                </p>

                <div className="d-flex align-items-center mb-4">
                  <a
                    className="btn btn-primary btn-md-square me-3"
                    href="https://facebook.com"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <i className="fab fa-facebook-f"></i>
                  </a>
                  <a
                    className="btn btn-primary btn-md-square me-3"
                    href="https://twitter.com"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <i className="fab fa-twitter"></i>
                  </a>
                  <a
                    className="btn btn-primary btn-md-square me-3"
                    href="https://instagram.com"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <i className="fab fa-instagram"></i>
                  </a>
                  <a
                    className="btn btn-primary btn-md-square me-0"
                    href="https://linkedin.com"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <i className="fab fa-linkedin-in"></i>
                  </a>
                </div>

                <div className="row g-4">
                  <div className="col-12">
                    <div className="d-inline-flex bg-white w-100 p-4">
                      <i className="fas fa-map-marker-alt fa-2x text-primary me-4"></i>
                      <div>
                        <h4>Address</h4>
                        <p className="mb-0">
                          456 Energy Avenue, New York, NY, USA
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-12 col-xl-6">
                    <div className="d-inline-flex bg-white w-100 p-4">
                      <i className="fas fa-envelope fa-2x text-primary me-4"></i>
                      <div>
                        <h4>Email Us</h4>
                        <p className="mb-0">contact@electragrid.com</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-12 col-xl-6">
                    <div className="d-inline-flex bg-white w-100 p-4">
                      <i className="fa fa-phone-alt fa-2x text-primary me-4"></i>
                      <div>
                        <h4>Call Us</h4>
                        <p className="mb-0">(+1) 212-555-0198</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN - CONTACT FORM */}
            <div className="col-lg-6 wow fadeInRight" data-wow-delay="0.4s">
              <div>
                <p className="mb-4">
                  Complete the form below to get in touch with ElectraGrid’s
                  specialists. We’ll respond promptly to help you find the
                  perfect electrical solutions for your home, business, or
                  industry.
                </p>
                <form onSubmit={handleSubmit} method="post">
                  <div className="row g-4">
                    <div className="col-lg-12 col-xl-6">
                      <div className="form-floating">
                        <input
                          type="text"
                          className="form-control border-0"
                          id="name"
                          placeholder="Your Name"
                          required
                        />
                        <label htmlFor="name">Your Name</label>
                      </div>
                    </div>
                    <div className="col-lg-12 col-xl-6">
                      <div className="form-floating">
                        <input
                          type="email"
                          className="form-control border-0"
                          id="email"
                          placeholder="Your Email"
                          required
                        />
                        <label htmlFor="email">Your Email</label>
                      </div>
                    </div>
                    <div className="col-lg-12 col-xl-6">
                      <div className="form-floating">
                        <input
                          type="tel"
                          className="form-control border-0"
                          id="phone"
                          placeholder="Your Phone"
                          required
                        />
                        <label htmlFor="phone">Your Phone</label>
                      </div>
                    </div>
                    <div className="col-lg-12 col-xl-6">
                      <div className="form-floating">
                        <input
                          type="text"
                          className="form-control border-0"
                          id="project"
                          placeholder="Project"
                          required
                        />
                        <label htmlFor="project">Your Project</label>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-floating">
                        <input
                          type="text"
                          className="form-control border-0"
                          id="subject"
                          placeholder="Subject"
                          required
                        />
                        <label htmlFor="subject">Subject</label>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-floating">
                        <textarea
                          className="form-control border-0"
                          placeholder="Leave a message here"
                          id="message"
                          style={{ height: "125px" }}
                          required
                        ></textarea>
                        <label htmlFor="message">Message</label>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value=""
                          id="flexCheck"
                          required
                        />
                        <label className="form-check-label" htmlFor="flexCheck">
                          I agree to ElectraGrid's privacy policy
                        </label>
                      </div>
                    </div>
                    <div className="col-12">
                      <button
                        className="btn btn-primary w-100 py-3"
                        type="submit"
                      >
                        Send Message
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>

            {/* GOOGLE MAP */}
            <div className="col-12 wow fadeInUp" data-wow-delay="0.2s">
              <div className="h-100 overflow-hidden">
                <iframe
                  className="w-100"
                  style={{ height: "400px" }}
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387191.33750346623!2d-73.97968099999999!3d40.6974881!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sus!4v1694259649153!5m2!1sen!2sus"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="ElectraGrid New York Map"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Contact End --> */}

      {/* <!-- Footer Start --> */}
      <div
        className="container-fluid footer bg-dark py-5 wow fadeIn"
        data-wow-delay="0.2s"
      >
        <div className="container py-5">
          <div className="row g-5 mb-5 align-items-center">
            <div className="col-lg-7">
              <div className="position-relative mx-auto">
                <input
                  className="form-control w-100 py-3 ps-4 pe-5"
                  type="text"
                  placeholder="Enter your email to subscribe"
                />
                <button
                  type="button"
                  className="btn btn-primary position-absolute top-0 end-0 py-2 px-4 mt-2 me-2"
                >
                  Subscribe
                </button>
              </div>
            </div>
            <div className="col-lg-5">
              <div className="d-flex align-items-center justify-content-center justify-content-lg-end">
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-twitter"></i>
                </a>
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-instagram"></i>
                </a>
                <a className="btn btn-light btn-md-square me-0" href="#">
                  <i className="fab fa-linkedin-in"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="row g-5">
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h3 className="text-white mb-4">
                  <i className="fas fa-bolt text-primary me-3"></i>ElectraGrid
                </h3>
                <p className="mb-3">
                  ElectraGrid delivers innovative electricity solutions and
                  energy management systems to power your business and home with
                  reliability and sustainability.
                </p>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Quick Links</h4>
                <a href="/">Home</a>
                <a href="/about">About Us</a>
                <a href="/services">Services</a>
                <a href="/projects">Projects</a>
                <a href="/contact">Contact Us</a>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Our Services</h4>
                <a href="/services">Smart Energy Management</a>
                <a href="/services">Electrical Installations</a>
                <a href="/services">Backup Power Solutions</a>
                <a href="/services">Energy Monitoring</a>
                <a href="/services">Sustainable Energy</a>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Contact Info</h4>
                <a href="#">
                  <i className="fa fa-map-marker-alt text-primary me-2"></i>
                  456 Energy Avenue, New York, USA
                </a>
                <a href="mailto:info@electragrid.com">
                  <i className="fas fa-envelope text-primary me-2"></i>
                  info@electragrid.com
                </a>
                <a href="tel:+1234567890">
                  <i className="fas fa-phone text-primary me-2"></i>
                  +1 234 567 890
                </a>
                <a href="tel:+1234567891" className="mb-3">
                  <i className="fas fa-print text-primary me-2"></i>
                  +1 234 567 891
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <a href="#" className="btn btn-primary btn-lg-square back-to-top">
        <i className="fa fa-arrow-up"></i>
      </a>
    </>
  );
}

export default Contact;
