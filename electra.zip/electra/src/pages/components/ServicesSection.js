import React, { useState, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

// import "./ServicesSection.css";

const ServicesSection = () => {
  const [activeTab, setActiveTab] = useState("ServiceTab-1");
  const swiperRef = useRef(null);

  const tabs = [
    { id: "ServiceTab-1", label: "Commercial" },
    { id: "ServiceTab-2", label: "Residential" },
    { id: "ServiceTab-3", label: "Industrial" },
  ];

  const services = {
    "ServiceTab-1": [
      {
        img: "img/commercial-1.jpg",
        title: "Brite Spark Services",
        desc: "Efficient lighting and electrical services for commercial buildings with a focus on innovation and safety.",
      },
      {
        img: "img/commercial-2.jpg",
        title: "Energy Ease Packages",
        desc: "Affordable and reliable energy solutions designed to optimize power usage in business environments.",
      },
      {
        img: "img/commercial-3.jpg",
        title: "Electra Care Packages",
        desc: "Comprehensive maintenance plans ensuring long-term stability and efficiency for commercial systems.",
      },
    ],
    "ServiceTab-2": [
      {
        img: "img/residential-1.jpg",
        title: "Electrical Services",
        desc: "Full residential wiring, installation, and energy-saving system integration with certified technicians.",
      },
      {
        img: "img/residential-2.jpg",
        title: "Security Systems",
        desc: "Advanced home surveillance and alarm setups to ensure your family’s safety and peace of mind.",
      },
      {
        img: "img/residential-3.jpg",
        title: "Air Conditioner",
        desc: "Energy-efficient air conditioning installations and repairs tailored to your home environment.",
      },
    ],
    "ServiceTab-3": [
      {
        img: "img/industrial-1.jpg",
        title: "Factory Manufacture",
        desc: "Custom industrial electrical setups for manufacturing units ensuring power reliability and safety.",
      },
      {
        img: "img/industrial-2.jpg",
        title: "General Electrical",
        desc: "End-to-end electrical planning, installation, and maintenance for large-scale industrial projects.",
      },
      {
        img: "img/industrial-3.jpg",
        title: "Electrical Planing",
        desc: "Strategic power management and electrical load distribution for efficient industrial operations.",
      },
    ],
  };

  return (
    <div className="container-fluid service py-5">
      <div className="container py-5">
        <div
          className="d-flex flex-column mx-auto text-center mb-5"
          style={{ maxWidth: "800px" }}
        >
          <h4 className="text-primary">Our Services</h4>
          <h1 className="display-4 mb-4">The Best Service For You</h1>
          <p className="mb-0">
            We offer specialized electrical solutions for residential,
            commercial, and industrial sectors with expert teams and
            high-quality standards.
          </p>
        </div>

        <div className="row g-5 align-items-center">
          <div className="col-lg-3">
            <div className="d-flex flex-column align-items-start">
              <button
                className="arrow-btn arrow-next mb-3"
                onClick={() => swiperRef.current?.slideNext()}
              >
                Next →
              </button>

              <ul className="nav flex-column w-100">
                {tabs.map((tab) => (
                  <li className="nav-item mb-3" key={tab.id}>
                    <button
                      className={`py-3 px-4 btn w-100 tab-btn ${
                        activeTab === tab.id ? "btn-primary" : "btn-secondary"
                      }`}
                      onClick={() => setActiveTab(tab.id)}
                    >
                      {tab.label}
                    </button>
                  </li>
                ))}
              </ul>

              <button
                className="arrow-btn arrow-prev mt-3"
                onClick={() => swiperRef.current?.slidePrev()}
              >
                ← Prev
              </button>
            </div>
          </div>

          <div className="col-lg-9">
            <Swiper
              onSwiper={(swiper) => {
                swiperRef.current = swiper;
              }}
              slidesPerView={2}
              spaceBetween={30}
              loop={true}
              autoplay={{
                delay: 3000,
                disableOnInteraction: false,
              }}
              modules={[Autoplay, Navigation]}
            >
              {services[activeTab].map((item, idx) => (
                <SwiperSlide key={idx}>
                  <div className="service-item">
                    <img
                      src={item.img}
                      className="img-fluid w-100"
                      alt={item.title}
                    />
                    <div className="border border-top-0 p-4">
                      <h4 className="mb-3">{item.title}</h4>
                      <p className="mb-4">{item.desc}</p>
                      <a className="btn btn-primary py-2 px-4" href="#">
                        Read More
                      </a>
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServicesSection;
