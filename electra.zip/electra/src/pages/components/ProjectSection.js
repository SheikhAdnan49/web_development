import React from "react";


function ProjectSection() {
  return (
    <>
    <div className="container-fluid projects bg-light py-5">
        <div className="container py-5">
          <div className="row g-5">
            <div className="col-lg-5 wow fadeInLeft" data-wow-delay="0.2s">
              <div>
                <h4 className="text-primary">Our Projects</h4>
                <h1 className="display-4 mb-4">
                ElectraGrid's Power Innovations
                </h1>
                <p className="mb-5">
                  At ElectraGrid, our projects redefine how electricity powers
                  homes, industries, and smart infrastructures. Explore how we
                  deliver efficiency, reliability, and cutting-edge technology.
                </p>
                <ul className="nav">
                  <li className="nav-item bg-white mb-4 w-100">
                    <a
                      className="d-flex align-items-center h4 mb-0 p-3 active"
                      data-bs-toggle="pill"
                      href="#ProjectsTab-1"
                    >
                      <div className="projects-icon btn-md-square bg-primary text-white me-3">
                        <span className="fas fa-bolt small"></span>
                      </div>
                      <span>GridGuard Power Systems</span>
                    </a>
                  </li>
                  <li className="nav-item bg-white mb-4 w-100">
                    <a
                      className="d-flex align-items-center h4 mb-0 p-3"
                      data-bs-toggle="pill"
                      href="#ProjectsTab-2"
                    >
                      <div className="projects-icon btn-md-square bg-primary text-white me-3">
                        <span className="fas fa-charging-station small"></span>
                      </div>
                      <span>SmartVolt Infrastructure</span>
                    </a>
                  </li>
                  <li className="nav-item bg-white mb-4 w-100">
                    <a
                      className="d-flex align-items-center h4 mb-0 p-3"
                      data-bs-toggle="pill"
                      href="#ProjectsTab-3"
                    >
                      <div className="projects-icon btn-md-square bg-primary text-white me-3">
                        <span className="fas fa-broadcast-tower small"></span>
                      </div>
                      <span>EnergyWave Networks</span>
                    </a>
                  </li>
                  <li className="nav-item bg-white mb-4 w-100">
                    <a
                      className="d-flex align-items-center h4 mb-0 p-3"
                      data-bs-toggle="pill"
                      href="#ProjectsTab-4"
                    >
                      <div className="projects-icon btn-md-square bg-primary text-white me-3">
                        <span className="fas fa-bolt small"></span>
                      </div>
                      <span>WattWise Innovations</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-lg-7 wow fadeInRight" data-wow-delay="0.2s">
              <div className="tab-content">
                <div
                  id="ProjectsTab-1"
                  className="tab-pane fade show p-0 active"
                >
                  <div className="projects-item">
                    <img
                      src="img/industrial-1.jpg"
                      className="img-fluid w-100"
                      alt="GridGuard Power Systems"
                    />
                    <div className="projects-content bg-white p-4">
                      <h4 className="mb-3">GridGuard Power Systems</h4>
                      <p className="mb-4">
                        Our advanced GridGuard projects ensure seamless power
                        distribution with real-time monitoring and smart
                        automation for maximum efficiency and stability in all
                        electrical infrastructures. Leveraging AI-driven
                        diagnostics, the system proactively detects faults and
                        minimizes downtime. Designed for both urban and rural
                        grids, GridGuard guarantees uninterrupted service and
                        enhanced energy management.
                      </p>
                      <a className="btn btn-primary py-2 px-4" href="#">
                        Read More
                      </a>
                    </div>
                  </div>
                </div>
                <div id="ProjectsTab-2" className="tab-pane fade show p-0">
                  <div className="projects-item">
                    <img
                      src="img/industrial-2.jpg"
                      className="img-fluid w-100"
                      alt="SmartVolt Infrastructure"
                    />
                    <div className="projects-content bg-white p-4">
                      <h4 className="mb-3">SmartVolt Infrastructure</h4>
                      <p className="mb-4">
                        ElectraGrid's SmartVolt solutions integrate cutting-edge
                        technology for intelligent power management, reducing
                        energy waste and optimizing performance in commercial
                        and industrial facilities. These systems utilize IoT
                        sensors and adaptive controls to balance load demands
                        and improve power quality. SmartVolt also supports
                        renewable energy integration, making it ideal for
                        sustainable infrastructure projects.
                      </p>
                      <a className="btn btn-primary py-2 px-4" href="#">
                        Read More
                      </a>
                    </div>
                  </div>
                </div>
                <div id="ProjectsTab-3" className="tab-pane fade show p-0">
                  <div className="projects-item">
                    <img
                      src="img/commercial-1.jpg"
                      className="img-fluid w-100"
                      alt="EnergyWave Networks"
                    />
                    <div className="projects-content bg-white p-4">
                      <h4 className="mb-3">EnergyWave Networks</h4>
                      <p className="mb-4">
                        EnergyWave Networks focus on modern communication and
                        energy systems, bringing robust connectivity and
                        data-driven insights for smarter electrical grids and
                        sustainable urban developments. By combining high-speed
                        data transmission with energy analytics, EnergyWave
                        enables precise grid control and fault management. This
                        project supports smart city initiatives by fostering
                        eco-friendly and efficient power usage.
                      </p>
                      <a className="btn btn-primary py-2 px-4" href="#">
                        Read More
                      </a>
                    </div>
                  </div>
                </div>
                <div id="ProjectsTab-4" className="tab-pane fade show p-0">
                  <div className="projects-item">
                    <img
                      src="img/commercial-2.jpg"
                      className="img-fluid w-100"
                      alt="WattWise Innovations"
                    />
                    <div className="projects-content bg-white p-4">
                      <h4 className="mb-4">WattWise Innovations</h4>
                      <p className="mb-4">
                        WattWise Innovations represent ElectraGrid's commitment
                        to developing energy-efficient systems, ensuring
                        sustainability and cost savings for businesses,
                        communities, and residential clients. By implementing
                        smart metering and adaptive load management, WattWise
                        maximizes energy conservation without compromising
                        performance. The innovations support green technology
                        adoption and promote long-term environmental
                        responsibility.
                      </p>
                      <a className="btn btn-primary py-2 px-4" href="#">
                        Read More
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </>
    );
}
export default ProjectSection;