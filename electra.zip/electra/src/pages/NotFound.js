import React from "react";
import { Helmet } from "react-helmet";
// import ServicesSection from './components/ServicesSection';

function NotFound() {
  return (
    <>
      <Helmet>
        <title>ElectraGrid - 404 Not Found</title>
        <meta
          name="description"
          content="ElectraGrid - 404 Not Found. The page you are looking for does not exist."
        />
        <link rel="canonical" href="https://www.electragrid.com/404" />
      </Helmet>
      
 {/* <!-- Navbar & Hero Start --> */}
 <div className="container-fluid header-top">
        <div className="container d-flex align-items-center">
          <div className="d-flex align-items-center h-100">
            <a href="#" className="navbar-brand" style={{ height: "125px" }}>
              <h1 className="text-primary mb-0">
                <i className="fas fa-bolt"></i> ElectraGrid
              </h1>
              {/* <img src="img/logo.png" alt="Logo" /> */}
            </a>
          </div>
          <div className="w-100 h-100">
            <div
              className="topbar px-0 py-2 d-none d-lg-block"
              style={{ height: "45px" }}
            >
              <div className="row gx-0 align-items-center">
                <div className="col-lg-8 text-center text-lg-center mb-lg-0">
                  <div className="d-flex flex-wrap">
                    <div className="border-end border-primary pe-3">
                      <a href="/contact" className="text-muted small">
                        <i className="fas fa-map-marker-alt text-primary me-2"></i>
                        Find A Location
                      </a>
                    </div>
                    <div className="ps-3">
                      <a
                        href="mailto:example@gmail.com"
                        className="text-muted small"
                      >
                        <i className="fas fa-envelope text-primary me-2"></i>
                        example@gmail.com
                      </a>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 text-center text-lg-end">
                  <div className="d-flex justify-content-end">
                    <div className="d-flex border-end border-primary pe-3">
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-facebook-f"></i>
                      </a>
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-twitter"></i>
                      </a>
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-instagram"></i>
                      </a>
                      <a className="btn p-0 text-primary me-0" href="#">
                        <i className="fab fa-linkedin-in"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="nav-bar px-0 py-lg-0" style={{ height: "80px" }}>
              <nav className="navbar navbar-expand-lg navbar-light d-flex justify-content-lg-end">
                <a href="/" className="navbar-brand-2">
                  <h1 className="text-primary mb-0">
                    <i className="fas fa-bolt"></i> ElectraGrid
                  </h1>
                  {/* <img src="img/logo.png" alt="Logo" /> */}
                </a>
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarCollapse"
                >
                  <span className="fa fa-bars"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarCollapse">
                  <div className="navbar-nav mx-0 mx-lg-auto bg-white">
                    <a href="/" className="nav-item nav-link active">
                      Home
                    </a>
                    <a href="/about" className="nav-item nav-link">
                      About
                    </a>
                    <a href="/services" className="nav-item nav-link">
                      Services
                    </a>
                    <a href="/blog" className="nav-item nav-link">
                      Blog
                    </a>
                    <a href="/project" className="nav-item nav-link">
                      Projects
                    </a>
                    <a href="/contact" className="nav-item nav-link">
                      Contact
                    </a>
                    <div className="nav-btn ps-3">
                      <button
                        className="btn-search btn btn-primary btn-md-square mt-2 mt-lg-0 mb-4 mb-lg-0 flex-shrink-0"
                        data-bs-toggle="modal"
                        data-bs-target="#searchModal"
                      >
                        <i className="fas fa-search"></i>
                      </button>
                      <a
                        href="/contact"
                        className="btn btn-primary py-2 px-4 ms-0 ms-lg-3"
                      >
                        {" "}
                        Get Solution
                      </a>
                    </div>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Navbar & Hero End -->

        <!-- Modal Search Start --> */}
      <div
        className="modal fade"
        id="searchModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-fullscreen">
          <div className="modal-content rounded-0">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Search by keyword
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body d-flex align-items-center bg-primary">
              <div className="input-group w-75 mx-auto d-flex">
                <input
                  type="search"
                  className="form-control p-3"
                  placeholder="keywords"
                  aria-describedby="search-icon-1"
                />
                <span
                  id="search-icon-1"
                  className="btn bg-light border nput-group-text p-3"
                >
                  <i className="fa fa-search"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Modal Search End -->*/}



       {/* <!-- Header Start --> */}
       <div className="container-fluid bg-breadcrumb">
            <div className="container text-center py-5" style={{ maxWidth: '900px' }}>
                <h4 className="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">404</h4>
                <ol className="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                    <li className="breadcrumb-item"><a href="/">Home</a></li>
                    <li className="breadcrumb-item active text-primary">404</li>
                </ol>    
            </div>
        </div>
        {/* <!-- Header End --> */}


        {/* <!-- 404 Start --> */}
        <div className="container-fluid py-5">
            <div className="container py-5 text-center">
                <div className="row justify-content-center">
                    <div className="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                        <i className="bi bi-exclamation-triangle display-1 text-primary"></i>
                        <h1 className="display-1">404</h1>
                        <h1 className="mb-4">Page Not Found</h1>
                        <p className="mb-4">We’re sorry, the page you have looked for does not exist in our website! Maybe go to our home page or try to use a search?</p>
                        <a className="btn btn-primary py-3 px-5" href="/">Go Back To Home</a>
                    </div>
                </div>
            </div>
        </div>
        {/* <!-- 404 End --> */}

          {/* <!-- Footer Start --> */}
      <div
        className="container-fluid footer bg-dark py-5 wow fadeIn"
        data-wow-delay="0.2s"
      >
        <div className="container py-5">
          <div className="row g-5 mb-5 align-items-center">
            <div className="col-lg-7">
              <div className="position-relative mx-auto">
                <input
                  className="form-control w-100 py-3 ps-4 pe-5"
                  type="text"
                  placeholder="Enter your email to subscribe"
                />
                <button
                  type="button"
                  className="btn btn-primary position-absolute top-0 end-0 py-2 px-4 mt-2 me-2"
                >
                  Subscribe
                </button>
              </div>
            </div>
            <div className="col-lg-5">
              <div className="d-flex align-items-center justify-content-center justify-content-lg-end">
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-twitter"></i>
                </a>
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-instagram"></i>
                </a>
                <a className="btn btn-light btn-md-square me-0" href="#">
                  <i className="fab fa-linkedin-in"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="row g-5">
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h3 className="text-white mb-4">
                  <i className="fas fa-bolt text-primary me-3"></i>ElectraGrid
                </h3>
                <p className="mb-3">
                  ElectraGrid delivers innovative electricity solutions and
                  energy management systems to power your business and home with
                  reliability and sustainability.
                </p>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Quick Links</h4>
                <a href="/">Home</a>
                <a href="/about">About Us</a>
                <a href="/services">Services</a>
                <a href="/projects">Projects</a>
                <a href="/contact">Contact Us</a>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Our Services</h4>
                <a href="/services">Smart Energy Management</a>
                <a href="/services">Electrical Installations</a>
                <a href="/services">Backup Power Solutions</a>
                <a href="/services">Energy Monitoring</a>
                <a href="/services">Sustainable Energy</a>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Contact Info</h4>
                <a href="#">
                  <i className="fa fa-map-marker-alt text-primary me-2"></i>
                  456 Energy Avenue, New York, USA
                </a>
                <a href="mailto:info@electragrid.com">
                  <i className="fas fa-envelope text-primary me-2"></i>
                  info@electragrid.com
                </a>
                <a href="tel:+1234567890">
                  <i className="fas fa-phone text-primary me-2"></i>
                  +1 234 567 890
                </a>
                <a href="tel:+1234567891" className="mb-3">
                  <i className="fas fa-print text-primary me-2"></i>
                  +1 234 567 891
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>


      <a href="#" className="btn btn-primary btn-lg-square back-to-top">
        <i className="fa fa-arrow-up"></i>
      </a>
    </>
  );
}
export default NotFound;