// src/pages/About.js
import React from "react";
import { Helmet } from "react-helmet";
import ProjectSection from "./components/ProjectSection";

function About() {
  return (
    <>
        <Helmet>
            <title>About ElectraGrid | Leading Electrical Service Provider</title>
            <meta name="description" content="Learn about ElectraGrid, your partner in innovative electrical solutions and energy management systems." />
            <meta name="keywords" content="ElectraGrid, electrical solutions, energy management, smart grid, sustainable energy" />
            <meta name="author" content="ElectraGrid Team" />
            <meta property="og:title" content="About Us - ElectraGrid" />
            <meta property="og:description" content="Discover how ElectraGrid delivers smart and reliable electrical solutions for residential, commercial, and industrial clients." />
            <meta property="og:image" content="https://www.electragrid.com/img/about-1.jpg" />
            <meta property="og:url" content="https://www.electragrid.com/about" />
            <meta property="og:type" content="website" />
            <meta name="twitter:card" content="summary_large_image" />
            <meta name="twitter:title" content="About Us - ElectraGrid" />
            <meta name="twitter:description" content="Learn about ElectraGrid, your partner in innovative electrical solutions and energy management systems." />
            <meta name="twitter:image" content="https://www.electragrid.com/img/about-1.jpg" />
            <meta name="twitter:site" content="@ElectraGrid" />
            <meta name="twitter:creator" content="@ElectraGrid" />
            <link rel="canonical" href="https://www.electragrid.com/about" />
        </Helmet>

       {/* <!-- Navbar & Hero Start --> */}
       <div className="container-fluid header-top">
        <div className="container d-flex align-items-center">
          <div className="d-flex align-items-center h-100">
            <a href="#" className="navbar-brand" style={{ height: "125px" }}>
              <h1 className="text-primary mb-0">
                <i className="fas fa-bolt"></i> ElectraGrid
              </h1>
              {/* <img src="img/logo.png" alt="Logo" /> */}
            </a>
          </div>
          <div className="w-100 h-100">
            <div
              className="topbar px-0 py-2 d-none d-lg-block"
              style={{ height: "45px" }}
            >
              <div className="row gx-0 align-items-center">
                <div className="col-lg-8 text-center text-lg-center mb-lg-0">
                  <div className="d-flex flex-wrap">
                    <div className="border-end border-primary pe-3">
                      <a href="/contact" className="text-muted small">
                        <i className="fas fa-map-marker-alt text-primary me-2"></i>
                        Find A Location
                      </a>
                    </div>
                    <div className="ps-3">
                      <a
                        href="mailto:example@gmail.com"
                        className="text-muted small"
                      >
                        <i className="fas fa-envelope text-primary me-2"></i>
                        example@gmail.com
                      </a>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 text-center text-lg-end">
                  <div className="d-flex justify-content-end">
                    <div className="d-flex border-end border-primary pe-3">
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-facebook-f"></i>
                      </a>
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-twitter"></i>
                      </a>
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-instagram"></i>
                      </a>
                      <a className="btn p-0 text-primary me-0" href="#">
                        <i className="fab fa-linkedin-in"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="nav-bar px-0 py-lg-0" style={{ height: "80px" }}>
              <nav className="navbar navbar-expand-lg navbar-light d-flex justify-content-lg-end">
                <a href="/" className="navbar-brand-2">
                  <h1 className="text-primary mb-0">
                    <i className="fas fa-bolt"></i> ElectraGrid
                  </h1>
                  {/* <img src="img/logo.png" alt="Logo" /> */}
                </a>
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarCollapse"
                >
                  <span className="fa fa-bars"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarCollapse">
                  <div className="navbar-nav mx-0 mx-lg-auto bg-white">
                    <a href="/" className="nav-item nav-link">
                      Home
                    </a>
                    <a href="/about" className="nav-item nav-link active">
                      About
                    </a>
                    <a href="/services" className="nav-item nav-link">
                      Services
                    </a>
                    <a href="/blog" className="nav-item nav-link">
                      Blog
                    </a>
                    <a href="/project" className="nav-item nav-link">
                      Projects
                    </a>
                    <a href="/contact" className="nav-item nav-link">
                      Contact
                    </a>
                    <div className="nav-btn ps-3">
                      <button
                        className="btn-search btn btn-primary btn-md-square mt-2 mt-lg-0 mb-4 mb-lg-0 flex-shrink-0"
                        data-bs-toggle="modal"
                        data-bs-target="#searchModal"
                      >
                        <i className="fas fa-search"></i>
                      </button>
                      <a
                        href="/contact"
                        className="btn btn-primary py-2 px-4 ms-0 ms-lg-3"
                      >
                        {" "}
                        Get Solution
                      </a>
                    </div>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Navbar & Hero End -->

        <!-- Modal Search Start --> */}
      <div
        className="modal fade"
        id="searchModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-fullscreen">
          <div className="modal-content rounded-0">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Search by keyword
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body d-flex align-items-center bg-primary">
              <div className="input-group w-75 mx-auto d-flex">
                <input
                  type="search"
                  className="form-control p-3"
                  placeholder="keywords"
                  aria-describedby="search-icon-1"
                />
                <span
                  id="search-icon-1"
                  className="btn bg-light border nput-group-text p-3"
                >
                  <i className="fa fa-search"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Modal Search End -->*/}

      {/* <!-- Header Start --> */}
      <div className="container-fluid bg-breadcrumb">
        <div
          className="container text-center py-5"
          style={{ maxWidth: "900px" }}
        >
          <h4
            className="text-white display-4 mb-4 wow fadeInDown"
            data-wow-delay="0.1s"
          >
            About Us
          </h4>
          <ol
            className="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown"
            data-wow-delay="0.3s"
          >
            <li className="breadcrumb-item">
              <a href="/">Home</a>
            </li>
            <li className="breadcrumb-item active text-primary">About</li>
          </ol>
        </div>
      </div>
      {/* <!-- Header End --> */}

      {/* <!-- About Start --> */}

      <div className="container-fluid about py-5">
        <div className="container py-5">
          <div className="row g-5">
            <div className="col-lg-7 wow fadeInLeft" data-wow-delay="0.2s">
              <div className="h-100">
                <h4 className="text-primary">About ElectraGrid</h4>
                <h1 className="display-4 mb-4">
                  Delivering Smart and Reliable Electrical Solutions
                </h1>
                <div className="row g-4 mb-4">
                  <div className="col-md-6">
                    <a href="tel:+01234567890" className="d-flex">
                      <span className="fas fa-bolt fa-3x me-3"></span>
                      <h4 className="mb-0">Emergency Power Solutions</h4>
                    </a>
                  </div>
                  <div className="col-md-6">
                    <a href="tel:+01234567890" className="d-flex">
                      <span className="fas fa-network-wired fa-3x me-3"></span>
                      <h4 className="mb-0">Smart Electrical Systems</h4>
                    </a>
                  </div>
                </div>
                <p className="mb-4">
                  At ElectraGrid, we specialize in designing and delivering
                  innovative electrical solutions that ensure efficiency,
                  safety, and sustainable power for residential, commercial, and
                  industrial clients. With decades of expertise, we transform
                  how energy powers your world.
                </p>
                <div className="text-dark mb-4">
                  <p className="fs-5">
                    <span className="fa fa-check text-primary me-2"></span>
                    Expert design and installation of modern electrical
                    networks.
                  </p>
                  <p className="fs-5">
                    <span className="fa fa-check text-primary me-2"></span>
                    Sustainable and energy-efficient power solutions.
                  </p>
                  <p className="fs-5">
                    <span className="fa fa-check text-primary me-2"></span>
                    Comprehensive protection for electrical systems and devices.
                  </p>
                </div>
                <a
                  className="btn btn-primary py-3 px-4 px-md-5 ms-2"
                  href="/contact"
                >
                  Contact us
                </a>
              </div>
            </div>
            <div className="col-lg-5 wow fadeInRight" data-wow-delay="0.2s">
              <div className="position-relative h-100">
                <img
                  src="img/about-1.jpg"
                  className="img-fluid w-100 h-100"
                  style={{ objectFit: "cover" }}
                  alt="About ElectraGrid"
                />
                <div className="bg-white">
                  <div
                    className="position-absolute pt-3 bg-white"
                    style={{ width: "50%", left: 0, bottom: 0 }}
                  >
                    <div className="bg-primary p-4">
                      <h4 className="display-2 mb-0">25+</h4>
                      <p className="text-white fs-5 mb-0">
                        Years of Excellence
                      </p>
                    </div>
                  </div>
                  <div
                    className="position-absolute p-3 bg-white pb-0 pe-0"
                    style={{ width: "50%", right: 0, bottom: 0 }}
                  >
                    <img
                      src="img/about-2.jpg"
                      className="img-fluid"
                      alt="ElectraGrid Work"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- About End -->


        <!-- Banner Start --> */}
      <div
        className="container-fluid banner py-5 wow zoomIn"
        data-wow-delay="0.2s"
      >
        <div className="banner-design-1"></div>
        <div className="banner-design-2"></div>
        <div className="container py-5">
          <div className="row g-5">
            <div className="col-lg-8">
              <div className="">
                <h4 className="text-white">Contact With Me</h4>
                <h1 className="display-4 text-white mb-0">
                  We provide professional electric services for our customer
                </h1>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="d-flex align-items-center justify-content-lg-end h-100">
                <a className="btn btn-primary py-3 px-4 px-md-5 ms-2" href="/contact">
                  EXPLORE MORE
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Banner End --> */}

      {/* <!-- Projects Start --> */}
      <div>
        <ProjectSection />
      </div>
      {/* <!-- Projects End --> */}

      {/* <!-- Testimonial Start --> */}
      <div className="container-fluid testimonial bg-dark py-5">
        <div className="container py-5">
          <div className="row g-5">
            <div
              className="col-lg-6 col-xl-5 wow fadeInUp"
              data-wow-delay="0.2s"
            >
              <h4 className="text-primary">Testimonials</h4>
              <h1 className="display-4 text-white mb-4">
                What Our Clients Say About ElectraGrid
              </h1>
              <p className="mb-4 text-light">
                Our commitment to excellence in electrical infrastructure and
                power solutions speaks through our customers. Here's what they
                have to say about our services.
              </p>
              <a className="btn btn-light py-3 px-5" href="#">
                View All Reviews
              </a>
            </div>
            <div
              className="col-lg-6 col-xl-7 wow fadeInUp"
              data-wow-delay="0.4s"
            >
              <div className="owl-carousel testimonial-carousel">
                <div className="testimonial-item">
                  <div className="testimonial-quote">
                    <i className="fa fa-quote-right fa-2x"></i>
                  </div>
                  <div className="testimonial-inner p-4">
                    <img
                      src="img/testimonial-1.jpg"
                      className="img-fluid"
                      alt="Aamir Riaz"
                    />
                    <div className="ms-4">
                      <h4>Aamir Riaz</h4>
                      <p>Facility Manager, Metro Systems</p>
                      <div className="d-flex text-primary">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star text-body"></i>
                      </div>
                    </div>
                  </div>
                  <div className="customer-text p-4">
                    <p className="mb-0 text-light">
                      ElectraGrid delivered our energy project on time and
                      exceeded performance expectations. Truly reliable and
                      professional in every way.
                    </p>
                  </div>
                </div>

                <div className="testimonial-item">
                  <div className="testimonial-quote">
                    <i className="fa fa-quote-right fa-2x"></i>
                  </div>
                  <div className="testimonial-inner p-4">
                    <img
                      src="img/testimonial-2.jpg"
                      className="img-fluid"
                      alt="Sana Khalid"
                    />
                    <div className="ms-4">
                      <h4>Sana Khalid</h4>
                      <p>Operations Lead, EcoSpark</p>
                      <div className="d-flex text-primary">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star text-body"></i>
                      </div>
                    </div>
                  </div>
                  <div className="customer-text p-4">
                    <p className="mb-0 text-light">
                      Their smart grid integration and technical team were
                      outstanding. We felt confident every step of the way with
                      ElectraGrid onboard.
                    </p>
                  </div>
                </div>

                {/* <div className="testimonial-item">
                  <div className="testimonial-quote">
                    <i className="fa fa-quote-right fa-2x"></i>
                  </div>
                  <div className="testimonial-inner p-4">
                    <img
                      src="img/testimonial-3.jpg"
                      className="img-fluid"
                      alt="Tahir Mehmood"
                    />
                    <div className="ms-4">
                      <h4>Tahir Mehmood</h4>
                      <p>Project Engineer, VoltEdge</p>
                      <div className="d-flex text-primary">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                      </div>
                    </div>
                  </div>
                  <div className="customer-text p-4">
                    <p className="mb-0 text-light">
                      We partnered with ElectraGrid for a large-scale electrical
                      project and were amazed by their precision, support, and
                      advanced solutions.
                    </p>
                  </div>
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Testimonial End --> */}

      {/* <!-- FAQ Start --> */}
      <div className="container-fluid faq-section bg-light py-5">
        <div className="container py-5">
          <div className="row g-5">
            <div className="col-lg-6 wow fadeInLeft" data-wow-delay="0.2s">
              <h4 className="text-primary">Frequently Asked Questions</h4>
              <h1 className="display-4 mb-4">
                Answers About ElectraGrid's Services
              </h1>
              <p className="mb-4">
                Learn more about how ElectraGrid can empower your energy
                solutions. Here are some of the most common questions our
                customers ask us.
              </p>
              <a className="btn btn-primary py-3 px-5" href="tel:+01234567890">
                Have Any Questions?
              </a>
            </div>
            <div className="col-xl-6 wow fadeInRight" data-wow-delay="0.4s">
              <div className="h-100">
                <div className="accordion" id="accordionExample">
                  <div className="accordion-item">
                    <h2 className="accordion-header" id="headingOne">
                      <button
                        className="accordion-button"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseOne"
                        aria-expanded="true"
                        aria-controls="collapseOne"
                      >
                        Q: How do I sign up for ElectraGrid services?
                      </button>
                    </h2>
                    <div
                      id="collapseOne"
                      className="accordion-collapse collapse show active"
                      aria-labelledby="headingOne"
                      data-bs-parent="#accordionExample"
                    >
                      <div className="accordion-body">
                        A: Signing up is easy! Visit our website and click on
                        the “Get Started” button, or contact our support team
                        directly. We'll guide you through choosing the right
                        plan for your needs.
                      </div>
                    </div>
                  </div>
                  <div className="accordion-item">
                    <h2 className="accordion-header" id="headingTwo">
                      <button
                        className="accordion-button collapsed"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseTwo"
                        aria-expanded="false"
                        aria-controls="collapseTwo"
                      >
                        Q: What types of energy solutions does ElectraGrid
                        offer?
                      </button>
                    </h2>
                    <div
                      id="collapseTwo"
                      className="accordion-collapse collapse"
                      aria-labelledby="headingTwo"
                      data-bs-parent="#accordionExample"
                    >
                      <div className="accordion-body">
                        A: ElectraGrid provides a range of services, including
                        smart grid integration, energy monitoring systems,
                        sustainable energy solutions, and emergency backup power
                        for businesses and industries.
                      </div>
                    </div>
                  </div>
                  <div className="accordion-item">
                    <h2 className="accordion-header" id="headingThree">
                      <button
                        className="accordion-button collapsed"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseThree"
                        aria-expanded="false"
                        aria-controls="collapseThree"
                      >
                        Q: How does ElectraGrid's billing and payment work?
                      </button>
                    </h2>
                    <div
                      id="collapseThree"
                      className="accordion-collapse collapse"
                      aria-labelledby="headingThree"
                      data-bs-parent="#accordionExample"
                    >
                      <div className="accordion-body">
                        A: We offer flexible billing options, including online
                        payments, automatic bank transfers, and monthly or
                        annual billing cycles. You can easily manage your
                        account through our secure online portal.
                      </div>
                    </div>
                  </div>
                  <div className="accordion-item">
                    <h2 className="accordion-header" id="headingFour">
                      <button
                        className="accordion-button collapsed"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseFour"
                        aria-expanded="false"
                        aria-controls="collapseFour"
                      >
                        Q: Can I monitor my energy usage with ElectraGrid?
                      </button>
                    </h2>
                    <div
                      id="collapseFour"
                      className="accordion-collapse collapse"
                      aria-labelledby="headingFour"
                      data-bs-parent="#accordionExample"
                    >
                      <div className="accordion-body">
                        A: Absolutely! Our advanced monitoring tools let you
                        track your real-time energy consumption, analyze trends,
                        and receive reports to help you optimize energy usage
                        and reduce costs.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Footer Start --> */}
      <div
        className="container-fluid footer bg-dark py-5 wow fadeIn"
        data-wow-delay="0.2s"
      >
        <div className="container py-5">
          <div className="row g-5 mb-5 align-items-center">
            <div className="col-lg-7">
              <div className="position-relative mx-auto">
                <input
                  className="form-control w-100 py-3 ps-4 pe-5"
                  type="text"
                  placeholder="Enter your email to subscribe"
                />
                <button
                  type="button"
                  className="btn btn-primary position-absolute top-0 end-0 py-2 px-4 mt-2 me-2"
                >
                  Subscribe
                </button>
              </div>
            </div>
            <div className="col-lg-5">
              <div className="d-flex align-items-center justify-content-center justify-content-lg-end">
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-twitter"></i>
                </a>
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-instagram"></i>
                </a>
                <a className="btn btn-light btn-md-square me-0" href="#">
                  <i className="fab fa-linkedin-in"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="row g-5">
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h3 className="text-white mb-4">
                  <i className="fas fa-bolt text-primary me-3"></i>ElectraGrid
                </h3>
                <p className="mb-3">
                  ElectraGrid delivers innovative electricity solutions and
                  energy management systems to power your business and home with
                  reliability and sustainability.
                </p>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Quick Links</h4>
                <a href="/">Home</a>
                <a href="/about">About Us</a>
                <a href="/services">Services</a>
                <a href="/projects">Projects</a>
                <a href="/contact">Contact Us</a>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Our Services</h4>
                <a href="/services">Smart Energy Management</a>
                <a href="/services">Electrical Installations</a>
                <a href="/services">Backup Power Solutions</a>
                <a href="/services">Energy Monitoring</a>
                <a href="/services">Sustainable Energy</a>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Contact Info</h4>
                <a href="#">
                  <i className="fa fa-map-marker-alt text-primary me-2"></i>
                  456 Energy Avenue, New York, USA
                </a>
                <a href="mailto:info@electragrid.com">
                  <i className="fas fa-envelope text-primary me-2"></i>
                  info@electragrid.com
                </a>
                <a href="tel:+1234567890">
                  <i className="fas fa-phone text-primary me-2"></i>
                  +1 234 567 890
                </a>
                <a href="tel:+1234567891" className="mb-3">
                  <i className="fas fa-print text-primary me-2"></i>
                  +1 234 567 891
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <a href="#" className="btn btn-primary btn-lg-square back-to-top">
        <i className="fa fa-arrow-up"></i>
      </a>
    </>
  );
}

export default About;
