import React from "react";
import { Helmet } from "react-helmet";
// import ServicesSection from './components/ServicesSection';

function Blog() {
  return (
    <>
      <Helmet>
        <title>
          ElectraGrid Blog | Tips and Insights on Electrical Innovations
        </title>
        <meta
          name="description"
          content="Stay updated with the latest news and insights from ElectraGrid. Explore our blog for expert articles on electricity solutions, energy management, and industry trends."
        />
        <meta
          name="keywords"
          content="ElectraGrid, blog, electricity solutions, energy management, industry trends, electrical services, news"
        />
        <link rel="canonical" href="https://www.electragrid.com/blog" />
        <meta property="og:title" content="ElectraGrid - Blog" />
        <meta
          property="og:description"
          content="Stay updated with the latest news and insights from ElectraGrid. Explore our blog for expert articles on electricity solutions, energy management, and industry trends."
        />
        <meta property="og:url" content="https://www.electragrid.com/blog" />
        <meta property="og:type" content="website" />
        <meta
          property="og:image"
          content="https://www.electragrid.com/img/blog-image.jpg"
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="ElectraGrid - Blog" />
        <meta
          name="twitter:description"
          content="Stay updated with the latest news and insights from ElectraGrid. Explore our blog for expert articles on electricity solutions, energy management, and industry trends."
        />
        <meta
          name="twitter:image"
          content="https://www.electragrid.com/img/blog-image.jpg"
        />
      </Helmet>

      {/* <!-- Navbar & Hero Start --> */}
      <div className="container-fluid header-top">
        <div className="container d-flex align-items-center">
          <div className="d-flex align-items-center h-100">
            <a href="#" className="navbar-brand" style={{ height: "125px" }}>
              <h1 className="text-primary mb-0">
                <i className="fas fa-bolt"></i> ElectraGrid
              </h1>
              {/* <img src="img/logo.png" alt="Logo" /> */}
            </a>
          </div>
          <div className="w-100 h-100">
            <div
              className="topbar px-0 py-2 d-none d-lg-block"
              style={{ height: "45px" }}
            >
              <div className="row gx-0 align-items-center">
                <div className="col-lg-8 text-center text-lg-center mb-lg-0">
                  <div className="d-flex flex-wrap">
                    <div className="border-end border-primary pe-3">
                      <a href="/contact" className="text-muted small">
                        <i className="fas fa-map-marker-alt text-primary me-2"></i>
                        Find A Location
                      </a>
                    </div>
                    <div className="ps-3">
                      <a
                        href="mailto:example@gmail.com"
                        className="text-muted small"
                      >
                        <i className="fas fa-envelope text-primary me-2"></i>
                        example@gmail.com
                      </a>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 text-center text-lg-end">
                  <div className="d-flex justify-content-end">
                    <div className="d-flex border-end border-primary pe-3">
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-facebook-f"></i>
                      </a>
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-twitter"></i>
                      </a>
                      <a className="btn p-0 text-primary me-3" href="#">
                        <i className="fab fa-instagram"></i>
                      </a>
                      <a className="btn p-0 text-primary me-0" href="#">
                        <i className="fab fa-linkedin-in"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="nav-bar px-0 py-lg-0" style={{ height: "80px" }}>
              <nav className="navbar navbar-expand-lg navbar-light d-flex justify-content-lg-end">
                <a href="/" className="navbar-brand-2">
                  <h1 className="text-primary mb-0">
                    <i className="fas fa-bolt"></i> ElectraGrid
                  </h1>
                  {/* <img src="img/logo.png" alt="Logo" /> */}
                </a>
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarCollapse"
                >
                  <span className="fa fa-bars"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarCollapse">
                  <div className="navbar-nav mx-0 mx-lg-auto bg-white">
                    <a href="/" className="nav-item nav-link">
                      Home
                    </a>
                    <a href="/about" className="nav-item nav-link">
                      About
                    </a>
                    <a href="/services" className="nav-item nav-link">
                      Services
                    </a>
                    <a href="/blog" className="nav-item nav-link active">
                      Blog
                    </a>
                    <a href="/project" className="nav-item nav-link">
                      Projects
                    </a>
                    <a href="/contact" className="nav-item nav-link">
                      Contact
                    </a>
                    <div className="nav-btn ps-3">
                      <button
                        className="btn-search btn btn-primary btn-md-square mt-2 mt-lg-0 mb-4 mb-lg-0 flex-shrink-0"
                        data-bs-toggle="modal"
                        data-bs-target="#searchModal"
                      >
                        <i className="fas fa-search"></i>
                      </button>
                      <a
                        href="/contact"
                        className="btn btn-primary py-2 px-4 ms-0 ms-lg-3"
                      >
                        {" "}
                        Get Solution
                      </a>
                    </div>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Navbar & Hero End -->

        <!-- Modal Search Start --> */}
      <div
        className="modal fade"
        id="searchModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-fullscreen">
          <div className="modal-content rounded-0">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Search by keyword
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body d-flex align-items-center bg-primary">
              <div className="input-group w-75 mx-auto d-flex">
                <input
                  type="search"
                  className="form-control p-3"
                  placeholder="keywords"
                  aria-describedby="search-icon-1"
                />
                <span
                  id="search-icon-1"
                  className="btn bg-light border nput-group-text p-3"
                >
                  <i className="fa fa-search"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Modal Search End -->*/}

      {/* <!-- Header Start --> */}
      <div className="container-fluid bg-breadcrumb">
        <div
          className="container text-center py-5"
          style={{ maxWidth: "900px" }}
        >
          <h4
            className="text-white display-4 mb-4 wow fadeInDown"
            data-wow-delay="0.1s"
          >
            Blogs
          </h4>
          <ol
            className="breadcrumb d-flex justify-content-center mb-0 wow fadeInDown"
            data-wow-delay="0.3s"
          >
            <li className="breadcrumb-item">
              <a href="/">Home</a>
            </li>
            <li className="breadcrumb-item active text-primary">Blogs</li>
          </ol>
        </div>
      </div>
      {/* <!-- Header End --> */}

      {/* <!-- Blog Start --> */}
      <div className="container-fluid blog py-5">
        <div className="container py-5">
          <div
            className="d-flex flex-column mx-auto text-center mb-5 wow fadeInUp"
            data-wow-delay="0.2s"
            style={{ maxWidth: "800px" }}
          >
            <h4 className="text-primary">Our Blog</h4>
            <h1 className="display-4 mb-4">ElectraGrid News & Insights</h1>
            <p className="mb-0">
              Stay informed with ElectraGrid’s latest updates, energy tips, and
              industry innovations. Explore how smart electricity solutions
              power the future.
            </p>
          </div>

          {/* Blog Posts */}
          <div className="row g-4">
            {/* Post 1 */}
            <div className="col-lg-4 wow fadeInUp" data-wow-delay="0.2s">
              <div className="blog-item">
                <div className="blog-img">
                  <img
                    src="img/commercial-1.jpg"
                    className="img-fluid w-100"
                    alt="Smart Grid Innovations"
                  />
                </div>
                <div className="blog-heading ms-4">
                  <a href="#" className="h4 mb-0 p-4">
                    Empowering Tomorrow with Smart Grids
                  </a>
                </div>
                <div className="blog-content bg-light p-4">
                  <div className="d-flex justify-content-between mb-4">
                    <p className="mb-0 small">
                      <i className="fa fa-calendar me-2"></i> April 2, 2025
                    </p>
                    <p className="mb-0 small">
                      <i className="fa fa-tag me-2"></i> Energy Trends
                    </p>
                  </div>
                  <p className="mb-4">
                    Discover how ElectraGrid is transforming electrical networks
                    with smart grid technology to improve reliability,
                    automation, and efficiency.
                  </p>
                  <a className="btn btn-primary py-2 px-4" href="#">
                    Learn More
                  </a>
                </div>
              </div>
            </div>

            {/* Post 2 */}
            <div className="col-lg-4 wow fadeInUp" data-wow-delay="0.4s">
              <div className="blog-item">
                <div className="blog-img">
                  <img
                    src="img/commercial-2.jpg"
                    className="img-fluid w-100"
                    alt="Sustainable Energy Solutions"
                  />
                </div>
                <div className="blog-heading ms-4">
                  <a href="#" className="h4 mb-0 p-4">
                    Sustainable Power for Modern Living
                  </a>
                </div>
                <div className="blog-content bg-light p-4">
                  <div className="d-flex justify-content-between mb-4">
                    <p className="mb-0 small">
                      <i className="fa fa-calendar me-2"></i> April 2, 2025
                    </p>
                    <p className="mb-0 small">
                      <i className="fa fa-tag me-2"></i> Green Energy
                    </p>
                  </div>
                  <p className="mb-4">
                    Learn how ElectraGrid delivers eco-friendly electrical
                    systems to support sustainability, lower energy costs, and
                    protect the environment.
                  </p>
                  <a className="btn btn-primary py-2 px-4" href="#">
                    Learn More
                  </a>
                </div>
              </div>
            </div>

            {/* Post 3 */}
            <div className="col-lg-4 wow fadeInUp" data-wow-delay="0.6s">
              <div className="blog-item">
                <div className="blog-img">
                  <img
                    src="img/commercial-3.jpg"
                    className="img-fluid w-100"
                    alt="Home Automation Power"
                  />
                </div>
                <div className="blog-heading ms-4">
                  <a href="#" className="h4 mb-0 p-4">
                    Powering Smart Homes with ElectraGrid
                  </a>
                </div>
                <div className="blog-content bg-light p-4">
                  <div className="d-flex justify-content-between mb-4">
                    <p className="mb-0 small">
                      <i className="fa fa-calendar me-2"></i> April 2, 2025
                    </p>
                    <p className="mb-0 small">
                      <i className="fa fa-tag me-2"></i> Smart Living
                    </p>
                  </div>
                  <p className="mb-4">
                    From lighting control to energy monitoring, explore how
                    ElectraGrid empowers homeowners with intelligent, efficient
                    electrical systems.
                  </p>
                  <a className="btn btn-primary py-2 px-4" href="#">
                    Learn More
                  </a>
                </div>
              </div>
            </div>
{/* Post 4 */}
<div className="col-lg-4 wow fadeInUp" data-wow-delay="0.2s">
  <div className="blog-item">
    <div className="blog-img">
      <img src="img/industrial-1.jpg" className="img-fluid w-100" alt="Energy Efficiency Strategies" />
    </div>
    <div className="blog-heading ms-4">
      <a href="#" className="h4 mb-0 p-4">Maximizing Energy Efficiency in Industries</a>
    </div>
    <div className="blog-content bg-light p-4">
      <div className="d-flex justify-content-between mb-4">
        <p className="mb-0 small"><i className="fa fa-calendar me-2"></i> April 5, 2025</p>
        <p className="mb-0 small"><i className="fa fa-tag me-2"></i> Industrial Power</p>
      </div>
      <p className="mb-4">
        ElectraGrid reveals smart approaches to reduce energy waste and enhance operational efficiency in manufacturing and industrial sectors.
      </p>
      <a className="btn btn-primary py-2 px-4" href="#">Learn More</a>
    </div>
  </div>
</div>

{/* Post 5 */}
<div className="col-lg-4 wow fadeInUp" data-wow-delay="0.4s">
  <div className="blog-item">
    <div className="blog-img">
      <img src="img/industrial-2.jpg" className="img-fluid w-100" alt="Commercial Electrical Safety" />
    </div>
    <div className="blog-heading ms-4">
      <a href="#" className="h4 mb-0 p-4">Essential Tips for Commercial Electrical Safety</a>
    </div>
    <div className="blog-content bg-light p-4">
      <div className="d-flex justify-content-between mb-4">
        <p className="mb-0 small"><i className="fa fa-calendar me-2"></i> April 8, 2025</p>
        <p className="mb-0 small"><i className="fa fa-tag me-2"></i> Safety Tips</p>
      </div>
      <p className="mb-4">
        Stay safe with ElectraGrid’s expert advice on maintaining secure, compliant electrical systems in commercial spaces and offices.
      </p>
      <a className="btn btn-primary py-2 px-4" href="#">Learn More</a>
    </div>
  </div>
</div>

{/* Post 6 */}
<div className="col-lg-4 wow fadeInUp" data-wow-delay="0.6s">
  <div className="blog-item">
    <div className="blog-img">
      <img src="img/industrial-3.jpg" className="img-fluid w-100" alt="Home Electrical Innovations" />
    </div>
    <div className="blog-heading ms-4">
      <a href="#" className="h4 mb-0 p-4">Innovations Powering Modern Homes</a>
    </div>
    <div className="blog-content bg-light p-4">
      <div className="d-flex justify-content-between mb-4">
        <p className="mb-0 small"><i className="fa fa-calendar me-2"></i> April 10, 2025</p>
        <p className="mb-0 small"><i className="fa fa-tag me-2"></i> Smart Homes</p>
      </div>
      <p className="mb-4">
        Discover how ElectraGrid integrates cutting-edge technology for smart homes, offering safety, convenience, and energy savings for homeowners.
      </p>
      <a className="btn btn-primary py-2 px-4" href="#">Learn More</a>
    </div>
  </div>
</div>


          </div>
        </div>
      </div>

      {/* <!-- Blog End --> */}

      {/* <!-- Footer Start --> */}
      <div
        className="container-fluid footer bg-dark py-5 wow fadeIn"
        data-wow-delay="0.2s"
      >
        <div className="container py-5">
          <div className="row g-5 mb-5 align-items-center">
            <div className="col-lg-7">
              <div className="position-relative mx-auto">
                <input
                  className="form-control w-100 py-3 ps-4 pe-5"
                  type="text"
                  placeholder="Enter your email to subscribe"
                />
                <button
                  type="button"
                  className="btn btn-primary position-absolute top-0 end-0 py-2 px-4 mt-2 me-2"
                >
                  Subscribe
                </button>
              </div>
            </div>
            <div className="col-lg-5">
              <div className="d-flex align-items-center justify-content-center justify-content-lg-end">
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-twitter"></i>
                </a>
                <a className="btn btn-light btn-md-square me-3" href="#">
                  <i className="fab fa-instagram"></i>
                </a>
                <a className="btn btn-light btn-md-square me-0" href="#">
                  <i className="fab fa-linkedin-in"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="row g-5">
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h3 className="text-white mb-4">
                  <i className="fas fa-bolt text-primary me-3"></i>ElectraGrid
                </h3>
                <p className="mb-3">
                  ElectraGrid delivers innovative electricity solutions and
                  energy management systems to power your business and home with
                  reliability and sustainability.
                </p>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Quick Links</h4>
                <a href="/">Home</a>
                <a href="/about">About Us</a>
                <a href="/services">Services</a>
                <a href="/projects">Projects</a>
                <a href="/contact">Contact Us</a>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Our Services</h4>
                <a href="/services">Smart Energy Management</a>
                <a href="/services">Electrical Installations</a>
                <a href="/services">Backup Power Solutions</a>
                <a href="/services">Energy Monitoring</a>
                <a href="/services">Sustainable Energy</a>
              </div>
            </div>
            <div className="col-md-6 col-lg-6 col-xl-3">
              <div className="footer-item d-flex flex-column">
                <h4 className="text-white mb-4">Contact Info</h4>
                <a href="#">
                  <i className="fa fa-map-marker-alt text-primary me-2"></i>
                  456 Energy Avenue, New York, USA
                </a>
                <a href="mailto:info@electragrid.com">
                  <i className="fas fa-envelope text-primary me-2"></i>
                  info@electragrid.com
                </a>
                <a href="tel:+1234567890">
                  <i className="fas fa-phone text-primary me-2"></i>
                  +1 234 567 890
                </a>
                <a href="tel:+1234567891" className="mb-3">
                  <i className="fas fa-print text-primary me-2"></i>
                  +1 234 567 891
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <a href="#" className="btn btn-primary btn-lg-square back-to-top">
        <i className="fa fa-arrow-up"></i>
      </a>
    </>
  );
}
export default Blog;
