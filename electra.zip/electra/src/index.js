import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';  // Your own custom styles (optional)
import App from './App';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import '@fortawesome/fontawesome-free/css/all.min.css';
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/autoplay";


import $ from 'jquery';


// Make jQuery global
window.$ = $;
window.jQuery = $;


// Then import owl carousel AFTER jQuery is defined globally

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
