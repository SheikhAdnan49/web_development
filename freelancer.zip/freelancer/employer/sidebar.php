<div class="menu_dashboard overflow-hidden flex-shrink-0 min-[320px]:w-[280px] w-[80vw] h-full bg-white relative z-[2] max-lg:hidden">
            <div class="inner scrollbar_custom max-h-full py-6 px-3">
                <div class="area">
                    <span class="px-6 text-xs font-semibold text-secondary uppercase">Overviews</span>
                    <ul class="list_link flex flex-col gap-2 mt-2">
                        <li>
                            <a href="employers-dashboard" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-squares-four text-2xl text-secondary"></span>
                                <strong class="text-title">Dashboard</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-messages" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-chats text-2xl text-secondary"></span>
                                <strong class="text-title">Messages</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-bookmarks" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-bookmarks-simple text-2xl text-secondary"></span>
                                <strong class="text-title">My Bookmarks</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-meetings" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-chalkboard-teacher text-2xl text-secondary"></span>
                                <strong class="text-title">Video Meetings</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-alerts-candidate" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background active">
                                <span class="ph-duotone ph-bell text-2xl text-secondary"></span>
                                <strong class="text-title">Alerts Candidate</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-billings" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-hand-coins text-2xl text-secondary"></span>
                                <strong class="text-title">Billings</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-payouts" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-credit-card text-2xl text-secondary"></span>
                                <strong class="text-title">Payouts</strong>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="area mt-6">
                    <span class="px-6 text-xs font-semibold text-secondary uppercase">Management</span>
                    <ul class="list_link flex flex-col gap-2 mt-2">
                        <li>
                            <a href="employers-applicants-jobs" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-notepad text-2xl text-secondary"></span>
                                <strong class="text-title">Applicants Jobs</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-jobs" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-briefcase text-2xl text-secondary"></span>
                                <strong class="text-title">My Jobs</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-choose-job-package" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-file-arrow-up text-2xl text-secondary"></span>
                                <strong class="text-title">Submit Jobs</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-proposals-projects" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-gavel text-2xl text-secondary"></span>
                                <strong class="text-title">Proposals Projects</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-my-projects" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-newspaper-clipping text-2xl text-secondary"></span>
                                <strong class="text-title">My Projects</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-choose-project-package" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-clock-countdown text-2xl text-secondary"></span>
                                <strong class="text-title">Submit Projects</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-bought-services" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-stack text-2xl text-secondary"></span>
                                <strong class="text-title">Bought Services</strong>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="area mt-6">
                    <span class="px-6 text-xs font-semibold text-secondary uppercase">User</span>
                    <ul class="list_link flex flex-col gap-2 mt-2">
                        <li>
                            <a href="employers-profile" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-user-circle text-2xl text-secondary"></span>
                                <strong class="text-title">My Profile</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-profile-setting" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-read-cv-logo text-2xl text-secondary"></span>
                                <strong class="text-title">Profile Setting</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-my-packages" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-currency-circle-dollar text-2xl text-secondary"></span>
                                <strong class="text-title">My Packages</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-change-passwords" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-lock-key-open text-2xl text-secondary"></span>
                                <strong class="text-title">Change Passwords</strong>
                            </a>
                        </li>
                        <li>
                            <a href="employers-delete-profile" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-trash text-2xl text-secondary"></span>
                                <strong class="text-title">Delete Profile</strong>
                            </a>
                        </li>
                        <li>
                            <a href="login" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph-duotone ph-sign-out text-2xl text-secondary"></span>
                                <strong class="text-title">Log Out</strong>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>