<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body class="lg:overflow-unset">

    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb bg-[#F9F2EC] sm:pt-35 pt-30 pb-15">
        <div class="container flex max-lg:flex-col lg:items-center justify-between gap-7 gap-y-5">
            <div class="employers_info flex flex-wrap sm:gap-7 gap-4 w-full">
                <div class="overflow-hidden flex-shrink-0 sm:w-[100px] w-24 sm:h-[100px] h-24">
                    <img src="../assets/images/company/1.png" alt="company/1" class="employers_avatar w-full h-full object-cover" />
                </div>
                <div class="flex flex-col gap-1">
                    <h4 class="employers_name heading4 -style-1">PrimeEdge Solutions</h4>
                    <div class="flex flex-wrap items-center gap-5 gap-y-1.5 mt-1">
                        <div class="employers_address -style-1 text-secondary">
                            <span class="ph ph-map-pin text-xl"></span>
                            <span class="address align-top">Las Vegas, USA</span>
                        </div>
                        <div class="employers_date text-secondary">
                            <span class="ph ph-calendar-blank text-xl"></span>
                            <span class="date align-top">2 days ago</span>
                        </div>
                    </div>
                    <div class="flex flex-wrap items-center gap-2.5 mt-2">
                        <span class="employers_tag text-button-sm py-2 px-5 border border-line rounded bg-white whitespace-nowrap">2 jobs openings</span>
                        <span class="employers_tag text-button-sm py-2 px-5 border border-line rounded bg-white whitespace-nowrap">4 projects openings</span>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_action flex flex-col max-lg:flex-col-reverse gap-4">
                <div class="flex max-sm:flex-wrap lg:justify-end gap-3">
                    <button class="button_share flex items-center justify-center w-12 h-12 border border-line rounded-full bg-white duration-300 hover:border-black">
                        <span class="ph ph-share-network text-2xl"></span>
                        <ul class="social">
                            <li class="social_item">
                                <a href="https://www.facebook.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-facebook"></span>
                                </a>
                            </li>
                            <li class="social_item">
                                <a href="https://www.linkedin.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-linkedin"></span>
                                </a>
                            </li>
                            <li class="social_item">
                                <a href="https://www.twitter.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-twitter"></span>
                                </a>
                            </li>
                        </ul>
                    </button>
                    <button class="add_wishlist_btn -relative -border w-12">
                        <span class="ph ph-heart text-2xl"></span>
                        <span class="ph-fill ph-heart text-2xl"></span>
                    </button>
                </div>
                <a href="../candidates/candidates-messages" class="message_btn button-main w-fit whitespace-nowrap">Send Message</a>
            </div>
        </div>
    </section>

    <section class="employers_detail lg:py-20 sm:py-14 py-10">
        <div class="container flex max-lg:flex-col gap-y-10">
            <div class="employers_info w-full lg:pr-15">
                <div class="description">
                    <h6 class="heading6">About Company</h6>
                    <div class="flex flex-col gap-3 mt-3">
                        <p class="body2 text-secondary">Are you a User Experience Designer with a track record of delivering intuitive digital experiences that drive results? Are you a strategic storyteller and systems thinker who can concept and craft smart, world-class campaigns across a variety of mediums?</p>
                        <p class="body2 text-secondary">
                            Deloitte's Green Dot Agency is looking to add a Lead User Experience Designer to our experience design team. We want a passionate creative who's inspired by new trends and emerging technologies, and is able to integrate them into memorable user experiences. A problem solver who is entrepreneurial, collaborative, hungry, and humble; can deliver beautifully designed, leading-edge experiences under tight deadlines; and who has demonstrated proven expertise.
                        </p>
                    </div>
                </div>
                <div class="images md:mt-10 mt-7">
                    <div class="video_block flex items-center justify-center relative overflow-hidden rounded-lg">
                        <img src="../assets/images/blog/1.webp" alt="blog/1" class="w-full h-full object-cover" />
                        <button class="btn_open_popup play_btn flex items-center justify-center absolute md:w-16 w-12 md:h-16 h-12 rounded-full bg-red text-white duration-300 hover:bg-white hover:text-red" data-type="modal_video">
                            <span class="ph-fill ph-play text-3xl"></span>
                        </button>
                    </div>
                    <ul class="list_images grid xl:grid-cols-4 lg:grid-cols-2 sm:grid-cols-4 grid-cols-2 gap-4 w-full mt-5">
                        <li class="relative overflow-hidden rounded-lg">
                            <img src="../assets/images/blog/2.webp" alt="blog/2" class="w-full h-full object-cover" />
                        </li>
                        <li class="relative overflow-hidden rounded-lg">
                            <img src="../assets/images/blog/3.webp" alt="blog/3" class="w-full h-full object-cover" />
                        </li>
                        <li class="relative overflow-hidden rounded-lg">
                            <img src="../assets/images/blog/4.webp" alt="blog/4" class="w-full h-full object-cover" />
                        </li>
                        <li class="relative overflow-hidden rounded-lg">
                            <img src="../assets/images/blog/5.webp" alt="blog/5" class="w-full h-full object-cover" />
                        </li>
                    </ul>
                </div>
                <div class="review md:mt-15 mt-8">
                    <div class="heading flex flex-wrap items-center justify-between gap-4">
                        <h5 class="heading5">Customer Review</h5>
                        <a href="#form-review" class="button-main -border">Write Reviews </a>
                    </div>
                    <div class="rating_area flex max-sm:flex-col justify-between gap-y-3 py-6">
                        <div class="flex flex-col items-center justify-center gap-1">
                            <h1 class="heading1 avg_rating">4.8</h1>
                            <div class="flex flex-col items-center gap-2">
                                <ul class="rate flex">
                                    <li class="ph-fill ph-star text-2xl text-yellow"></li>
                                    <li class="ph-fill ph-star text-2xl text-yellow"></li>
                                    <li class="ph-fill ph-star text-2xl text-yellow"></li>
                                    <li class="ph-fill ph-star text-2xl text-yellow"></li>
                                    <li class="ph-fill ph-star-half text-2xl text-yellow"></li>
                                </ul>
                                <span class="total_rating caption1">(1,968 Ratings)</span>
                            </div>
                        </div>
                        <div class="list_rating flex-shrink-0 xl:w-[465px] sm:w-[60%] w-full">
                            <div class="item flex items-center justify-between gap-3">
                                <div class="flex flex-shrink-0 items-center gap-1 min-w-7">
                                    <strong class="text-button-sm">5</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-[70%] h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">70%</strong>
                            </div>
                            <div class="item flex items-center justify-between gap-3 mt-1">
                                <div class="flex flex-shrink-0 items-center gap-1 min-w-7">
                                    <strong class="text-button-sm">4</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-[20%] h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">20%</strong>
                            </div>
                            <div class="item flex items-center justify-between gap-3 mt-1">
                                <div class="flex flex-shrink-0 items-center gap-1 min-w-7">
                                    <strong class="text-button-sm">3</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-[10%] h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">10%</strong>
                            </div>
                            <div class="item flex items-center justify-between gap-3 mt-1">
                                <div class="flex flex-shrink-0 items-center gap-1 min-w-7">
                                    <strong class="text-button-sm">2</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-0 h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">0%</strong>
                            </div>
                            <div class="item flex items-center justify-between gap-3 mt-1">
                                <div class="flex flex-shrink-0 items-center gap-2 min-w-7">
                                    <strong class="text-button-sm">1</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-0 h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">0%</strong>
                            </div>
                        </div>
                    </div>
                    <div class="list_review flex flex-col items-center gap-10 md:pt-10 pt-7 border-t border-line">
                        <ul class="list flex flex-col gap-6">
                            <li class="review_item flex gap-5">
                                <img src="../assets/images/avatar/IMG-13.webp" alt="avatar/IMG-13" class="user_avatar w-15 h-15 flex-shrink-0 rounded-full" />
                                <div class="review_content w-full">
                                    <div class="flex flex-wrap justify-between gap-6 gap-y-3 w-full">
                                        <div class="user_info">
                                            <div class="flex items-center gap-2">
                                                <span class="name heading6">Jeremy L.</span>
                                                <span class="ph-fill ph-check-circle text-lg text-success"></span>
                                            </div>
                                            <span class="date caption1 text-secondary">August 24, 2024</span>
                                            <ul class="review_rate flex mt-1">
                                                <li class="ph-fill ph-star text-yellow"></li>
                                                <li class="ph-fill ph-star text-yellow"></li>
                                                <li class="ph-fill ph-star text-yellow"></li>
                                                <li class="ph-fill ph-star text-yellow"></li>
                                                <li class="ph-fill ph-star text-yellow"></li>
                                            </ul>
                                        </div>
                                        <button class="is_helpful button-main -small -border border-line gap-2 h-fit bg-white text-secondary">
                                            <span class="caption1">Was this helpful?</span>
                                            <span class="ph ph-thumbs-up"></span>
                                        </button>
                                    </div>
                                    <p class="desc mt-4">I really like the logo that Gihan created, and he was very responsive and great to work with. I would recommend him to anyone looking for a logo or graphic design!</p>
                                </div>
                            </li>
                            <li class="review_item flex gap-5">
                                <img src="../assets/images/avatar/IMG-11.webp" alt="avatar/IMG-11" class="user_avatar w-15 h-15 flex-shrink-0 rounded-full" />
                                <div class="review_content w-full">
                                    <div class="flex flex-wrap justify-between gap-6 gap-y-3 w-full">
                                        <div class="user_info">
                                            <div class="flex items-center gap-2">
                                                <span class="name heading6">Alexander P.</span>
                                                <span class="ph-fill ph-check-circle text-lg text-success"></span>
                                            </div>
                                            <span class="date caption1 text-secondary">August 13, 2024</span>
                                            <ul class="review_rate flex mt-1">
                                                <li class="ph-fill ph-star text-yellow"></li>
                                                <li class="ph-fill ph-star text-yellow"></li>
                                                <li class="ph-fill ph-star text-yellow"></li>
                                                <li class="ph-fill ph-star text-yellow"></li>
                                                <li class="ph-fill ph-star text-yellow"></li>
                                            </ul>
                                        </div>
                                        <button class="is_helpful button-main -small -border border-line gap-2 h-fit bg-white text-secondary">
                                            <span class="caption1">Was this helpful?</span>
                                            <span class="ph ph-thumbs-up"></span>
                                        </button>
                                    </div>
                                    <p class="desc mt-4">I really like the logo that Gihan created, and he was very responsive and great to work with. I would recommend him to anyone looking for a logo or graphic design!</p>
                                </div>
                            </li>
                        </ul>
                        <button class="text-button underline duration-300 hover:text-primary">See more reviews (19)</button>
                    </div>
                    <div id="form-review" class="form-review md:pt-10 pt-7">
                        <h6 class="heading6">Leave A comment</h6>
                        <form class="form grid sm:grid-cols-2 gap-4 gap-y-5 mt-6">
                            <div class="name">
                                <label for="username">Name</label>
                                <input class="w-full mt-2 px-4 py-3 border-line rounded-lg" id="username" type="text" placeholder="Your Name" required />
                            </div>
                            <div class="mail">
                                <label for="email">Email</label>
                                <input class="w-full mt-2 px-4 py-3 border-line rounded-lg" id="email" type="email" placeholder="Your Email" required />
                            </div>
                            <div class="col-span-full message">
                                <label for="message">Review</label>
                                <textarea class="border w-full mt-2 px-4 py-3 border-line rounded-lg" id="message" name="message" rows="3" placeholder="Write comment " required></textarea>
                            </div>
                            <div class="col-span-full flex items-start gap-2">
                                <input type="checkbox" id="saveAccount" name="saveAccount" class="mt-1.5" />
                                <label class="" for="saveAccount">Save my name, email, and website in this browser for the next time I comment.</label>
                            </div>
                            <div class="user_rating flex items-center gap-3 col-span-full">
                                <span>Your Rating:</span>
                                <ul class="list_rate flex gap-1">
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="1"></li>
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="2"></li>
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="3"></li>
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="4"></li>
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="5"></li>
                                </ul>
                            </div>
                            <div class="col-span-full">
                                <button class="button-main">Post Comment</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="related md:mt-15 mt-8">
                    <h5 class="heading5">Related Jobs</h5>
                    <ul class="list_related flex flex-col md:gap-7.5 gap-6 w-full mt-5">
                        <li class="jobs_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="jobs_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../jobs-detail" class="overflow-hidden flex-shrink-0 w-15 h-15">
                                    <img src="../assets/images/company/2.png" alt="company/2" class="jobs_avatar w-full h-full object-cover" />
                                </a>
                                <div class="jobs_content flex items-center justify-between gap-2 w-full">
                                    <a href="../jobs-detail" class="jobs_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                        <span class="jobs_company text-sm font-semibold text-primary">PrimeEdge Solutions</span>
                                        <strong class="jobs_name text-title -style-1">Digital Marketing</strong>
                                        <div class="flex flex-wrap items-center gap-5 gap-y-1">
                                            <div class="jobs_address -style-1 text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="address caption1 align-top">Nevada, USA</span>
                                            </div>
                                            <div class="jobs_date text-secondary">
                                                <span class="ph ph-calendar-blank text-lg"></span>
                                                <span class="date caption1 align-top">2 days ago</span>
                                            </div>
                                        </div>
                                    </a>
                                    <button class="add_wishlist_btn -relative -border">
                                        <span class="ph ph-heart text-xl"></span>
                                        <span class="ph-fill ph-heart text-xl"></span>
                                    </button>
                                </div>
                            </div>
                            <div class="jobs_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../jobs-default" class="jobs_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Part-Time</a>
                                    <a href="../jobs-default" class="jobs_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">UX/UI</a>
                                </div>
                                <div class="jobs_price">
                                    <span class="price text-title">$10 - $15</span>
                                    <span class="text-secondary">/hour</span>
                                </div>
                            </div>
                        </li>
                        <li class="jobs_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="jobs_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../jobs-detail" class="overflow-hidden flex-shrink-0 w-15 h-15">
                                    <img src="../assets/images/company/9.png" alt="company/9" class="jobs_avatar w-full h-full object-cover" />
                                </a>
                                <div class="jobs_content flex items-center justify-between gap-2 w-full">
                                    <a href="../jobs-detail" class="jobs_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                        <span class="jobs_company text-sm font-semibold text-primary">Rockstar Games New York</span>
                                        <strong class="jobs_name text-title -style-1">Full Stack Developer</strong>
                                        <div class="flex flex-wrap items-center gap-5 gap-y-1">
                                            <div class="jobs_address -style-1 text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="address caption1 align-top">Las Vegas, USA</span>
                                            </div>
                                            <div class="jobs_date text-secondary">
                                                <span class="ph ph-calendar-blank text-lg"></span>
                                                <span class="date caption1 align-top">2 days ago</span>
                                            </div>
                                        </div>
                                    </a>
                                    <button class="add_wishlist_btn -relative -border">
                                        <span class="ph ph-heart text-xl"></span>
                                        <span class="ph-fill ph-heart text-xl"></span>
                                    </button>
                                </div>
                            </div>
                            <div class="jobs_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../jobs-default" class="jobs_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Part-Time</a>
                                    <a href="../jobs-default" class="jobs_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="jobs_price">
                                    <span class="price text-title">$100 - $120</span>
                                    <span class="text-secondary">/hour</span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="employers_sidebar lg:sticky lg:top-24 flex-shrink-0 lg:w-[380px] w-full h-fit">
                <div class="about overflow-hidden rounded-xl bg-white shadow-md duration-300">
                    <div class="flex items-center justify-between px-5 py-4 border-b border-line">
                        <h6 class="heading6">About the Employer</h6>
                    </div>
                    <div class="employer_info p-5">
                        <a href="employers-detail" class="flex items-center gap-5 w-full">
                            <img src="../assets/images/company/1.png" alt="company/1" class="flex-shrink-0 w-20 h-20" />
                            <div>
                                <div class="rate flex items-center pb-1">
                                    <span class="ph-fill ph-star text-yellow"></span>
                                    <span class="ph-fill ph-star text-yellow"></span>
                                    <span class="ph-fill ph-star text-yellow"></span>
                                    <span class="ph-fill ph-star text-yellow"></span>
                                    <span class="ph-fill ph-star text-placehover"></span>
                                </div>
                                <strong class="employers_name heading6">PrimeEdge Solutions</strong>
                                <span class="employers_establish text-secondary">Since December 11, 2020</span>
                            </div>
                        </a>
                        <div class="industry flex items-center justify-between w-full py-5 border-b border-line">
                            <span class="text-secondary">Industry:</span>
                            <strong class="text-button">Internet Publishing</strong>
                        </div>
                        <div class="size flex items-center justify-between w-full py-5 border-b border-line">
                            <span class="text-secondary">Company size:</span>
                            <strong class="text-button">150 Employees</strong>
                        </div>
                        <div class="address flex items-center justify-between w-full py-5 border-b border-line">
                            <span class="text-secondary">Address:</span>
                            <strong class="text-button">3 SValley , Las Vegas, USA</strong>
                        </div>
                        <div class="list_social flex flex-wrap items-center justify-between gap-4 w-full py-5">
                            <span class="text-secondary">Socials:</span>
                            <ul class="list flex flex-wrap items-center gap-3">
                                <li>
                                    <a href="https://www.facebook.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-facebook text-lg"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-linkedin text-lg"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.twitter.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-twitter text-lg"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.instagram.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-instagram text-lg"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.pinterest.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-pinterest text-lg"></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <a href="employers-messages" class="button-main w-full text-center">Send Message</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

     <!-- footer start  -->
     <?php include('footer.php'); ?>

      <!-- end  -->

  <!-- Menu mobile -->

  <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>

</html>