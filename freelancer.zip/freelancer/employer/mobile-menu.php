

<!-- Menu mobile -->
<div class="menu_mobile">
    <button class="menu_mobile_close flex items-center justify-center absolute top-5 left-5 w-8 h-8 rounded-full bg-surface">
        <span class="ph-bold ph-x"></span>
    </button>
    <div class="heading flex items-center justify-center mt-5">
        <a href="../index" class="logo">
            <img src="../assets/images/logo.png" alt="logo" class="h-8" />
        </a>
    </div>
    <form class="form-search relative mt-4 mx-5">
        <button class="absolute left-3 top-1/2 -translate-y-1/2 cursor-pointer">
            <i class="ph ph-magnifying-glass text-xl block"></i>
        </button>
        <input type="text" placeholder="What are you looking for?" class="h-12 rounded-lg border border-line text-sm w-full pl-10 pr-4" required />
    </form>
    <div class="mt-4">
        <ul class="nav_mobile">
            <li class="nav_item py-2">
                <a href="../index" class="text-xl font-semibold flex items-center justify-between">
                    Home

                </a>

            </li>
            <li class="nav_item py-2">
                <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                    For Candidates
                    <span class="text-right">
                        <i class="ph ph-caret-right text-xl"></i>
                    </span>
                </a>
                <div class="sub_nav_mobile">
                    <button class="back_btn flex items-center gap-3">
                        <i class="ph ph-caret-left text-xl"></i>
                        Back
                    </button>
                    <div class="list-nav-item w-full pt-2 pb-6">
                        <ul>
                            <li class="nav_item">
                                <a href="../jobs-grid" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                    Browse jobs

                                </a>

                            </li>
                            <li class="nav_item">
                                <a href="../project-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                    Browse Projects

                                </a>

                            </li>
                            <li class="nav_item">
                                <a href="employers-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                    Browse Employer

                                </a>

                            </li>
                            <li class="nav_item">
                                <a href="../become-seller" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a seller </a>
                            </li>
                            <li class="nav_item">
                                <a href="../candidates/candidates-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Candidates Dashboard </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
            <li class="nav_item py-2">
                <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                    For Employers
                    <span class="text-right">
                        <i class="ph ph-caret-right text-xl"></i>
                    </span>
                </a>
                <div class="sub_nav_mobile">
                    <button class="back_btn flex items-center gap-3">
                        <i class="ph ph-caret-left text-xl"></i>
                        Back
                    </button>
                    <div class="list-nav-item w-full pt-2 pb-6">
                        <ul>
                            <li class="nav_item">
                                <a href="../services-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                    Browse services

                                </a>

                            </li>
                            <li class="nav_item">
                                <a href="../candidates/candidates-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                    Browse candidates

                                </a>

                            </li>
                            <li class="nav_item">
                                <a href="../become-buyer" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a buyer </a>
                            </li>
                            <li class="nav_item">
                                <a href="employers-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> employer Dashboard </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
            <li class="nav_item py-2">
                <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                    Blogs
                    <span class="text-right">
                        <i class="ph ph-caret-right text-xl"></i>
                    </span>
                </a>
                <div class="sub_nav_mobile">
                    <button class="back_btn flex items-center gap-3">
                        <i class="ph ph-caret-left text-xl"></i>
                        Back
                    </button>
                    <div class="list-nav-item w-full pt-2 pb-6">
                        <ul>
                            <br>
                            <li>
                                <a href="../blog-list" class="inline-block text-xl font-semibold py-2 capitalize"> Blog list </a>
                            </li>

                            <li>
                                <a href="../blog-detail" class="inline-block text-xl font-semibold py-2 capitalize"> Blog detail </a>
                            </li>
                            <br><br><br>

                        </ul>
                    </div>
                </div>
            </li>
            <li class="nav_item py-2">
                <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                    Pages
                    <span class="text-right">
                        <i class="ph ph-caret-right text-xl"></i>
                    </span>
                </a>
                <div class="sub_nav_mobile">
                    <button class="back_btn flex items-center gap-3">
                        <i class="ph ph-caret-left text-xl"></i>
                        Back
                    </button>
                    <div class="list-nav-item w-full pt-2 pb-6">
                        <ul>
                            <li>
                                <a href="../about" class="inline-block text-xl font-semibold py-2 capitalize"> About Us </a>
                            </li>

                            <li>
                                <a href="../pricing" class="inline-block text-xl font-semibold py-2 capitalize"> Pricing Plan </a>
                            </li>
                            <li>
                                <a href="../contact" class="inline-block text-xl font-semibold py-2 capitalize"> Contact Us </a>
                            </li>

                            <li>
                                <a href="../faqs" class="inline-block text-xl font-semibold py-2 capitalize"> Faqs </a>
                            </li>
                            <li>
                                <a href="../term-of-use" class="inline-block text-xl font-semibold py-2 capitalize"> Terms of use </a>
                            </li>

                            <li>
                                <a href="login" class="inline-block text-xl font-semibold py-2 capitalize"> Login </a>
                            </li>
                            <li>
                                <a href="register" class="inline-block text-xl font-semibold py-2 capitalize"> Register </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>

<!-- Modal -->
<div class="modal">
    <!-- menu_dashboard -->
    <div class="modal_item menu_dashboard -modal overflow-hidden relative flex-shrink-0 min-[320px]:w-[280px] w-[80vw] h-full bg-white" data-type="menu_dashboard">
        <div class="inner scrollbar_custom max-h-full py-6 px-3">
            <div class="area">
                <span class="px-6 text-xs font-semibold text-secondary uppercase">Overviews</span>
                <ul class="list_link flex flex-col gap-2 mt-2">
                    <li>
                        <a href="employers-dashboard" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-squares-four text-2xl text-secondary"></span>
                            <strong class="text-title">Dashboard</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-messages" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-chats text-2xl text-secondary"></span>
                            <strong class="text-title">Messages</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-bookmarks" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-bookmarks-simple text-2xl text-secondary"></span>
                            <strong class="text-title">My Bookmarks</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-meetings" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background active">
                            <span class="ph-duotone ph-chalkboard-teacher text-2xl text-secondary"></span>
                            <strong class="text-title">Video Meetings</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-alerts-candidate" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-bell text-2xl text-secondary"></span>
                            <strong class="text-title">Alerts Candidate</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-billings" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-hand-coins text-2xl text-secondary"></span>
                            <strong class="text-title">Billings</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-payouts" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-credit-card text-2xl text-secondary"></span>
                            <strong class="text-title">Payouts</strong>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="area mt-6">
                <span class="px-6 text-xs font-semibold text-secondary uppercase">Management</span>
                <ul class="list_link flex flex-col gap-2 mt-2">
                    <li>
                        <a href="employers-applicants-jobs" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-notepad text-2xl text-secondary"></span>
                            <strong class="text-title">Applicants Jobs</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-jobs" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-briefcase text-2xl text-secondary"></span>
                            <strong class="text-title">My Jobs</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-choose-job-package" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-file-arrow-up text-2xl text-secondary"></span>
                            <strong class="text-title">Submit Jobs</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-proposals-projects" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-gavel text-2xl text-secondary"></span>
                            <strong class="text-title">Proposals Projects</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-my-projects" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-newspaper-clipping text-2xl text-secondary"></span>
                            <strong class="text-title">My Projects</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-choose-project-package" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-clock-countdown text-2xl text-secondary"></span>
                            <strong class="text-title">Submit Projects</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-bought-services" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-stack text-2xl text-secondary"></span>
                            <strong class="text-title">Bought Services</strong>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="area mt-6">
                <span class="px-6 text-xs font-semibold text-secondary uppercase">User</span>
                <ul class="list_link flex flex-col gap-2 mt-2">
                    <li>
                        <a href="employers-profile" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-user-circle text-2xl text-secondary"></span>
                            <strong class="text-title">My Profile</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-profile-setting" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-read-cv-logo text-2xl text-secondary"></span>
                            <strong class="text-title">Profile Setting</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-my-packages" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-currency-circle-dollar text-2xl text-secondary"></span>
                            <strong class="text-title">My Packages</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-change-passwords" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-lock-key-open text-2xl text-secondary"></span>
                            <strong class="text-title">Change Passwords</strong>
                        </a>
                    </li>
                    <li>
                        <a href="employers-delete-profile" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-trash text-2xl text-secondary"></span>
                            <strong class="text-title">Delete Profile</strong>
                        </a>
                    </li>
                    <li>
                        <a href="login" class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                            <span class="ph-duotone ph-sign-out text-2xl text-secondary"></span>
                            <strong class="text-title">Log Out</strong>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>


    <!-- modal_delete -->
    <div class="modal_item modal_delete relative flex-shrink-0 sm:w-[600px] w-[90vw] rounded-lg bg-white" data-type="modal_delete">
        <div class="heading flex items-center justify-between py-6 px-7 border-b border-line">
            <h5 class="heading5">Delete</h5>
            <button class="close_popup_btn">
                <span class="ph ph-x text-2xl"></span>
            </button>
        </div>
        <div class="flex flex-col items-center py-7 md:px-10 px-6">
            <h5 class="heading5 text-center">Are you sure you want to delete?</h5>
            <p class="mt-3 text-secondary text-center">Do you really want to delete your these record? <br class="max-sm:hidden" />This process can't be undo.</p>
            <div class="flex items-center gap-5 mt-6">
                <button class="button-main bg-red btn_confirm_delete">Confirm</button>
                <button class="button-main -border close_popup_btn">Cancel</button>
            </div>
        </div>
    </div>
</div>