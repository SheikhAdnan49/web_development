<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
        <title>FreelanHub - Job Board & Freelance Marketplace</title>
        <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
        <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
        <link rel="stylesheet" href="../assets/css/leaflet.css" />
        <link rel="stylesheet" href="../assets/css/slick.css" />
        <link rel="stylesheet" href="../assets/css/apexcharts.css" />
        <link rel="stylesheet" href="../assets/css/quill.snow.css" />
        <link rel="stylesheet" href="../assets/css/style.css" />
        <link rel="stylesheet" href="../dist/output-tailwind.css" />
        <link rel="stylesheet" href="../dist/output-scss.css" />
    </head>

    <body class="lg:overflow-hidden">
  <!-- Header -->
  <?php include ('header.php');?>
     <!-- end -->

        <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">
            
        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

            <div class="dashboard_change_password scrollbar_custom w-full bg-surface">
                <div class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8">
                    <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 lg:hidden" data-type="menu_dashboard">
                        <span class="ph ph-squares-four text-xl"></span>
                        <strong class="text-button">Menu</strong>
                    </button>
                    <h4 class="heading4 max-lg:mt-3">Change Passwords</h4>
                    <form class="form_change grid grid-cols-2 gap-5 w-full p-10 mt-7.5 rounded-lg bg-white shadow-sm">
                        <div class="email col-span-full flex flex-col">
                            <label for="email" class="w-fit">Your Email: <span class="text-red">*</span></label>
                            <input class="w-1/2 h-12 px-4 mt-2 border-line rounded-lg" id="email" type="text" placeholder="Your Email..." value="hi.avitex@gmail.com" required />
                        </div>
                        <div class="old_pass col-span-full flex flex-col">
                            <label for="oldPass" class="w-fit">Old Password: <span class="text-red">*</span></label>
                            <input class="w-1/2 h-12 px-4 mt-2 border-line rounded-lg" id="oldPass" type="password" placeholder="Old Password..." required />
                        </div>
                        <div class="new_pass col-span-full flex flex-col">
                            <label for="newPass" class="w-fit">New Password: <span class="text-red">*</span></label>
                            <input class="w-1/2 h-12 px-4 mt-2 border-line rounded-lg" id="newPass" type="password" placeholder="Old Password..." required />
                        </div>
                        <div class="confirm_pass col-span-full flex flex-col">
                            <label for="confirmPass" class="w-fit">Confirm New Password: <span class="text-red">*</span></label>
                            <input class="w-1/2 h-12 px-4 mt-2 border-line rounded-lg" id="confirmPass" type="password" placeholder="Confirm New Password..." required />
                        </div>
                        <div class="block_btn">
                            <button class="button-main btn_open_popup btn_change_password" data-type="modal_verify">Change Password</button>
                        </div>
                    </form>
                </div>
                <div class="lg:fixed bottom-0 left-0 z-[1] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                    <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
                </div>
            </div>
        </div>

       <!-- Menu mobile -->

    <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/phosphor-icons.js"></script>
        <script src="../assets/js/slick.min.js"></script>
        <script src="../assets/js/leaflet.js"></script>
        <script src="../assets/js/swiper-bundle.min.js"></script>
        <script src="../assets/js/apexcharts.js"></script>
        <script src="../assets/js/quill.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>

<!-- Mirrored from freelanhub.vercel.app/employers-change-passwords by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Jan 2025 03:38:22 GMT -->
</html>
