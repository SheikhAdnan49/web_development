<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/apexcharts.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body class="lg:overflow-hidden">

    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->



    <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">
        
        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

        <div class="dashboard_alert scrollbar_custom w-full bg-surface">
            <div class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8">
                <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 lg:hidden" data-type="menu_dashboard">
                    <span class="ph ph-squares-four text-xl"></span>
                    <strong class="text-button">Menu</strong>
                </button>
                <h4 class="heading4 max-lg:mt-3">View Applicants</h4>
                <div class="mt-7.5 p-6 rounded-lg bg-white">
                    <div class="outstanding flex max-sm:flex-col sm:items-center justify-between xl:gap-20 gap-10 gap-y-5 p-5 rounded-lg bg-surface">
                        <div class="left flex flex-wrap justify-between max-sm:flex-col sm:items-center sm:gap-5 gap-4 w-full">
                            <a href="../jobs-detail" class="block">
                                <strong class="candidates_name -style-1 heading6 duration-300 hover:text-primary">Full Stack Development</strong>
                                <div class="address flex items-center gap-2 mt-1 text-secondary">
                                    <span class="ph ph-map-pin text-xl"></span>
                                    <span class="employers_address font-normal">Las Vegas, USA</span>
                                </div>
                            </a>
                            <div>
                                <p>Created date: March 18, 2024</p>
                                <p>Expiry date: March 30, 2025</p>
                            </div>
                            <span class="tag w-fit bg-opacity-10 bg-success text-success text-button">Published</span>
                        </div>
                        <div class="right flex flex-col sm:items-end sm:gap-2 xl:pl-20 sm:pl-10 sm:border-l border-line">
                            <span class="text-secondary whitespace-nowrap">Number of Applicants</span>
                            <strong class="heading3">4</strong>
                        </div>
                    </div>
                    <div class="flex flex-wrap items-center justify-between gap-5 pt-6">
                        <form class="relative w-[340px] h-12">
                            <input type="text" class="w-full h-full pl-4 pr-12 border border-line rounded-lg overflow-hidden" placeholder="Search by keyword" required />
                            <button type="submit" class="absolute top-1/2 -translate-y-1/2 right-4">
                                <span class="ph ph-magnifying-glass text-xl block"></span>
                            </button>
                        </form>
                        <div class="select_block sm:pr-16 pr-10 pl-3 py-2 border border-line rounded">
                            <div class="select">
                                <span class="selected caption1 capitalize" data-title="sort by (default)">sort by (default)</span>
                                <ul class="list_option scrollbar_custom max-h-[200px] p-0 bg-white">
                                    <li class="capitalize" data-item="default">sort by (default)</li>
                                    <li class="capitalize" data-item="candidate name (a -> z)">candidate name (a -> z)</li>
                                    <li class="capitalize" data-item="candidate name (z -> a)">candidate name (z -> a)</li>
                                    <li class="capitalize" data-item="job title (a -> z)">job title (a -> z)</li>
                                    <li class="capitalize" data-item="job title (z -> a)">job title (z -> a)</li>
                                    <li class="capitalize" data-item="status (on hold)">status (on hold)</li>
                                    <li class="capitalize" data-item="status (interviewed)">status (interviewed)</li>
                                    <li class="capitalize" data-item="status (rejected)">status (rejected)</li>
                                    <li class="capitalize" data-item="status (hired)">status (hired)</li>
                                </ul>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="list overflow-x-auto w-full py-6 rounded-xl">
                        <table class="w-full max-[1400px]:w-[1200px] max-md:w-[1000px]">
                            <thead class="border-b border-line">
                                <tr>
                                    <th scope="col" class="px-5 py-4 text-left text-sm font-bold uppercase text-secondary whitespace-nowrap">Candidates</th>
                                    <th scope="col" class="px-5 py-4 text-left text-sm font-bold uppercase text-secondary whitespace-nowrap">Date Applied</th>
                                    <th scope="col" class="px-5 py-4 text-left text-sm font-bold uppercase text-secondary whitespace-nowrap">Status</th>
                                    <th scope="col" class="px-5 py-4 text-right text-sm font-bold uppercase text-secondary whitespace-nowrap">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info flex items-center gap-3">
                                            <a href="../candidates/candidates-detail" class="avatar flex-shrink-0 w-15 h-15 rounded-full overflow-hidden">
                                                <img src="../assets/images/avatar/IMG-1.webp" alt="avatar/IMG-1" class="w-full h-full object-cover" />
                                            </a>
                                            <a href="../candidates/candidates-detail" class="block">
                                                <strong class="candidates_name -style-1 heading6 duration-300 hover:text-primary">Kelemen Krisztina</strong>
                                                <div class="address flex items-center gap-2 mt-1 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Las Vegas, USA</span>
                                                </div>
                                            </a>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 12, 2024</td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-yellow text-yellow text-button">On Hold</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_create_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_create_meeting">
                                                <span class="ph ph-video-camera text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Create Metting</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_approved_application flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_approved_application">
                                                <span class="ph ph-check text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Approved Application</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_undo_approved flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_undo_approved">
                                                <span class="ph ph-box-arrow-down text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Download CV</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_reject flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_reject">
                                                <span class="ph ph-x text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Reject</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info flex items-center gap-3">
                                            <a href="../candidates/candidates-detail" class="avatar flex-shrink-0 w-15 h-15 rounded-full overflow-hidden">
                                                <img src="../assets/images/avatar/IMG-2.webp" alt="avatar/IMG-2" class="w-full h-full object-cover" />
                                            </a>
                                            <a href="../candidates/candidates-detail" class="block">
                                                <strong class="candidates_name -style-1 heading6 duration-300 hover:text-primary">Sara Smith</strong>
                                                <div class="address flex items-center gap-2 mt-1 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Paris, France</span>
                                                </div>
                                            </a>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 10, 2024</td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-yellow text-yellow text-button">On Hold</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_create_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_create_meeting">
                                                <span class="ph ph-video-camera text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Create Metting</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_approved_application flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_approved_application">
                                                <span class="ph ph-check text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Approved Application</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_undo_approved flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_undo_approved">
                                                <span class="ph ph-box-arrow-down text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Download CV</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_reject flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_reject">
                                                <span class="ph ph-x text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Reject</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info flex items-center gap-3">
                                            <a href="../candidates/candidates-detail" class="avatar flex-shrink-0 w-15 h-15 rounded-full overflow-hidden">
                                                <img src="../assets/images/avatar/IMG-3.webp" alt="avatar/IMG-3" class="w-full h-full object-cover" />
                                            </a>
                                            <a href="../candidates/candidates-detail" class="block">
                                                <strong class="candidates_name -style-1 heading6 duration-300 hover:text-primary">Katona Beatrix</strong>
                                                <div class="address flex items-center gap-2 mt-1 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Brasilla, Brazil</span>
                                                </div>
                                            </a>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 06, 2024</td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-features text-features text-button">Interviewed</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_create_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_create_meeting">
                                                <span class="ph ph-video-camera text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Create Metting</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_undo_approved flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_undo_approved">
                                                <span class="ph ph-repeat text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Undo Approved</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_undo_approved flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_undo_approved">
                                                <span class="ph ph-box-arrow-down text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Download CV</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_reject flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_reject">
                                                <span class="ph ph-x text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Reject</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info flex items-center gap-3">
                                            <a href="../candidates/candidates-detail" class="avatar flex-shrink-0 w-15 h-15 rounded-full overflow-hidden">
                                                <img src="../assets/images/avatar/IMG-4.webp" alt="avatar/IMG-4" class="w-full h-full object-cover" />
                                            </a>
                                            <a href="../candidates/candidates-detail" class="block">
                                                <strong class="candidates_name -style-1 heading6 duration-300 hover:text-primary">Kende Lili</strong>
                                                <div class="address flex items-center gap-2 mt-1 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Berlin, Germany</span>
                                                </div>
                                            </a>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 01, 2024</td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-red text-red text-button">Rejected</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_create_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_create_meeting">
                                                <span class="ph ph-video-camera text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Create Metting</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_undo_approved flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_undo_approved">
                                                <span class="ph ph-repeat text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Undo Approved</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_undo_approved flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_undo_approved">
                                                <span class="ph ph-box-arrow-down text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Download CV</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_reject flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_reject">
                                                <span class="ph ph-x text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Reject</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="flex flex-wrap items-center justify-between gap-4 pt-6 border-t border-line">
                        <ul class="list_pagination menu_tab flex items-center justify-center gap-2 w-full md:mt-10 mt-7" role="tablist">
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black active" role="tab" aria-selected="true">1</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">2</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">3</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">></a>
                            </li>
                        </ul>
                        <p class="text-secondary whitespace-nowrap">Showing <span class="start">1</span> to <span class="end">6</span> of <span class="total">24</span> entries</p>
                    </div>
                </div>
            </div>
            <div class="lg:fixed bottom-0 left-0 z-[1] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
            </div>
        </div>
    </div>

   <!-- Menu mobile -->

   <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/apexcharts.js"></script>
    <script src="../assets/js/main.js"></script>
</body>

</html>