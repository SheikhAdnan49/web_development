<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password !== $confirmPassword) {
        echo "<script>alert('Invalid input or passwords do not match!'); window.history.back();</script>";
        exit;
    }
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Check if email exists
    $stmt = $conn->prepare("SELECT * FROM register WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        echo "<script>alert('Email already registered!'); window.history.back();</script>";
        exit;
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO register (email, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $email, $hashedPassword);

    if ($stmt->execute()) {
        // Send email to owner
        mail("owner@example.com", "New Registration", "New user registered: $email", "From: Freelancer@gmail.com");
        echo "<script>alert('Registration successful!'); window.location.href='login.php';</script>";

    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body>
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->


    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="breadcrumb_inner relative sm:mt-20 mt-16 lg:py-20 py-14">
            <div class="breadcrumb_bg absolute top-0 left-0 w-full h-full">
                <img src="../assets/images/components/breadcrumb_candidate.webp" alt="breadcrumb_candidate" class="w-full h-full object-cover" />
            </div>
            <div class="container relative h-full">
                <div class="breadcrumb_content flex flex-col items-start justify-center xl:w-[1000px] lg:w-[848px] md:w-5/6 w-full h-full">
                    <div class="list_breadcrumb flex items-center gap-2 animate animate_top" style="--i: 1">
                        <a href="../index" class="caption1 text-white">Home</a>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white">Pages</span>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white opacity-60">Register</span>
                    </div>
                    <h3 class="heading3 text-white mt-2 animate animate_top" style="--i: 2">Register</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- Form Register -->
    <section class="form_register lg:py-20 sm:py-14 py-10">
        <div class="container flex items-center justify-center">
            <div class="content sm:w-[448px] w-full">
                <h3 class="heading3 text-center">Create a free account</h3>
                <div class="menu_tab w-full mt-8">
                    <ul class="list grid grid-cols-2 gap-5 w-full" role="tablist">

                    </ul>
                </div>
                <div id="candidate" class="tab_list active" role="tabpanel" aria-labelledby="tab_candidate" aria-hidden="false">
                    <form action="" method="POST" class="form mt-6">
                        <div class="form-group">
                            <label for="username">Candidate email address*</label>
                            <input id="username" type="email" name="username" class="form-control w-full mt-3 border border-line px-4 h-[50px] rounded-lg" placeholder="Email address*" required />
                        </div>
                        <div class="form-group mt-6">
                            <label for="password">Password*</label>
                            <input id="password" type="password" name="password" class="form-control w-full mt-3 border border-line px-4 h-[50px] rounded-lg" placeholder="Password*" required />
                        </div>
                        <div class="form-group mt-6">
                            <label for="confirmPassword">Confirm password*</label>
                            <input id="confirmPassword" type="password" name="confirmPassword" class="form-control w-full mt-3 border border-line px-4 h-[50px] rounded-lg" placeholder="Confirm password*" required />
                        </div>
                        <div class="block-button mt-6">
                            <button type="submit" class="button-main bg-primary w-full text-center">Create a new account</button>
                        </div>
                        <div class="navigate flex items-center justify-center gap-2 mt-6">
                            <span class="text-surface1">Already have an account?</span>
                            <a class="text-button hover:underline" href="login">Login</a>
                        </div>
                    </form>

                </div>
                <div id="employer" class="tab_list" role="tabpanel" aria-labelledby="tab_employer" aria-hidden="true">
                    <form class="form mt-6">
                        <div class="form-group">
                            <label for="username">Employer email address*</label>
                            <input id="username" type="email" name="username" class="form-control w-full mt-3 border border-line px-4 h-[50px] rounded-lg" placeholder="Email address*" required />
                        </div>
                        <div class="form-group mt-6">
                            <label for="password">Password*</label>
                            <input id="password" type="password" name="password" class="form-control w-full mt-3 border border-line px-4 h-[50px] rounded-lg" placeholder="Password*" required />
                        </div>
                        <div class="form-group mt-6">
                            <label for="confirmPassword">Confirm password*</label>
                            <input id="confirmPassword" type="password" name="confirmPassword" class="form-control w-full mt-3 border border-line px-4 h-[50px] rounded-lg" placeholder="Confirm password*" required />
                        </div>
                        <div class="flex items-center justify-between mt-6">
                            <div class="sub-input-checkbox flex items-center gap-2">
                                <input id="checkbox" type="checkbox" name="checkbox" />
                                <label for="checkbox" class="text-surface1">I agree to the <a href="../term-of-use" class="text-button hover:underline">Terms of User</a></label>
                            </div>
                        </div>
                        <div class="block-button mt-6">
                            <button class="button-main bg-primary w-full text-center">Create a new account</button>
                        </div>
                        <div class="navigate flex items-center justify-center gap-2 mt-6">
                            <span class="text-surface1">Already have an account?</span>
                            <a class="text-button hover:underline" href="login">Login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    <!-- footer start  -->
   

    <!-- end -->

    <!-- Menu mobile -->
    

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>

<!-- Mirrored from freelanhub.vercel.app/register by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Jan 2025 03:38:05 GMT -->

</html>