<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/apexcharts.css" />
    <link rel="stylesheet" href="../assets/css/quill.snow.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body class="lg:overflow-hidden">

    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">

        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

        <div class="dashboard_profile scrollbar_custom w-full bg-surface">
            <form method="post" action="save_employer.php" enctype="multipart/form-data" class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8">
                <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 lg:hidden" data-type="menu_dashboard">
                    <span class="ph ph-squares-four text-xl"></span>
                    <strong class="text-button">Menu</strong>
                </button>
                <div class="heading flex flex-wrap items-center justify-between gap-4">
                    <h4 class="heading4 max-lg:mt-3">My profile</h4>
                    <button class="button-main" type="submit">Save & Publish</button>
                </div>
                <div class="infomation p-8 mt-7.5 rounded-lg bg-white shadow-sm">
                    <h5 class="heading5">Information</h5>
                    <div class="grid sm:grid-cols-2 gap-5 mt-5">
                        <div class="upload_image col-span-full">
                            <label for="avatar">Upload a new avatar: <span class="text-red">*</span></label>
                            <div class="flex flex-wrap items-center gap-5 mt-3">
                                <div class="bg_img flex-shrink-0 relative w-[7.5rem] h-[7.5rem] rounded-md overflow-hidden border border-dashed border-line bg-surface">
                                    <span class="ph ph-image text-5xl absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-secondary"></span>
                                    <img src="#" alt="preview img" class="upload_img relative z-[1] w-full h-full object-cover hidden" />
                                </div>
                                <div>
                                    <strong class="text-button">Upload Avatar</strong>
                                    <p class="caption1 text-secondary mt-1">JPG 320x240px</p>
                                    <div class="upload_file flex items-center gap-3 w-[220px] mt-3 px-3 py-2 border border-line rounded">
                                        <label for="avatar_path" class="caption2 py-1 px-3 rounded bg-line whitespace-nowrap cursor-pointer">Choose File</label>
                                        <input type="file" name="avatar_path" id="avatar_path" accept="image/*" class="caption2 cursor-pointer" required />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="name">
                            <label for="name">Name: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg capitalize" name="name" id="name" type="text" placeholder="Name..." required />
                        </div>
                        <div class="email">
                            <label for="email">Email: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="email" id="email" type="email" placeholder="Email..." required />
                        </div>
                        <div class="phone">
                            <label for="phone">Phone: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="phone" id="phone" type="number" placeholder="Phone..." required />
                        </div>
                        <div class="website">
                            <label for="website">Website: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="website" id="website" type="text" placeholder="Website..." required />
                        </div>
                        <div class="founded">
                            <label for="founded">Founded: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="founded" id="founded" type="number" placeholder="Founded..." required />
                        </div>
                        <div class="company_size">
                            <label for="company_size">Company Size: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="company_size" id="company_size" type="text" placeholder="Company Size..." required />
                        </div>
                        <div class="categories col-span-full">
                            <label for="categories">Categories: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="categories" id="categories" type="text" placeholder="Categories..." required />
                        </div>
                        <div class="description col-span-full">
                            <label for="description">Description: <span class="text-red">*</span></label>
                            <textarea class="w-full p-4 mt-2 border-line rounded-lg" name="description" id="description" rows="3" placeholder="Description..." required></textarea>
                        </div>
                    </div>
                </div>
                <div class="gallery p-8 mt-7.5 rounded-lg bg-white">
                    <h5 class="heading5">Gallery</h5>
                    <div class="video_url mt-5">
                        <label for="video_url">Video URL: <span class="text-red">*</span></label>
                        <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="video_url" id="video_url" type="text" placeholder="Video URL..." required />
                    </div>
                </div>
                <div class="map_location p-8 mt-7.5 rounded-lg bg-white shadow-sm">
                    <h5 class="heading5">Location</h5>
                    <div class="grid sm:grid-cols-2 gap-5 mt-5">
                        <div class="address col-span-full">
                            <label for="address">Address:</label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="address" id="address" type="text" placeholder="Address..." />
                        </div>
                    </div>
                </div>
            </form>


            <div class="lg:fixed bottom-0 left-0 z-[1] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
            </div>
        </div>
    </div>

    <!-- Menu mobile -->

    <?php include('mobile-menu.php'); ?>

    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/apexcharts.js"></script>
    <script src="../assets/js/quill.js"></script>
    <script src="../assets/js/main.js"></script>
</body>

<!-- Mirrored from freelanhub.vercel.app/employers-profile-setting by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Jan 2025 03:38:21 GMT -->

</html>