<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body>
    <!-- Header -->
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="breadcrumb_inner relative sm:mt-20 mt-16 lg:py-20 py-14">
            <div class="breadcrumb_bg absolute top-0 left-0 w-full h-full">
                <img src="../assets/images/components/breadcrumb_employer.webp" alt="breadcrumb_employer" class="w-full h-full object-cover" />
            </div>
            <div class="container relative h-full">
                <div class="breadcrumb_content flex flex-col items-start justify-center xl:w-[1000px] lg:w-[848px] md:w-5/6 w-full h-full">
                    <div class="list_breadcrumb flex items-center gap-2 animate animate_top" style="--i: 1">
                        <a href="../index" class="caption1 text-white">Home</a>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white">For Candidates</span>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white opacity-60">Employers</span>
                    </div>
                    <h3 class="heading3 text-white mt-2 animate animate_top" style="--i: 2">Employers List</h3>
                    <div class="form_search z-[1] w-full mt-5 animate animate_top" style="--i: 3">
                        <form class="form_inner flex items-center justify-between max-sm:flex-wrap gap-6 gap-y-4 relative w-full p-3 rounded-lg bg-white">
                            <div class="form_input relative w-full">
                                <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-2 text-xl"></span>
                                <input type="text" class="input_search w-full h-full pl-10" placeholder="Job title, key words or company" required />
                            </div>
                            <div class="select_block flex-shrink-0 max-sm:w-full sm:pr-16 pr-7 sm:pl-6 pl-3 sm:border-l border-line">
                                <div class="select">
                                    <span class="selected" data-title="City, State or Zip">City, State or Zip</span>
                                    <ul class="list_option bg-white max-sm:w-full">
                                        <li data-item="Las Vegas, USA">Las Vegas, USA</li>
                                        <li data-item="Cape Town, South Africa">Cape Town, South Africa</li>
                                        <li data-item="Sydney, Australia">Sydney, Australia</li>
                                        <li data-item="Tokyo, Japan">Tokyo, Japan</li>
                                    </ul>
                                </div>
                                <span class="icon_down ph ph-caret-down sm:text-2xl text-xl sm:right-0 right-3"></span>
                            </div>
                            <div class="select_block flex-shrink-0 max-sm:w-full sm:pr-16 pr-7 sm:pl-6 pl-3 sm:border-l border-line">
                                <div class="select">
                                    <span class="selected" data-title="All Categories">All Categories</span>
                                    <ul class="list_option bg-white max-sm:w-full">
                                        <li data-item="Graphic & Design">Graphic & Design</li>
                                        <li data-item="Wrting">Wrting</li>
                                        <li data-item="Videos">Videos</li>
                                        <li data-item="Digital Marketing">Digital Marketing</li>
                                    </ul>
                                </div>
                                <span class="icon_down ph ph-caret-down sm:text-2xl text-xl sm:right-0 right-3"></span>
                            </div>
                            <button type="submit" class="button-main max-sm:w-1/3 text-center flex-shrink-0">Search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- List employers -->
    <div class="employers lg:py-20 sm:py-14 py-10">
        <div class="container flex flex-col items-center">
            <div class="filter flex flex-wrap items-center justify-between gap-8 gap-y-3 relative w-full">
                <button id="filter_btn" class="filter_btn inline-flex items-center gap-1.5 py-1.5 px-2.5 border border-line rounded-md duration-300 hover:bg-primary hover:text-white">
                    <span class="ph ph-sliders-horizontal text-xl"></span>
                    <span>Filters</span>
                </button>
                <ul class="list_layout flex items-center gap-2 sm:absolute sm:left-1/2 sm:-translate-x-1/2">
                    <li class="max-xl:hidden">
                        <button class="layout_btn cols_3"></button>
                    </li>
                    <li class="max-xl:hidden">
                        <button class="layout_btn cols_2 active"></button>
                    </li>
                    <li class="xl:hidden">
                        <a href="employers-default" class="layout_link cols_2"></a>
                    </li>
                    <li class="xl:hidden">
                        <a href="#!" class="layout_link list active"></a>
                    </li>
                </ul>
                <div class="select_filter flex items-center gap-3">
                    <span class="caption1">Sort by:</span>
                    <div class="select_block sm:pr-16 pr-10 pl-3 py-1 border border-line rounded">
                        <div class="select">
                            <span class="selected caption1 capitalize" data-title="sort default">default</span>
                            <ul class="list_option p-0 bg-white">
                                <li class="capitalize" data-item="default">sort by (default)</li>
                                <li class="capitalize" data-item="newest">newest</li>
                                <li class="capitalize" data-item="oldest">oldest</li>
                                <li class="capitalize" data-item="random">random</li>
                            </ul>
                        </div>
                        <span class="icon_down ph ph-caret-down right-3"></span>
                    </div>
                </div>
            </div>
            <div class="list_filtered flex flex-wrap items-center gap-3 w-full mt-5">
                <span class="quantity pr-3 border-r border-line">1,200+ Results</span>
                <div class="list flex flex-wrap items-center gap-3"></div>
                <button class="clear_all_btn inline-flex items-center gap-1 py-1 px-2 border border-red text-red rounded-full duration-300 hover:bg-red hover:text-white">
                    <span class="ph ph-x text-sm"></span>
                    <span class="caption1">Clear All</span>
                </button>
            </div>
            <ul class="list_layout_cols list_employers grid md:grid-cols-2 gap-5 w-full md:mt-10 mt-7">
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/1.png" alt="company/1" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">Bright Future</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">Las Vegas, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/2.png" alt="company/2" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">Innovations</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">New York, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/3.png" alt="company/3" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">CoreTech</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">Texas, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/4.png" alt="company/4" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">GlobalTech Partners</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">California, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/5.png" alt="company/5" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">PrimeEdge Solutions</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">Nevada, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/6.png" alt="company/6" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">Stellar Enterprises</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">Georgia, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/7.png" alt="company/7" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">EliteTech Solutions</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">Idaho, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/8.png" alt="company/8" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">Apex Innovations</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">New Mexico, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/9.png" alt="company/9" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">Infinity Solutions</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">Colorado, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/10.png" alt="company/10" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">Horizons Corporation</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">Florida, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/11.png" alt="company/11" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">Quantum Dynamics</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">New Mexico, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
                <li class="employers_item flex flex-wrap items-center justify-between gap-3 p-6 rounded-lg bg-white shadow-md duration-300">
                    <div class="left flex items-center gap-4">
                        <a href="employers-detail" class="overflow-hidden block flex-shrink-0 w-15 h-15">
                            <img src="../assets/images/company/12.png" alt="company/12" class="employers_logo w-full h-full object-cover" />
                        </a>
                        <div>
                            <ul class="rate flex items-center mt-4">
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                                <li class="ph-fill ph-star text-yellow"></li>
                            </ul>
                            <a href="employers-detail" class="employers_name text-title -style-1 mt-1 duration-300 hover:text-primary">Fusion Innovations</a>
                            <div class="employers_address -style-1 text-secondary mt-1">
                                <span class="ph ph-map-pin text-lg"></span>
                                <span class="address caption1 align-top">Las Vegas, USA</span>
                            </div>
                        </div>
                    </div>
                    <div class="right flex items-center gap-4">
                        <button class="add_wishlist_btn -relative -border flex-shrink-0">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                        <a href="employers-detail" class="button-main -border flex-shrink-0">2 job openings</a>
                    </div>
                </li>
            </ul>
            <ul class="list_pagination menu_tab flex items-center justify-center gap-2 w-full md:mt-10 mt-7" role="tablist">
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black active" role="tab" aria-selected="true">1</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">2</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">3</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">></a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    <!-- Footer -->


    <!-- footer start  -->
    <?php include('footer.php'); ?>

    <!-- end  -->

   <!-- Menu mobile -->

   <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>


</html>