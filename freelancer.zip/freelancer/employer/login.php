<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        die("Email and password are required.");
    }

    // User check register table mein
    $stmt = $conn->prepare("SELECT id, password FROM register WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Agar password hashed hai to password_verify() use karo
        if (password_verify($password, $row['password'])) {
            // Password correct hai
            $_SESSION['user_id'] = $row['id'];
            // Profile check karna employers table mein
            $user_id = $row['id'];
            $check = $conn->prepare("SELECT id FROM employers WHERE user_id = ?");
            $check->bind_param("i", $user_id);
            $check->execute();
            $profile = $check->get_result();

            if ($profile->num_rows > 0) {
                // Profile exists, redirect to profile page
                header("Location: employers-dashboard.php");
            } 
            // else {
                // Profile nahi hai, redirect to profile setting page
            //     header("Location: employers-profile-setting.php");
            // }
            exit;

        } else {
            die("Incorrect password.");
        }
    } else {
        die("No user found with that email.");
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body>

    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="breadcrumb_inner relative sm:mt-20 mt-16 lg:py-20 py-14">
            <div class="breadcrumb_bg absolute top-0 left-0 w-full h-full">
                <img src="../assets/images/components/breadcrumb_candidate.webp" alt="breadcrumb_candidate" class="w-full h-full object-cover" />
            </div>
            <div class="container relative h-full">
                <div class="breadcrumb_content flex flex-col items-start justify-center xl:w-[1000px] lg:w-[848px] md:w-5/6 w-full h-full">
                    <div class="list_breadcrumb flex items-center gap-2 animate animate_top" style="--i: 1">
                        <a href="../index" class="caption1 text-white">Home</a>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white">Pages</span>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white opacity-60">Login</span>
                    </div>
                    <h3 class="heading3 text-white mt-2 animate animate_top" style="--i: 2">Login</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- Form Login -->
    <section class="form_login lg:py-20 sm:py-14 py-10">
        <div class="container flex items-center justify-center">
            <div class="content sm:w-[448px] w-full">
                <h3 class="heading3 text-center">Log In</h3>
                <form class="form mt-6" action="login.php" method="POST">
                    <div class="form-group">
                        <label for="email">Email address*</label>
                        <input id="email" type="email" name="email" class="form-control w-full mt-3 border border-line px-4 h-[50px] rounded-lg" placeholder="Email address*" required />
                    </div>
                    <div class="form-group mt-6">
                        <label for="password">Password*</label>
                        <input id="password" type="password" name="password" class="form-control w-full mt-3 border border-line px-4 h-[50px] rounded-lg" placeholder="Password*" required />
                    </div>
                    <div class="flex items-center justify-between mt-6">
                        <div class="sub-input-checkbox flex items-center gap-2">
                            <input id="rememberMe" type="checkbox" name="rememberMe" required />
                            <label for="rememberMe" class="text-surface1">Remember me</label>
                        </div>
                    </div>
                    <div class="block-button mt-6">
                        <button type="submit" class="button-main bg-primary w-full text-center">Login</button>
                    </div>
                    <div class="navigate flex items-center justify-center gap-2 mt-6">
                        <span class="text-surface1">Not registered yet?</span>
                        <a class="text-button hover:underline" href="register">Sign Up</a>
                    </div>
                </form>

            </div>
        </div>
    </section>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>



    <!-- Menu mobile -->
     <!-- Menu mobile -->
     <div class="menu_mobile">
            <button class="menu_mobile_close flex items-center justify-center absolute top-5 left-5 w-8 h-8 rounded-full bg-surface">
                <span class="ph-bold ph-x"></span>
            </button>
            <div class="heading flex items-center justify-center mt-5">
                <a href="../index" class="logo">
                    <img src="../assets/images/logo.png" alt="logo" class="h-8" />
                </a>
            </div>
            <form class="form-search relative mt-4 mx-5">
                <button class="absolute left-3 top-1/2 -translate-y-1/2 cursor-pointer">
                    <i class="ph ph-magnifying-glass text-xl block"></i>
                </button>
                <input type="text" placeholder="What are you looking for?" class="h-12 rounded-lg border border-line text-sm w-full pl-10 pr-4" required />
            </form>
            <div class="mt-4">
                <ul class="nav_mobile">
                    <li class="nav_item py-2">
                        <a href="../index" class="text-xl font-semibold flex items-center justify-between">
                            Home

                        </a>

                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            For Candidates
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li class="nav_item">
                                        <a href="../jobs-grid" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse jobs

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../project-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse Projects

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../employer/employers-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse Employer

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../become-seller" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a seller </a>
                                    </li>
                                    <li class="nav_item">
                                        <a href="../candidates/candidates-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Candidates Dashboard </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            For Employers
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li class="nav_item">
                                        <a href="../services-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse services

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../candidates/candidates-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse candidates

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../become-buyer" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a buyer </a>
                                    </li>
                                    <li class="nav_item">
                                        <a href="../employer/employers-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> employer Dashboard </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            Blogs
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <br>
                                    <li>
                                        <a href="../blog-list" class="inline-block text-xl font-semibold py-2 capitalize"> Blog list </a>
                                    </li>

                                    <li>
                                        <a href="../blog-detail1" class="inline-block text-xl font-semibold py-2 capitalize"> Blog detail </a>
                                    </li>
                                    <br><br><br>

                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            Pages
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li>
                                        <a href="../about" class="inline-block text-xl font-semibold py-2 capitalize"> About Us </a>
                                    </li>

                                    <li>
                                        <a href="../pricing" class="inline-block text-xl font-semibold py-2 capitalize"> Pricing Plan </a>
                                    </li>
                                    <li>
                                        <a href="../contact" class="inline-block text-xl font-semibold py-2 capitalize"> Contact Us </a>
                                    </li>

                                    <li>
                                        <a href="../faqs" class="inline-block text-xl font-semibold py-2 capitalize"> Faqs </a>
                                    </li>
                                    <li>
                                        <a href="../term-of-use" class="inline-block text-xl font-semibold py-2 capitalize"> Terms of use </a>
                                    </li>

                                    <li>
                                        <a href="login" class="inline-block text-xl font-semibold py-2 capitalize"> Login </a>
                                    </li>
                                    <li>
                                        <a href="register" class="inline-block text-xl font-semibold py-2 capitalize"> Register </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>




</body>

</html>