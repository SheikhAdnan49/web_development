<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/apexcharts.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body class="lg:overflow-hidden">

    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">
        
        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

        <div class="dashboard_alert scrollbar_custom w-full bg-surface">
            <div class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8">
                <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 lg:hidden" data-type="menu_dashboard">
                    <span class="ph ph-squares-four text-xl"></span>
                    <strong class="text-button">Menu</strong>
                </button>
                <div class="flex flex-wrap items-center justify-between gap-4">
                    <h4 class="heading4 max-lg:mt-3">Website design</h4>
                    <a href="employers-add-alerts-candidate" class="button-main">Add New Alert</a>
                </div>
                <div class="alert_block mt-7.5 rounded-lg bg-white">
                    <div class="flex flex-wrap items-center justify-between gap-5 pt-6 px-6">
                        <form class="relative w-[340px] h-12">
                            <input type="text" class="w-full h-full pl-4 pr-12 border border-line rounded-lg overflow-hidden" placeholder="Search by keyword" required />
                            <button type="submit" class="absolute top-1/2 -translate-y-1/2 right-4">
                                <span class="ph ph-magnifying-glass text-xl block"></span>
                            </button>
                        </form>
                        <div class="select_block sm:pr-16 pr-10 pl-3 py-2 border border-line rounded">
                            <div class="select">
                                <span class="selected caption1 capitalize" data-title="sort by (default)">sort by (default)</span>
                                <ul class="list_option scrollbar_custom max-h-[200px] p-0 bg-white">
                                    <li class="capitalize" data-item="default">sort by (default)</li>
                                    <li class="capitalize" data-item="title (a -> z)">title (a -> z)</li>
                                    <li class="capitalize" data-item="title (z -> a)">title (z -> a)</li>
                                    <li class="capitalize" data-item="jobs (high to low)">jobs (high to low)</li>
                                    <li class="capitalize" data-item="jobs (low to high)">jobs (low to high)</li>
                                    <li class="capitalize" data-item="times (daily)">times (daily)</li>
                                    <li class="capitalize" data-item="times (weekly)">times (weekly)</li>
                                    <li class="capitalize" data-item="times (monthly)">times (monthly)</li>
                                    <li class="capitalize" data-item="status (on)">status (on)</li>
                                    <li class="capitalize" data-item="status (off)">status (off)</li>
                                </ul>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <ul class="list grid xl:grid-cols-3 sm:grid-cols-2 gap-6 p-6">
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-8.webp" alt="IMG-8" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Kelemen Krisztina</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Las Vegas, USA</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-7.webp" alt="IMG-7" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Sara Smith</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Cape Town, South Africa</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-6.webp" alt="IMG-6" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Katona Beatrix</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Rio de Janeiro, Brazil</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-5.webp" alt="IMG-5" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Kende Lili</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Sydney, Australia</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-4.webp" alt="IMG-4" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Kiss Dorka</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Tokyo, Japan</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-3.webp" alt="IMG-3" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Vincze Nikolett</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Paris, France</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-2.webp" alt="IMG-2" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Del Busquet</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Paris, France</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-1.webp" alt="IMG-1" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Bernaldo Silva</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Paris, France</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                        <li class="item candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                            <div class="candidates_info flex gap-4 w-full pb-4 border-b border-line">
                                <a href="../candidates/candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                                    <img src="../assets/images/avatar/IMG-10.webp" alt="IMG-10" class="candidates_avatar w-full h-full object-cover" />
                                </a>
                                <div class="candidates_content w-full">
                                    <div class="flex items-center justify-between gap-2 w-full">
                                        <a href="../candidates/candidates-detail" class="candidates_detail flex flex-col gap-0.5 duration-300 hover:text-primary">
                                            <strong class="candidates_name text-title -style-1">Victoria Bentric</strong>
                                            <span class="flex items-center text-secondary">
                                                <span class="ph ph-map-pin text-lg"></span>
                                                <span class="candidates_address -style-1 caption1 pl-1">Paris, France</span>
                                            </span>
                                        </a>
                                        <button class="btn_action btn_open_popup btn_delete relative flex flex-shrink-0 items-center justify-center w-10 h-10 border border-line rounded-full duration-300 hover:text-red hover:border-red" data-type="modal_delete">
                                            <span class="ph ph-trash text-xl"></span>
                                            <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                        </button>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-3 mt-2">
                                        <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                        <div class="flex items-center gap-1">
                                            <span class="ph-fill ph-star text-yellow text-sm"></span>
                                            <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                            <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                                <div class="flex flex-wrap items-center gap-2.5">
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                                    <a href="../candidates/candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                                </div>
                                <div class="candidates_price">
                                    <span class="price text-title">$20</span>
                                    <span class="text-secondary">/Hours</span>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <div class="flex flex-wrap items-center justify-between gap-4 p-6 border-t border-line">
                        <ul class="list_pagination menu_tab flex items-center justify-center gap-2 w-full md:mt-10 mt-7" role="tablist">
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black active" role="tab" aria-selected="true">1</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">2</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">3</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">></a>
                            </li>
                        </ul>
                        <p class="text-secondary whitespace-nowrap">Showing <span class="start">1</span> to <span class="end">9</span> of <span class="total">16</span> entries</p>
                    </div>
                </div>
            </div>
            <div class="lg:fixed bottom-0 left-0 z-[1] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
            </div>
        </div>
    </div>

   <!-- Menu mobile -->

   <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/apexcharts.js"></script>
    <script src="../assets/js/main.js"></script>
</body>

<!-- Mirrored from freelanhub.vercel.app/employers-alerts-candidate-detail by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Jan 2025 03:38:23 GMT -->

</html>