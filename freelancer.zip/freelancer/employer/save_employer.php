<?php
session_start();
include('../db-config.php');

// ✅ Check session
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page with redirect back to apply
    header("Location: login.php?redirect=save_employer");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request.");
}

// File upload handling
$avatarPath = '';
if (!empty($_FILES['avatar']['name'])) {
    $avatarName = time() . '_' . basename($_FILES['avatar']['name']);
    $avatarPath = 'uploads/' . $avatarName;
    if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $avatarPath)) {
        die("Failed to upload avatar.");
    }
}


// Validate and fetch POST data
$name = trim($_POST['name'] ?? '');
if (!$name) {
    die("Full name is required.");
}


// For simplicity, set other fields blank if not sent
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';
$founded = $_POST['founded'] ?? '';
$address = $_POST['address'] ?? '';
$category = $_POST['category'] ?? '';
$video_url = $_POST['video_url'] ?? '';
$website = $_POST['website'] ?? '';
$description = $_POST['description'] ?? '';
$company_size = $_POST['company_size'] ?? '';

// Prepare and execute SQL
$sql = "INSERT INTO employers (user_id,
    name, phone, email, founded,
    category, address, video_url, description,
    avatar_path, company_size
) VALUES (?,
    ?, ?, ?, ?,
    ?, ?, ?,?,
    ?, ?
)";

$stmt = $pdo->prepare($sql);

try {
    $stmt->execute([$user_id,
        $name, $phone, $email, $founded,
        $category, $address, $video_url, $description,
        $avatarPath, $company_size
    ]);
    echo "Application submitted successfully!";

    // Redirect to another page after 3 seconds (optional delay)
    header("Refresh: 1; URL=employers-profile");
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
