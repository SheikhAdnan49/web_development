<?php
// Include the database connection
include('db.php');

// Ensure the id parameter is valid
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    // SQL query to fetch data for the specific flight
    $sql = "SELECT * FROM `services` WHERE id = $id";
    $result = mysqli_query($conn, $sql);

    // Check if query execution was successful
    if (!$result) {
        echo 'Unable to get data: ' . mysqli_error($conn);
        exit;
    }

    // Fetch the data as an associative array
    $data = mysqli_fetch_assoc($result);

    // Reset result pointer for further fetching if needed (if you want to use mysqli_fetch_row)
    mysqli_data_seek($result, 0);
} else {
    echo 'Invalid ID parameter.';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/css/leaflet.css" />
    <link rel="stylesheet" href="assets/css/slick.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="dist/output-tailwind.css" />
    <link rel="stylesheet" href="dist/output-scss.css" />
</head>

<body class="lg:overflow-unset">
    <!-- Header -->
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb bg-[#F9F2EC] sm:pt-35 pt-30 pb-15">
        <div class="container flex max-lg:flex-col lg:items-center justify-between gap-7 gap-y-2">
            <div class="services_info flex flex-wrap sm:gap-7 gap-4 w-full">
                <div class="overflow-hidden flex-shrink-0 sm:w-[100px] w-24 sm:h-[100px] h-24 rounded-full">
                    <img src="https://www.w3schools.com/howto/img_avatar.png" alt="avatar/IMG-13" class="services_avatar w-full h-full object-cover" />
                </div>
                <div class="flex flex-col gap-1 lg:w-[760px]">
                    <h3 class="services_name heading3">
                        <?php
                        if (isset($data)) {
                            echo htmlspecialchars($data['title']);
                        }
                        ?>
                    </h3>>
                    <div class="flex flex-wrap items-center gap-5 gap-y-1.5 mt-1">
                        <div class="services_review flex items-center gap-1">
                            <span class="ph-fill ph-star text-xl text-yellow"></span>
                            <strong class="text-button">4.8</strong>
                            <span class="review text-secondary">(751 review)</span>
                        </div>
                        <div class="services_date flex items-center gap-1">
                            <span class="ph-fill ph-crown-simple text-xl text-primary"></span>
                            <span>Top Rated</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_action flex flex-col max-lg:flex-col-reverse gap-2">
                <div class="flex max-sm:flex-wrap lg:justify-end gap-3">
                    <button class="button_share flex items-center justify-center w-12 h-12 border border-line rounded-full bg-white duration-300 hover:border-black">
                        <span class="ph ph-share-network text-2xl"></span>
                        <ul class="social">
                            <li class="social_item">
                                <a href="https://www.facebook.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-facebook"></span>
                                </a>
                            </li>
                            <li class="social_item">
                                <a href="https://www.linkedin.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-linkedin"></span>
                                </a>
                            </li>
                            <li class="social_item">
                                <a href="https://www.twitter.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-twitter"></span>
                                </a>
                            </li>
                        </ul>
                    </button>
                    <button class="add_wishlist_btn -relative -border w-12">
                        <span class="ph ph-heart text-2xl"></span>
                        <span class="ph-fill ph-heart text-2xl"></span>
                    </button>
                </div>
                <div class="flex items-center gap-3">
                    <span class="body2 text-secondary">From:</span>
                    <h5 class="heading5">$<?php
    if (isset($data)) {
        echo htmlspecialchars($data['start_price']);
    }
    ?></h5>
                </div>
            </div>
        </div>
    </section>

    <section class="services_detail lg:py-20 sm:py-14 py-10">
        <div class="container flex max-lg:flex-col gap-y-10">
            <div class="services_content w-full overflow-hidden lg:pr-15">
                <div class="images overflow-hidden w-full">
                    <div class="swiper swiper-thumb-images section-swiper-navigation rounded-xl">

                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <img src="assets/images//service/<?php
    if (isset($data)) {
        echo htmlspecialchars($data['image']);
    }
    ?>" alt="blog/1" class="w-full h-full object-cover" />
                            </div>


                        </div>

                    </div>

                </div>
                <div class="description md:mt-10 mt-7">
                    <h6 class="heading6">About service</h6>
                    <div class="flex flex-col gap-3 mt-3">
                        <p class="body2 text-secondary"><?php
    if (isset($data)) {
        echo htmlspecialchars($data['description_1']);
    }
    ?></p>
                        <p class="body2 text-secondary"><?php
    if (isset($data)) {
        echo htmlspecialchars($data['description_2']);
    }
    ?></p>
                    </div>
                </div>
                <div class="services md:mt-10 mt-7">
                    <h6 class="heading6">My Services:</h6>
                    <div class="list_services w-full mt-3">
                        <div class="flex body2 text-secondary">
                            <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                            <p><?php
    if (isset($data)) {
        echo htmlspecialchars($data['my_services']);
    }
    ?></p>
                        </div>

                    </div>
                </div>
                <div class="tags md:mt-10 mt-7">
                    <h6 class="heading6">Tags:</h6>
                    <ul class="list_tags flex flex-wrap gap-3 gap-y-5 mt-4">
                        <li>
                            <a href="services-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Website Design </a>
                        </li>
                        <li>
                            <a href="services-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Mobile App </a>
                        </li>
                        <li>
                            <a href="services-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Animation </a>
                        </li>
                        <li>
                            <a href="services-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Adobe Photoshop </a>
                        </li>
                        <li>
                            <a href="services-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Figma </a>
                        </li>
                    </ul>
                </div>
                <div class="about md:mt-15 mt-7">

                    <div class="portfolio md:mt-10 mt-7">


                        <div class="overflow-hidden rounded-lg">
                            <img src="assets/images/service/<?php
    if (isset($data)) {
        echo htmlspecialchars($data['image_2']);
    }
    ?>" alt="service/2" class="w-full h-full object-cover" />
                        </div>


                    </div>
                </div>
                <div class="compare_pricing md:mt-15 mt-7">
                    <h5 class="heading5">Compare pricing</h5>
                    <div class="list overflow-x-auto w-full mt-4 p-5 rounded-xl bg-surface">
                        <table class="w-full max-[560px]:w-[560px]">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th scope="col">
                                        <div class="item flex flex-col items-center gap-1 py-5">
                                            <span class="text-sm font-bold text-secondary">Starter</span>
                                            <strong class="heading5">50%</strong>
                                        </div>
                                    </th>
                                    <th scope="col">
                                        <div class="item flex flex-col items-center gap-1 py-5">
                                            <span class="text-sm font-bold text-secondary">Professional</span>
                                            <strong class="heading5">75%</strong>
                                        </div>
                                    </th>
                                    <th scope="col">
                                        <div class="item flex flex-col items-center gap-1 py-5">
                                            <span class="text-sm font-bold text-secondary">Executive</span>
                                            <strong class="heading5">100%</strong>
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Delivery time</th>
                                    <td class="p-4 bg-white text-title text-center">2 day</td>
                                    <td class="p-4 bg-white text-title text-center">3 day</td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">5 day</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg text-left font-normal">Number of revisions</th>
                                    <td class="p-4 text-title text-center">8 time</td>
                                    <td class="p-4 text-title text-center">20 time</td>
                                    <td class="p-4 rounded-r-lg text-title text-center">Unlimited</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Printable resolution file</th>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg text-left font-normal">Logo Design</th>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Branding</th>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg text-left font-normal">Mockup</th>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Vector file</th>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg text-left font-normal">Source Files</th>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Support life time</th>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="review md:mt-15 mt-8">
                    <div class="heading flex flex-wrap items-center justify-between gap-4">
                        <h5 class="heading5">Customer Review</h5>
                        <a href="#form-review" class="button-main -border">Write Reviews </a>
                    </div>
                    <div class="rating_area flex max-sm:flex-col justify-between gap-y-3 py-6">
                        <div class="flex flex-col items-center justify-center gap-1">
                            <h1 class="heading1 avg_rating">4.8</h1>
                            <div class="flex flex-col items-center gap-2">
                                <ul class="rate flex">
                                    <li class="ph-fill ph-star text-2xl text-yellow"></li>
                                    <li class="ph-fill ph-star text-2xl text-yellow"></li>
                                    <li class="ph-fill ph-star text-2xl text-yellow"></li>
                                    <li class="ph-fill ph-star text-2xl text-yellow"></li>
                                    <li class="ph-fill ph-star-half text-2xl text-yellow"></li>
                                </ul>
                                <span class="total_rating caption1">(1,968 Ratings)</span>
                            </div>
                        </div>
                        <div class="list_rating flex-shrink-0 xl:w-[465px] sm:w-[60%] w-full">
                            <div class="item flex items-center justify-between gap-3">
                                <div class="flex flex-shrink-0 items-center gap-1 min-w-7">
                                    <strong class="text-button-sm">5</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-[70%] h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">70%</strong>
                            </div>
                            <div class="item flex items-center justify-between gap-3 mt-1">
                                <div class="flex flex-shrink-0 items-center gap-1 min-w-7">
                                    <strong class="text-button-sm">4</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-[20%] h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">20%</strong>
                            </div>
                            <div class="item flex items-center justify-between gap-3 mt-1">
                                <div class="flex flex-shrink-0 items-center gap-1 min-w-7">
                                    <strong class="text-button-sm">3</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-[10%] h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">10%</strong>
                            </div>
                            <div class="item flex items-center justify-between gap-3 mt-1">
                                <div class="flex flex-shrink-0 items-center gap-1 min-w-7">
                                    <strong class="text-button-sm">2</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-0 h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">0%</strong>
                            </div>
                            <div class="item flex items-center justify-between gap-3 mt-1">
                                <div class="flex flex-shrink-0 items-center gap-2 min-w-7">
                                    <strong class="text-button-sm">1</strong>
                                    <span class="ph-fill ph-star text-sm text-yellow"></span>
                                </div>
                                <div class="progress bg-line relative w-full h-3">
                                    <div class="progress-percent absolute bg-primary w-0 h-full left-0 top-0"></div>
                                </div>
                                <strong class="percent flex-shrink-0 min-w-8 text-right text-button-sm">0%</strong>
                            </div>
                        </div>
                    </div>
                    
                    <div id="form-review" class="form-review md:pt-10 pt-7">
                        <h6 class="heading6">Leave A comment</h6>
                        <form class="form grid sm:grid-cols-2 gap-4 gap-y-5 mt-6" method="post" action="">
                            <div class="name">
                                <label for="username">Name</label>
                                <input class="w-full mt-2 px-4 py-3 border-line rounded-lg" id="username" type="text" placeholder="Your Name" required />
                            </div>
                            <div class="mail">
                                <label for="email">Email</label>
                                <input class="w-full mt-2 px-4 py-3 border-line rounded-lg" id="email" type="email" placeholder="Your Email" required />
                            </div>
                            <div class="col-span-full message">
                                <label for="message">Review</label>
                                <textarea class="border w-full mt-2 px-4 py-3 border-line rounded-lg" id="message" name="message" rows="3" placeholder="Write comment " required></textarea>
                            </div>
                            <div class="col-span-full flex items-start gap-2">
                                <input type="checkbox" id="saveAccount" name="saveAccount" class="mt-1.5" />
                                <label class="" for="saveAccount">Save my name, email, and website in this browser for the next time I comment.</label>
                            </div>
                            <div class="user_rating flex items-center gap-3 col-span-full">
                                <span>Your Rating:</span>
                                <ul class="list_rate flex gap-1">
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="1"></li>
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="2"></li>
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="3"></li>
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="4"></li>
                                    <li class="ph-fill ph-star star text-2xl text-line cursor-pointer" data-value="5"></li>
                                </ul>
                            </div>
                            <div class="col-span-full">
                                <button class="button-main">Post Comment</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
            <div class="pricing_sidebar lg:sticky lg:top-24 flex-shrink-0 lg:w-[380px] w-full h-fit rounded-xl overflow-hidden bg-white shadow-md duration-300">
                <div class="compare_pricing md:mt-15 mt-5">
                    <h5 class="heading5">Compare pricing</h5>
                    <div class="list overflow-x-auto w-full mt-4 p-5 rounded-xl bg-surface">
                        <table class="w-full max-[560px]:w-[560px]">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th scope="col">
                                        <div class="item flex flex-col items-center gap-1 py-5">
                                            <span class="text-sm font-bold text-secondary">Starter</span>
                                            <strong class="heading5">50%</strong>
                                        </div>
                                    </th>
                                    <th scope="col">
                                        <div class="item flex flex-col items-center gap-1 py-5">
                                            <span class="text-sm font-bold text-secondary">Professional</span>
                                            <strong class="heading5">75%</strong>
                                        </div>
                                    </th>
                                    <th scope="col">
                                        <div class="item flex flex-col items-center gap-1 py-5">
                                            <span class="text-sm font-bold text-secondary">Executive</span>
                                            <strong class="heading5">100%</strong>
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Delivery time</th>
                                    <td class="p-4 bg-white text-title text-center">2 day</td>
                                    <td class="p-4 bg-white text-title text-center">3 day</td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">5 day</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg text-left font-normal">Number of revisions</th>
                                    <td class="p-4 text-title text-center">8 time</td>
                                    <td class="p-4 text-title text-center">20 time</td>
                                    <td class="p-4 rounded-r-lg text-title text-center">Unlimited</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Printable resolution file</th>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg text-left font-normal">Logo Design</th>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Branding</th>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg text-left font-normal">Mockup</th>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Vector file</th>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg text-left font-normal">Source Files</th>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="p-4 rounded-l-lg bg-white text-left font-normal">Support life time</th>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-minus text-xl text-placehover"></span>
                                    </td>
                                    <td class="p-4 bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                    <td class="p-4 rounded-r-lg bg-white text-title text-center">
                                        <span class="ph-bold ph-check text-xl text-primary"></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    <!-- footer start  -->
    <?php include('footer.php'); ?>

    <!-- end  -->
    <!-- Menu mobile -->

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/phosphor-icons.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/leaflet.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>


</html>