<footer class="footer">
        <div class="footer_inner bg-feature">
            <div class="container">
                <div
                    class="footer_heading flex flex-wrap items-center justify-between gap-4 w-full md:pt-10 pt-7 md:pb-5 pb-4 border-b border-light">
                    <a href="index" class="footer_logo">
                        <img src="assets/images/logo-white.png" alt="logo-white" class="h-[42px] w-auto" />
                    </a>
                    <div class="list_social flex flex-wrap items-center gap-4">
                        <span class="text-subtitle text-white">Follow Us:</span>
                        <div class="list flex flex-wrap items-center gap-3">
                            <a href="https://www.facebook.com/" target="_blank"
                                class="w-10 h-10 flex items-center justify-center border border-light text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                <span class="icon-facebook text-lg"></span>
                            </a>
                            <a href="https://www.linkedin.com/" target="_blank"
                                class="w-10 h-10 flex items-center justify-center border border-light text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                <span class="icon-linkedin text-lg"></span>
                            </a>
                            <a href="https://www.twitter.com/" target="_blank"
                                class="w-10 h-10 flex items-center justify-center border border-light text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                <span class="icon-twitter text-lg"></span>
                            </a>
                            <a href="https://www.instagram.com/" target="_blank"
                                class="w-10 h-10 flex items-center justify-center border border-light text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                <span class="icon-instagram text-lg"></span>
                            </a>
                            <a href="https://www.pinterest.com/" target="_blank"
                                class="w-10 h-10 flex items-center justify-center border border-light text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                <span class="icon-pinterest text-lg"></span>
                            </a>
                            <a href="https://www.youtube.com/" target="_blank"
                                class="w-10 h-10 flex items-center justify-center border border-light text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                <span class="icon-youtube text-lg"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="footer_content flex max-xl:flex-wrap items-start justify-between gap-y-8 md:py-10 py-7">
                    <div class="footer_nav max-md:w-1/2">
                        <strong class="nav_heading text-button-sm text-white">Categories</strong>
                        <ul class="list_nav flex flex-col gap-3 mt-4">
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="jobs-default">Graphics & Design</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="jobs-default">Digital Marketing</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="jobs-default">Writing & Translation</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="jobs-default">Video & Animation</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="jobs-default">Music & Audio</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="jobs-default">Programming & Tech</a></li>
                        </ul>
                    </div>
                    <div class="footer_nav max-md:w-1/2">
                        <strong class="nav_heading text-button-sm text-white">For Candidates</strong>
                        <ul class="list_nav flex flex-col gap-3 mt-4">
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="candidates/candidates-dashboard">Candidate Dashboard</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="jobs-grid">Browse jobs</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="employer/employers-list">Browse employers</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="candidates/candidates-proposals">My Proposals</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="services-list">My Services</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="candidates/candidates-jobs-alerts">Job Alerts</a></li>
                        </ul>
                    </div>
                    <div class="footer_nav max-md:w-1/2">
                        <strong class="nav_heading text-button-sm text-white">For Employer</strong>
                        <ul class="list_nav flex flex-col gap-3 mt-4">
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="employer/employers-dashboard">Employer Dashboard</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="candidates/candidates-list">Browse Candidates</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="services-list">Browse services</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="employer/employers-submit-jobs">Submit jobs</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="employer/employers-jobs">My Jobs</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="employer/employers-applicants-jobs">Applicants jobs</a></li>
                        </ul>
                    </div>
                    <div class="footer_nav max-md:w-1/2">
                        <strong class="nav_heading text-button-sm text-white">Support</strong>
                        <ul class="list_nav flex flex-col gap-3 mt-4">
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="term-of-use">Help & Support</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="become-seller">Selling On FreelanHub</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="become-buyer">Buying On FreelanHub</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="about">About Us</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="faqs">FAQs</a></li>
                            <li><a class="caption1 capitalize line-before line-white text-placehover hover:text-white duration-300"
                                    href="contact">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="flex-shrink-0 max-xl:w-full">
                        <div class="company-contact sm:w-[340px]">
                            <strong class="heading block text-button-sm text-white">Subscribe</strong>
                            <form class="send-block mt-4 flex items-center h-[46px] rounded-lg overflow-hidden">
                                <input class="caption1 text-secondary h-full w-full pr-4 pl-3" type="email"
                                    placeholder="Your email address" required />
                                <button
                                    class="flex items-center justify-center w-[46px] h-[46px] bg-primary flex-shrink-0">
                                    <span class="ph ph-paper-plane-tilt text-white"></span>
                                </button>
                            </form>
                            <strong class="heading block text-button-sm text-white mt-5">Download App</strong>
                            <div class="list-download flex items-start gap-3 mt-4">
                                <a href="https://play.google.com/" target="_blank">
                                    <img src="assets/images/download/gg_play.png" alt="gg_play" />
                                </a>
                                <a href="https://www.apple.com/app-store/" target="_blank">
                                    <img src="assets/images/download/app_store.png" alt="app_store" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="footer_bottom flex items-center justify-between max-sm:flex-col gap-2 py-2 border-t border-light">
                    <div class="left-block flex items-center">
                        <div class="copyright text-placehover caption1">©2024 FreelanHub. All Rights Reserved.</div>
                    </div>
                    <div class="nav-link flex items-center gap-2.5">
                        <a class="text-placehover caption1 hover-underline" href="term-of-use">Terms Of
                            Services</a>
                        <span class="text-placehover caption1">|</span>
                        <a class="text-placehover caption1 hover-underline" href="term-of-use">Privacy Policy</a>
                    </div>
                </div>
            </div>
        </div>


    <a href="tel:+923081579248" class="mobile-call-button">
        <div>
            <h3> 03081579248 </h3>
            <p class="call-availability">We are open 24 hours a day, 7 days a week</p>
        </div>
    </a>

    <!-- WhatsApp Button -->
    <a href="https://wa.me/+923151066800" target="_blank" class="whatsapp-button">
        <img src="assets/images/whatsapp.webp" alt="WhatsApp" />
    </a>

    </footer>

    <div class="menu_mobile">
        <button
            class="menu_mobile_close flex items-center justify-center absolute top-5 left-5 w-8 h-8 rounded-full bg-surface">
            <span class="ph-bold ph-x"></span>
        </button>
        <div class="heading flex items-center justify-center mt-5">
            <a href="index" class="logo">
                <img src="assets/images/logo.png" alt="logo" class="h-8" />
            </a>
        </div>
        <form class="form-search relative mt-4 mx-5">
            <button class="absolute left-3 top-1/2 -translate-y-1/2 cursor-pointer">
                <i class="ph ph-magnifying-glass text-xl block"></i>
            </button>
            <input type="text" placeholder="What are you looking for?"
                class="h-12 rounded-lg border border-line text-sm w-full pl-10 pr-4" required />
        </form>
        <div class="mt-4">
            <ul class="nav_mobile">
                <li class="nav_item py-2">
                    <a href="index" class="text-xl font-semibold flex items-center justify-between">
                        Home

                    </a>

                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        For Candidates
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li class="nav_item">
                                    <a href="jobs-grid"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse jobs

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="project-list"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse Projects

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="employer/employers-list"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse Employer

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="become-seller"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Become a seller </a>
                                </li>
                                <li class="nav_item">
                                    <a href="candidates/candidates-dashboard"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Candidates Dashboard </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        For Employers
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li class="nav_item">
                                    <a href="services-list"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse services

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="candidates/candidates-list"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse candidates

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="become-buyer"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Become a buyer </a>
                                </li>
                                <li class="nav_item">
                                    <a href="employer/employers-dashboard"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        employer Dashboard </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        Blogs
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <br>
                                <li>
                                    <a href="blog-list" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Blog list </a>
                                </li>

                                <li>
                                    <a href="blog-detail"
                                        class="inline-block text-xl font-semibold py-2 capitalize"> Blog detail </a>
                                </li>
                                <br><br><br>

                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        Pages
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li>
                                    <a href="about" class="inline-block text-xl font-semibold py-2 capitalize">
                                        About Us </a>
                                </li>

                                <li>
                                    <a href="pricing" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Pricing Plan </a>
                                </li>
                                <li>
                                    <a href="contact" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Contact Us </a>
                                </li>

                                <li>
                                    <a href="faqs" class="inline-block text-xl font-semibold py-2 capitalize"> Faqs
                                    </a>
                                </li>
                                <li>
                                    <a href="term-of-use "
                                        class="inline-block text-xl font-semibold py-2 capitalize"> Terms of use </a>
                                </li>

                                <li>
                                    <a href="login" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Login </a>   
                                </li>
                                <li>
                                    <a href="register" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Register </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
