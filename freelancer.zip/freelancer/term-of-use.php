<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/css/leaflet.css" />
    <link rel="stylesheet" href="assets/css/slick.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="dist/output-tailwind.css" />
    <link rel="stylesheet" href="dist/output-scss.css" />
</head>

<body class="lg:overflow-unset">
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="breadcrumb_inner sm:pt-20 pt-16">
            <div class="content relative w-full h-full">
                <div class="breadcrumb_bg absolute top-0 left-0 w-full h-full">
                    <img src="assets/images/components/breadcrumb_candidate.webp" alt="breadcrumb_candidate"
                        class="w-full h-full object-cover" />
                </div>
                <div class="container relative h-full lg:py-20 sm:py-14 py-10">
                    <div
                        class="breadcrumb_content flex flex-col items-start justify-center xl:w-[1000px] lg:w-[848px] md:w-5/6 w-full h-full">
                        <div class="list_breadcrumb flex items-center gap-2 animate animate_top" style="--i: 1">
                            <a href="index" class="caption1 text-white">Home</a>
                            <span class="caption1 text-white opacity-40">/</span>
                            <span class="caption1 text-white">Pages</span>
                            <span class="caption1 text-white opacity-40">/</span>
                            <span class="caption1 text-white opacity-60">Terms of use</span>
                        </div>
                        <h3 class="heading3 text-white mt-2 animate animate_top" style="--i: 2">Terms of use</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Terms of use -->
    <section class="terms_of_use lg:py-20 sm:py-14 py-10">
        <div class="container flex max-lg:flex-col justify-between gap-15 gap-y-10">
            <div class="list_link lg:sticky lg:top-24 lg:w-[360px] w-full h-fit">
                <ul class="menu_tab flex flex-col flex-shrink-0 gap-3 border-l border-line">
                    <li>
                        <a href="#term"
                            class="tab_btn inline-block heading6 py-2.5 pl-4 border-l-4 border-transparent duration-300">1.
                            Terms</a>
                    </li>
                    <li>
                        <a href="#limitations"
                            class="tab_btn inline-block heading6 py-2.5 pl-4 border-l-4 border-transparent duration-300">2.
                            Limitations</a>
                    </li>
                    <li>
                        <a href="#revisions"
                            class="tab_btn inline-block heading6 py-2.5 pl-4 border-l-4 border-transparent duration-300">3.
                            Revisions and Corrections</a>
                    </li>
                    <li>
                        <a href="#modifications"
                            class="tab_btn inline-block heading6 py-2.5 pl-4 border-l-4 border-transparent duration-300">4.
                            Site terms of use modifications</a>
                    </li>
                    <li>
                        <a href="#risks"
                            class="tab_btn inline-block heading6 py-2.5 pl-4 border-l-4 border-transparent duration-300">5.
                            Risks</a>
                    </li>
                </ul>
            </div>
            <div id="term" class="content w-full">
                <h3 class="heading3">Terms of use</h3>
                <div id="limitations" class="section pt-10">
                    <h5 class="heading5">1. Terms</h5>
                    <div class="desc flex flex-col gap-3 mt-3">
                        <p class="body2 text-secondary">"Freelancer terms and conditions are crucial for project
                            clarity. Both clients and freelancers must respect agreed deadlines, payment terms, and
                            project scopes. Disputes should be resolved promptly, and professional communication is
                            essential for maintaining successful collaborations."</p>
                        <p class="body2 text-secondary">It should maintain professionalism, ensuring effective
                            communication and meeting deadlines. Clients must provide clear project descriptions and
                            feedback. Disputes should be handled according to platform policies, and all parties must
                            respect agreed payment terms for a smooth working relationship.</p>
                        <p class="body2 text-secondary">Freelancers are expected to deliver high-quality work on time
                            and in accordance with the agreed terms. Clients must provide timely payments and
                            constructive feedback. Both parties should follow platform guidelines to ensure a positive
                            experience and resolve issues effectively.</p>
                    </div>
                </div>
                <div id="revisions" class="section pt-8">
                    <h5 class="heading5">2. Limitations</h5>
                    <div class="desc flex flex-col gap-3 mt-3">
                        <p class="body2 text-secondary">Freelancers and clients are limited by the platform’s terms and
                            conditions. Any breach of contract, failure to meet deadlines, or unsatisfactory work may
                            result in penalties or suspension. The platform cannot be held responsible for issues
                            outside its control, such as delays or disputes between parties.</p>
                        <ul class="flex flex-col gap-3 mt-4">
                            <li class="flex body2">
                                <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                                <p>Freelancers and clients are bound by the platform's terms, with limitations on
                                    behavior and contract breaches.</p>
                            </li>
                            <li class="flex body2">
                                <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                                <p>The platform is not responsible for delays, disputes, or issues outside its control.
                                </p>
                            </li>
                            <li class="flex body2">
                                <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                                <p>Penalties may apply for failure to meet agreed deadlines or deliverables.</p>
                            </li>
                        </ul>
                        <p class="body2 text-secondary">Under the "Limitation" section, both freelancers and clients
                            must adhere to the platform's terms and guidelines. The platform is not liable for issues
                            beyond its control, such as external delays or disputes. Any failure to meet deadlines,
                            project requirements, or contractual obligations may result in penalties or account
                            suspension.</p>
                    </div>
                </div>
                <div id="modifications" class="section pt-8">
                    <h5 class="heading5">3. Revisions and Corrections</h5>
                    <div class="desc flex flex-col gap-3 mt-3">
                        <p class="body2 text-secondary">Revisions are an essential part of the freelancing process,
                            ensuring that the final deliverable meets the client’s expectations. Freelancers are
                            expected to make reasonable revisions as agreed in the contract, within the specified time
                            frame. Clients should provide clear feedback to facilitate the revision process. Any
                            significant changes outside the initial scope may incur additional charges.</p>
                        <p class="body2 text-secondary">In cases of errors or discrepancies in the deliverable,
                            freelancers are responsible for correcting them promptly. If a mistake is identified,
                            clients should inform the freelancer as soon as possible, allowing them time to resolve the
                            issue. Revisions related to errors will generally be made without extra cost, depending on
                            the agreement. Open communication between both parties is key to preventing
                            misunderstandings.</p>
                        <p class="body2 text-secondary">The platform encourages transparency in revisions and error
                            resolution to maintain a professional working relationship. If revisions are requested, both
                            the client and freelancer should be clear about the expectations and timelines. Any
                            corrections or adjustments should be documented to avoid further confusion. It is important
                            to address revisions swiftly to ensure project completion on time.</p>
                    </div>
                </div>
                <div id="risks" class="section pt-8">
                    <h5 class="heading5">4. Site terms of use modifications</h5>
                    <div class="desc flex flex-col gap-3 mt-3">
                        <p class="body2 text-secondary">The platform reserves the right to modify or update the terms of
                            use at any time. Changes will be communicated to users through notifications or updated
                            documents on the site. Continued use of the site after modifications indicates acceptance of
                            the new terms.</p>
                        <ul class="flex flex-col gap-3 mt-4">
                            <li class="flex body2">
                                <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                                <p>The platform can modify terms without prior notice to users.</p>
                            </li>
                            <li class="flex body2">
                                <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                                <p>Users are encouraged to review the terms regularly to stay informed.</p>
                            </li>
                            <li class="flex body2">
                                <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                                <p>Acceptance of changes is implied by continued site usage after updates.</p>
                            </li>
                        </ul>
                        <p class="body2 text-secondary">It is the user's responsibility to regularly review the terms
                            for any changes. Modifications may include updates to policies, payment procedures, or
                            platform features. The platform ensures that all changes comply with legal and regulatory
                            requirements.</p>
                    </div>
                </div>
                <div class="section pt-8">
                    <h5 class="heading5">5. Risks</h5>
                    <div class="desc flex flex-col gap-3 mt-3">
                        <p class="body2 text-secondary">Engaging in freelance work comes with inherent risks, including
                            the possibility of delayed or incomplete deliveries. Clients should set clear expectations
                            to minimize misunderstandings and ensure timely project completion.</p>
                        <p class="body2 text-secondary">Freelancers may face challenges, such as receiving unclear
                            project requirements or payment disputes. It’s essential to have a well-defined contract to
                            reduce the risk of miscommunication and ensure fair compensation.</p>
                        <p class="body2 text-secondary">Both parties should be aware of the platform’s dispute
                            resolution process in case of conflicts. While the platform can assist, it cannot guarantee
                            outcomes, and both freelancers and clients bear responsibility for managing risks.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    <!-- footer start  -->
    <?php include('footer.php'); ?>

    <!-- end  -->

    <!-- Menu mobile -->
    

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/phosphor-icons.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/leaflet.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>


</html>