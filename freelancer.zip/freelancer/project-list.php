<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/css/leaflet.css" />
    <link rel="stylesheet" href="assets/css/slick.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="dist/output-tailwind.css" />
    <link rel="stylesheet" href="dist/output-scss.css" />
</head>

<body>
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="breadcrumb_inner relative sm:mt-20 mt-16 py-15">
            <div class="breadcrumb_bg absolute top-0 left-0 w-full h-full">
                <img src="assets/images/components/breadcrumb_project.webp" alt="breadcrumb_project" class="w-full h-full object-cover" />
            </div>
            <div class="container relative h-full">
                <div class="breadcrumb_content flex flex-col items-start justify-center lg:w-[848px] md:w-5/6 w-full h-full">
                    <div class="list_breadcrumb flex items-center gap-2 animate animate_top" style="--i: 1">
                        <a href="index" class="caption1 text-white">Home</a>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white">For Candidates</span>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white opacity-60">Projects</span>
                    </div>
                    <h3 class="heading3 text-white mt-2 animate animate_top" style="--i: 2">Project list</h3>
                    <div class="form_search w-full mt-5 animate animate_top" style="--i: 3">
                        <form class="form_inner flex items-center justify-between max-sm:flex-wrap gap-6 gap-y-4 relative w-full p-3 rounded-lg bg-white">
                            <div class="form_input relative w-full">
                                <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-2 text-xl"></span>
                                <input type="text" class="input_search w-full h-full pl-10" placeholder="Job title, key words or company" required />
                            </div>
                            <button type="submit" class="button-main max-sm:w-1/3 text-center flex-shrink-0">Search</button>
                        </form>
                    </div>
                    <div class="list_tags flex flex-wrap items-center gap-3 mt-5 animate animate_top" style="--i: 4">
                        <strong class="text-button-sm text-white">Top Services:</strong>
                        <a href="project-default" class="tag -small -border text-white text-button-sm hover:bg-white hover:text-black">Graphics</a>
                        <a href="project-default" class="tag -small -border text-white text-button-sm hover:bg-white hover:text-black">Website</a>
                        <a href="project-default" class="tag -small -border text-white text-button-sm hover:bg-white hover:text-black">Logo</a>
                        <a href="project-default" class="tag -small -border text-white text-button-sm hover:bg-white hover:text-black">Developement</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- List projects -->
    <div class="project lg:py-20 sm:py-14 py-10">
        <div class="container flex flex-col items-center">
            <div class="filter flex flex-wrap items-center justify-between gap-8 gap-y-3 relative w-full">
                <button id="filter_btn" class="filter_btn inline-flex items-center gap-1.5 py-1.5 px-2.5 border border-line rounded-md duration-300 hover:bg-primary hover:text-white">
                    <span class="ph ph-sliders-horizontal text-xl"></span>
                    <span>Filters</span>
                </button>
                <ul class="list_layout flex items-center gap-1 sm:absolute sm:left-1/2 sm:-translate-x-1/2">
                    <li class="max-xl:hidden">
                        <button class="layout_btn cols_2 active"></button>
                    </li>
                    <li class="max-xl:hidden">
                        <button class="layout_btn cols_1 list"></button>
                    </li>
                    <li class="xl:hidden">
                        <a href="project-default" class="layout_link cols_2"></a>
                    </li>
                    <li class="xl:hidden">
                        <a href="#!" class="layout_link list active"></a>
                    </li>
                </ul>
                <div class="select_filter flex items-center gap-3">
                    <span class="caption1">Sort by:</span>
                    <div class="select_block sm:pr-16 pr-10 pl-3 py-1 border border-line rounded">
                        <div class="select">
                            <span class="selected caption1 capitalize" data-title="sort default">default</span>
                            <ul class="list_option p-0 bg-white">
                                <li class="capitalize" data-item="default">sort by (default)</li>
                                <li class="capitalize" data-item="newest">newest</li>
                                <li class="capitalize" data-item="oldest">oldest</li>
                                <li class="capitalize" data-item="random">random</li>
                            </ul>
                        </div>
                        <span class="icon_down ph ph-caret-down right-3"></span>
                    </div>
                </div>
            </div>
            <div class="list_filtered flex flex-wrap items-center gap-3 w-full mt-5">
                <span class="quantity pr-3 border-r border-line">1,200+ Results</span>
                <div class="list flex flex-wrap items-center gap-3"></div>
                <button class="clear_all_btn inline-flex items-center gap-1 py-1 px-2 border border-red text-red rounded-full duration-300 hover:bg-red hover:text-white">
                    <span class="ph ph-x text-sm"></span>
                    <span class="caption1">Clear All</span>
                </button>
            </div>
            <ul class="list_layout_cols list_project grid lg:grid-cols-2 grid-cols-1 sm:gap-7.5 gap-5 md:mt-10 mt-7">
                <li class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                    <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                        <div class="project_info">
                            <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Figma mockup needed for a new website for Electrica</a>
                            <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                <div class="project_date flex items-center gap-1">
                                    <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                    <span class="caption1 text-secondary">2 days ago</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <span class="ph ph-map-pin text-xl text-secondary"></span>
                                    <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                </div>
                                <div class="project_spent flex items-center gap-1">
                                    <span class="caption1 text-secondary">$</span>
                                    <span class="caption1 text-secondary">2.8K</span>
                                    <span class="caption1 text-secondary">spent</span>
                                </div>
                            </div>
                            <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                            <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                            </div>
                        </div>
                        <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                        <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                            <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                            <div class="max-sm:w-full max-sm:order-[-1]">
                                <div class="project_proposals sm:text-end">
                                    <span class="text-secondary">Proposals: </span>
                                    <span class="proposals">50+</span>
                                </div>
                                <div class="project_price sm:text-end mt-1">
                                    <span class="price text-title">$170</span>
                                    <span class="text-secondary">/fixed-price</span>
                                </div>
                            </div>
                            <a href="project-detail" class="button-main -border h-fit">See more</a>
                        </div>
                    </div>
                </li>
                <li class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                    <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                        <div class="project_info">
                            <a href="project-detail" class="project_name heading6 duration-300 hover:underline">I need you to design a email confirming for a ticket buying</a>
                            <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                <div class="project_date flex items-center gap-1">
                                    <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                    <span class="caption1 text-secondary">2 days ago</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <span class="ph ph-map-pin text-xl text-secondary"></span>
                                    <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                </div>
                                <div class="project_spent flex items-center gap-1">
                                    <span class="caption1 text-secondary">$</span>
                                    <span class="caption1 text-secondary">2.8K</span>
                                    <span class="caption1 text-secondary">spent</span>
                                </div>
                            </div>
                            <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                            <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                            </div>
                        </div>
                        <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                        <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                            <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                            <div class="max-sm:w-full max-sm:order-[-1]">
                                <div class="project_proposals sm:text-end">
                                    <span class="text-secondary">Proposals: </span>
                                    <span class="proposals">50+</span>
                                </div>
                                <div class="project_price sm:text-end mt-1">
                                    <span class="price text-title">$170</span>
                                    <span class="text-secondary">/fixed-price</span>
                                </div>
                            </div>
                            <a href="project-detail" class="button-main -border h-fit">See more</a>
                        </div>
                    </div>
                </li>
                <li class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                    <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                        <div class="project_info">
                            <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Website Design for an Online Tutoring Website</a>
                            <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                <div class="project_date flex items-center gap-1">
                                    <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                    <span class="caption1 text-secondary">2 days ago</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <span class="ph ph-map-pin text-xl text-secondary"></span>
                                    <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                </div>
                                <div class="project_spent flex items-center gap-1">
                                    <span class="caption1 text-secondary">$</span>
                                    <span class="caption1 text-secondary">2.8K</span>
                                    <span class="caption1 text-secondary">spent</span>
                                </div>
                            </div>
                            <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                            <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                            </div>
                        </div>
                        <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                        <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                            <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                            <div class="max-sm:w-full max-sm:order-[-1]">
                                <div class="project_proposals sm:text-end">
                                    <span class="text-secondary">Proposals: </span>
                                    <span class="proposals">50+</span>
                                </div>
                                <div class="project_price sm:text-end mt-1">
                                    <span class="price text-title">$170</span>
                                    <span class="text-secondary">/fixed-price</span>
                                </div>
                            </div>
                            <a href="project-detail" class="button-main -border h-fit">See more</a>
                        </div>
                    </div>
                </li>
                <li class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                    <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                        <div class="project_info">
                            <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Web Designer to Redesign the First Screen of the Main Page</a>
                            <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                <div class="project_date flex items-center gap-1">
                                    <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                    <span class="caption1 text-secondary">2 days ago</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <span class="ph ph-map-pin text-xl text-secondary"></span>
                                    <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                </div>
                                <div class="project_spent flex items-center gap-1">
                                    <span class="caption1 text-secondary">$</span>
                                    <span class="caption1 text-secondary">2.8K</span>
                                    <span class="caption1 text-secondary">spent</span>
                                </div>
                            </div>
                            <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                            <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                            </div>
                        </div>
                        <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                        <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                            <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                            <div class="max-sm:w-full max-sm:order-[-1]">
                                <div class="project_proposals sm:text-end">
                                    <span class="text-secondary">Proposals: </span>
                                    <span class="proposals">50+</span>
                                </div>
                                <div class="project_price sm:text-end mt-1">
                                    <span class="price text-title">$170</span>
                                    <span class="text-secondary">/fixed-price</span>
                                </div>
                            </div>
                            <a href="project-detail" class="button-main -border h-fit">See more</a>
                        </div>
                    </div>
                </li>
                <li class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                    <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                        <div class="project_info">
                            <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Web & Responsive for an Online Tutoring Website</a>
                            <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                <div class="project_date flex items-center gap-1">
                                    <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                    <span class="caption1 text-secondary">2 days ago</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <span class="ph ph-map-pin text-xl text-secondary"></span>
                                    <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                </div>
                                <div class="project_spent flex items-center gap-1">
                                    <span class="caption1 text-secondary">$</span>
                                    <span class="caption1 text-secondary">2.8K</span>
                                    <span class="caption1 text-secondary">spent</span>
                                </div>
                            </div>
                            <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                            <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                            </div>
                        </div>
                        <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                        <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                            <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                            <div class="max-sm:w-full max-sm:order-[-1]">
                                <div class="project_proposals sm:text-end">
                                    <span class="text-secondary">Proposals: </span>
                                    <span class="proposals">50+</span>
                                </div>
                                <div class="project_price sm:text-end mt-1">
                                    <span class="price text-title">$170</span>
                                    <span class="text-secondary">/fixed-price</span>
                                </div>
                            </div>
                            <a href="project-detail" class="button-main -border h-fit">See more</a>
                        </div>
                    </div>
                </li>
                <li class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                    <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                        <div class="project_info">
                            <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Web Designer to Redesign the First Screen of the Main Page</a>
                            <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                <div class="project_date flex items-center gap-1">
                                    <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                    <span class="caption1 text-secondary">2 days ago</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <span class="ph ph-map-pin text-xl text-secondary"></span>
                                    <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                </div>
                                <div class="project_spent flex items-center gap-1">
                                    <span class="caption1 text-secondary">$</span>
                                    <span class="caption1 text-secondary">2.8K</span>
                                    <span class="caption1 text-secondary">spent</span>
                                </div>
                            </div>
                            <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                            <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                            </div>
                        </div>
                        <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                        <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                            <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                            <div class="max-sm:w-full max-sm:order-[-1]">
                                <div class="project_proposals sm:text-end">
                                    <span class="text-secondary">Proposals: </span>
                                    <span class="proposals">50+</span>
                                </div>
                                <div class="project_price sm:text-end mt-1">
                                    <span class="price text-title">$170</span>
                                    <span class="text-secondary">/fixed-price</span>
                                </div>
                            </div>
                            <a href="project-detail" class="button-main -border h-fit">See more</a>
                        </div>
                    </div>
                </li>
                <li class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                    <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                        <div class="project_info">
                            <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Web & Responsive for an Online Tutoring Website</a>
                            <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                <div class="project_date flex items-center gap-1">
                                    <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                    <span class="caption1 text-secondary">2 days ago</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <span class="ph ph-map-pin text-xl text-secondary"></span>
                                    <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                </div>
                                <div class="project_spent flex items-center gap-1">
                                    <span class="caption1 text-secondary">$</span>
                                    <span class="caption1 text-secondary">2.8K</span>
                                    <span class="caption1 text-secondary">spent</span>
                                </div>
                            </div>
                            <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                            <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                            </div>
                        </div>
                        <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                        <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                            <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                            <div class="max-sm:w-full max-sm:order-[-1]">
                                <div class="project_proposals sm:text-end">
                                    <span class="text-secondary">Proposals: </span>
                                    <span class="proposals">50+</span>
                                </div>
                                <div class="project_price sm:text-end mt-1">
                                    <span class="price text-title">$170</span>
                                    <span class="text-secondary">/fixed-price</span>
                                </div>
                            </div>
                            <a href="project-detail" class="button-main -border h-fit">See more</a>
                        </div>
                    </div>
                </li>
                <li class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                    <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                        <div class="project_info">
                            <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Figma mockup needed for a new website for Electrical contractor business website</a>
                            <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                <div class="project_date flex items-center gap-1">
                                    <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                    <span class="caption1 text-secondary">2 days ago</span>
                                </div>
                                <div class="flex items-center gap-1">
                                    <span class="ph ph-map-pin text-xl text-secondary"></span>
                                    <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                </div>
                                <div class="project_spent flex items-center gap-1">
                                    <span class="caption1 text-secondary">$</span>
                                    <span class="caption1 text-secondary">2.8K</span>
                                    <span class="caption1 text-secondary">spent</span>
                                </div>
                            </div>
                            <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                            <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                            </div>
                        </div>
                        <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                        <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                            <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                            <div class="max-sm:w-full max-sm:order-[-1]">
                                <div class="project_proposals sm:text-end">
                                    <span class="text-secondary">Proposals: </span>
                                    <span class="proposals">50+</span>
                                </div>
                                <div class="project_price sm:text-end mt-1">
                                    <span class="price text-title">$170</span>
                                    <span class="text-secondary">/fixed-price</span>
                                </div>
                            </div>
                            <a href="project-detail" class="button-main -border h-fit">See more</a>
                        </div>
                    </div>
                </li>
            </ul>
            <ul class="list_pagination menu_tab flex items-center justify-center gap-2 w-full md:mt-10 mt-7" role="tablist">
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black active" role="tab" aria-selected="true">1</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">2</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">3</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">></a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    <!-- footer start  -->
    <?php include('footer.php'); ?>

    <!-- end  -->

    <!-- Menu mobile -->
    
    <!-- Modal -->
    <div class="modal">
        <div class="sidebar min-[390px]:w-[348px] w-[80vw] h-full bg-white">
            <form class="h-full">
                <div class="block_filter h-full py-4 px-6">
                    <div class="filter_section search">
                        <strong class="text-button">search</strong>
                        <div class="form_input relative w-full h-12 mt-2">
                            <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-xl"></span>
                            <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Job title, key words or company" />
                        </div>
                    </div>
                    <div class="filter_section category relative z-[2] mt-6">
                        <strong class="text-button">category</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select category">Select category</span>
                                <div class="list_option w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find category..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="Accounting & Consulting">Accounting & Consulting</li>
                                        <li class="capitalize" data-item="Admin Support">Admin Support</li>
                                        <li class="capitalize" data-item="Customer Service">Customer Service</li>
                                        <li class="capitalize" data-item="Design & Creative">Design & Creative</li>
                                        <li class="capitalize" data-item="Data Science & Analytics">Data Science & Analytics</li>
                                        <li class="capitalize" data-item="Design & Creative">Design & Creative</li>
                                        <li class="capitalize" data-item="Engineering & Architecture">Engineering & Architecture</li>
                                        <li class="capitalize" data-item="IT & Networking">IT & Networking</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="filter_section experience mt-6">
                        <strong class="text-button">Experience level</strong>
                        <div class="list_level flex flex-col gap-2 mt-2">
                            <div class="checkbox_block">
                                <input type="checkbox" class="checkbox" id="entry" data-label="entry" />
                                <span class="ph-fill ph-check-square text-xl check_icon"></span>
                                <label class="label pl-6" for="entry">Entry Level</label>
                            </div>
                            <div class="checkbox_block">
                                <input type="checkbox" class="checkbox" id="intermediate" data-label="intermediate" />
                                <span class="ph-fill ph-check-square text-xl check_icon"></span>
                                <label class="label pl-6" for="intermediate">Intermediate</label>
                            </div>
                            <div class="checkbox_block">
                                <input type="checkbox" class="checkbox" id="expert" data-label="expert" />
                                <span class="ph-fill ph-check-square text-xl check_icon"></span>
                                <label class="label pl-6" for="expert">Expert</label>
                            </div>
                        </div>
                    </div>
                    <div class="filter_section filter_price mt-6">
                        <strong class="text-button">Filter by Fixed-Price</strong>
                        <div class="tow_bar_block mt-5">
                            <div class="progress"></div>
                        </div>
                        <div class="range_input">
                            <input class="input range_min" type="range" min="0" max="3000" value="0" />
                            <input class="input range_max" type="range" min="0" max="3000" value="3000" />
                        </div>
                        <div class="price_block flex items-center justify-between mt-4">
                            <div class="price_min flex items-center overflow-hidden relative w-32 h-10">
                                <span class="text-button text-secondary absolute top-1/2 -translate-y-1/2 left-3">$</span>
                                <input type="number" class="caption1 w-full h-full pl-7 pr-10 border border-line rounded-lg" value="0" />
                                <span class="caption1 text-placehover absolute top-1/2 -translate-y-1/2 right-3">min</span>
                            </div>
                            <span class="ph-bold ph-minus text-xl"></span>
                            <div class="price_max flex items-center overflow-hidden relative w-32 h-10">
                                <span class="text-button text-secondary absolute top-1/2 -translate-y-1/2 left-3">$</span>
                                <input type="number" class="caption1 w-full h-full pl-7 pr-10 border border-line rounded-lg" value="3000" />
                                <span class="caption1 text-placehover absolute top-1/2 -translate-y-1/2 right-3">max</span>
                            </div>
                        </div>
                    </div>
                    <div class="filter_section hourly mt-6">
                        <strong class="text-button">Filter by Hourly</strong>
                        <div class="hour_block flex items-center justify-between mt-2">
                            <div class="min flex items-center overflow-hidden relative w-32 h-10">
                                <span class="text-button text-secondary absolute top-1/2 -translate-y-1/2 left-3">$</span>
                                <input type="number" class="caption1 w-full h-full pl-7 pr-10 border border-line rounded-lg" />
                                <span class="caption1 text-placehover absolute top-1/2 -translate-y-1/2 right-3">min</span>
                            </div>
                            <span class="ph-bold ph-minus text-xl"></span>
                            <div class="max flex items-center overflow-hidden relative w-32 h-10">
                                <span class="text-button text-secondary absolute top-1/2 -translate-y-1/2 left-3">$</span>
                                <input type="number" class="caption1 w-full h-full pl-7 pr-10 border border-line rounded-lg" />
                                <span class="caption1 text-placehover absolute top-1/2 -translate-y-1/2 right-3">max</span>
                            </div>
                        </div>
                    </div>
                    <div class="filter_section location mt-6">
                        <strong class="text-button">Client Location</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select client location">Select client location</span>
                                <div class="list_option w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find location..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="Africa">Africa</li>
                                        <li class="capitalize" data-item="Americas">Americas</li>
                                        <li class="capitalize" data-item="Antarctica">Antarctica</li>
                                        <li class="capitalize" data-item="Asia">Asia</li>
                                        <li class="capitalize" data-item="Europe">Europe</li>
                                        <li class="capitalize" data-item="Oceania">Oceania</li>
                                        <li class="capitalize" data-item="Australia and New Zealand">Australia and New Zealand</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="filter_section timezone mt-6">
                        <strong class="text-button">Client timezone</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select client timezone">Select client timezone</span>
                                <div class="list_option -top w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find timezone..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="(UTC-11:00) Midway Island">(UTC-11:00) Midway Island</li>
                                        <li class="capitalize" data-item="(UTC-10:00) Hawaii">(UTC-10:00) Hawaii</li>
                                        <li class="capitalize" data-item="(UTC-08:00) Alaska">(UTC-08:00) Alaska</li>
                                        <li class="capitalize" data-item="(UTC-07:00) Pacific Time">(UTC-07:00) Pacific Time</li>
                                        <li class="capitalize" data-item="(UTC-07:00) Arizona">(UTC-07:00) Arizona</li>
                                        <li class="capitalize" data-item="(UTC-06:00) Mountain Time ">(UTC-06:00) Mountain Time</li>
                                        <li class="capitalize" data-item="(UTC-05:00) Eastern Time">(UTC-05:00) Eastern Time</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="filter_section english mt-6">
                        <strong class="text-button">English Level</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select english level">Select english level</span>
                                <div class="list_option -top w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find level..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="Basic">Basic</li>
                                        <li class="capitalize" data-item="Conversational">Conversational</li>
                                        <li class="capitalize" data-item="Fluent">Fluent</li>
                                        <li class="capitalize" data-item="Native Or Bilingual">Native Or Bilingual</li>
                                        <li class="capitalize" data-item="Professional">Professional</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                </div>
                <div class="block_btn absolute right-0 bottom-0 left-0 z-[1] bg-white h-[68px] py-2.5 px-6">
                    <button class="button-main w-full text-center">Find Projects</button>
                </div>
            </form>
        </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/phosphor-icons.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/leaflet.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

<!-- Mirrored from freelanhub.vercel.app/project-list by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Jan 2025 03:37:31 GMT -->

</html>