<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/apexcharts.css" />
    <link rel="stylesheet" href="../assets/css/quill.snow.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

  <body class="lg:overflow-hidden">
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">
        
        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

        <div class="dashboard_applied scrollbar_custom w-full bg-surface">
        <form action="apply.php" method="POST" class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8">

                <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 lg:hidden" data-type="menu_dashboard">
                    <span class="ph ph-squares-four text-xl"></span>
                    <strong class="text-button">Menu</strong>
                </button>
                <div class="heading flex flex-wrap items-center justify-between gap-4">
                    <h4 class="heading4 max-lg:mt-3">Edit profile</h4>
                    
                </div>
                <div class="cv_file p-8 mt-7.5 rounded-lg bg-white shadow-sm">
                    <h5 class="heading5">CV File</h5>
                    <ul class="list_file flex flex-wrap items-center gap-10 gap-y-5 mt-5">
                        <li class="item flex items-center gap-3">
                            <a href="#!" class="flex flex-shrink-0 items-center justify-between gap-3 min-[400px]:w-[276px] w-[220px] h-[76px] p-3 rounded-lg bg-surface duration-300 hover:bg-background">
                                <div class="overflow-hidden">
                                    <span class="text-sm font-bold text-secondary uppercase whitespace-nowrap">file_name_pdf</span>
                                    <strong class="block mt-1 text-title cursor-pointer">PDF</strong>
                                </div>
                                <span class="ph ph-file-pdf flex-shrink-0 text-4xl text-primary"></span>
                            </a>
                            <button class="btn_delete flex-shrink-0">
                                <span class="ph-bold ph-x text-2xl text-red block"></span>
                            </button>
                        </li>
                        <li class="item flex items-center gap-3">
                            <a href="#!" class="flex flex-shrink-0 items-center justify-between gap-3 min-[400px]:w-[276px] w-[220px] h-[76px] p-3 rounded-lg bg-surface duration-300 hover:bg-background">
                                <div class="overflow-hidden">
                                    <span class="text-sm font-bold text-secondary uppercase whitespace-nowrap">file_name_doc</span>
                                    <strong class="block mt-1 text-title cursor-pointer">DOC</strong>
                                </div>
                                <span class="ph ph-file-doc flex-shrink-0 text-4xl text-primary"></span>
                            </a>
                            <button class="btn_delete flex-shrink-0">
                                <span class="ph-bold ph-x text-2xl text-red block"></span>
                            </button>
                        </li>
                    </ul>
                    <div class="flex flex-wrap items-center gap-3 w-full mt-6">
                        <div class="upload_file flex items-center gap-3 w-[220px] px-3 py-2 border border-line rounded">
                            <label for="file_attached" class="caption2 py-1 px-3 rounded bg-line whitespace-nowrap cursor-pointer">Choose File</label>
                            <input type="file" name="file_attached" id="file_attached" class="caption2 cursor-pointer" />
                        </div>
                        <span class="caption1 text-secondary">Upload file PDF, Doc, Docx</span>
                    </div>
                </div>
                <div class="infomation p-8 mt-7.5 rounded-lg bg-white shadow-sm">
                    <h5 class="heading5">Infomation</h5>
                    <div class="grid sm:grid-cols-2 gap-5 mt-5">
                        <div class="upload_image col-span-full">
                            <label for="uploadImage">Upload a new avatar: <span class="text-red">*</span></label>
                            <div class="flex flex-wrap items-center gap-5 mt-3">
                                <div class="bg_img flex-shrink-0 relative w-[7.5rem] h-[7.5rem] rounded-md overflow-hidden border border-dashed border-line bg-surface">
                                    <span class="ph ph-image text-5xl absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-secondary"></span>
                                    <img src="#" alt="preview img" class="upload_img relative z-[1] w-full h-full object-cover hidden" />
                                </div>
                                <div>
                                    <strong class="text-button">Upload Avatar</strong>
                                    <p class="caption1 text-secondary mt-1">JPG 320x240px</p>
                                    <div class="upload_file flex items-center gap-3 w-[220px] mt-3 px-3 py-2 border border-line rounded">
                                        <label for="uploadImage" class="caption2 py-1 px-3 rounded bg-line whitespace-nowrap cursor-pointer">Choose File</label>
                                        <input type="file" name="uploadImage" id="uploadImage" accept="image/*" class="caption2 cursor-pointer" required />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="full_name">
                            <label for="fullName">Full Name: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg capitalize" name="full_name" id="full_name" type="text" placeholder="Full Name..." value="" required />
                        </div>
                        <div class="birth">
                            <label for="dob">Date of birth: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="dob" id="dob" type="date" placeholder="Date of birth..." value="" required />
                        </div>
                        <div class="phone_number">
                            <label for="phoneNumber">Phone number: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="phone" id="phone" type="number" placeholder="Phone Number..." value="" required />
                        </div>
                        <div class="email_address">
                            <label for="emailAddress">Email address: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="email" id="email" type="email" placeholder="Email Address..." value="" required />
                        </div>
                        <div class="gender">
                            <label>Gender: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="gender" id="gender" type="text" placeholder="Gender..." value="" required />
                        </div>
                        <div class="age">
                            <label for="age">Age: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="age" id="age" type="number" placeholder="Age..." value="" required />
                        </div>
                        <div class="salary">
                            <label for="salary">Offered salary ($): <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="salary" id="salary" type="number" placeholder="Offered salary..." value="" required />
                        </div>
                        <div class="salary_type">
                            <label>Salary type: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="salary_type" id="salary_type" type="text" placeholder="Month/year" value="" required />
                        </div>
                        <div class="experience_time col-span-full">
                            <label>Experience time: <span class="text-red">*</span></label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" id="experience" name="experience"  type="text" placeholder="Time period of experience.." value="" />
                        </div>
                        <div class="language col-span-full">
                            <label>Languague: <span class="text-red">*</span></label>
                            <div class="category-selector relative flex flex-wrap items-center justify-between gap-y-2 w-full min-h-12 px-4 py-1 mt-2 border border-line rounded-lg">
                                <input class="languageInput w-full min-h-8" name="languague" id="languague" type="text" placeholder="Type to search language..." />
                                
                            </div>
                        </div>
                        <div class="categories col-span-full">
                            <label>Categories: <span class="text-red">*</span></label>
                            <div class="category-selector relative flex flex-wrap items-center justify-between gap-y-2 w-full min-h-12 px-4 py-1 mt-2 border border-line rounded-lg">
                                <input class="categoryInput w-full min-h-8" type="text" name="categories" id="categories" placeholder="Type to search categories..." />
                                
                            </div>
                        </div>
                        <div class="tools col-span-full">
                            <label>Tools: <span class="text-red">*</span></label>
                            <div class="category-selector relative flex flex-wrap items-center justify-between gap-y-2 w-full min-h-12 px-4 py-1 mt-2 border border-line rounded-lg">
                                <input class="toolsInput w-full min-h-8" type="text" name="tools" id="tools" placeholder="Type to search tools..." />
                                
                            </div>
                        </div>
                        <div class="desc col-span-full">
                            <label>Decscription: <span class="text-red">*</span></label>
                            
                            <textarea class="w-full p-4 mt-2 border-line rounded-lg" name="description" id="description" rows="3" placeholder="Decscription..." required></textarea>
                            
                        </div>
                    </div>
                </div>
                <div class="map_location p-8 mt-7.5 rounded-lg bg-white shadow-sm">
                    <h5 class="heading5">Map Location</h5>
                    <div class="grid sm:grid-cols-2 gap-5 mt-5">
                        <div class="address col-span-full">
                            <label for="address">Address:</label>
                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" id="address"  type="text" placeholder="Address..." value="" />
                        </div>
                        
                        
                    </div>
                </div>
                
                <div class="education p-8 mt-7.5 rounded-lg bg-white shadow-sm">
                    <h5 class="heading5">Education</h5>
                    <ul class="list grid gap-5 mt-5">
                        <li class="item px-5 rounded-lg border border-line">
                            <div class="toggle_item">
                                <div class="heading flex items-center gap-2 py-5">
                                    <button type="button" class="btn_delete ph-fill ph-x-circle text-red text-2xl flex-shrink-0 cursor-pointer"></button>
                                    <div class="flex items-center justify-between w-full cursor-pointer">
                                        <strong class="text-title">Education </strong>
                                        <span class="ph ph-pencil-simple-line text-2xl"></span>
                                    </div>
                                </div>
                                <div class="toggle_menu py-5 border-t border-line hidden">
                                    <div class="form grid grid-cols-2 gap-5">
                                        <div class="specialized">
                                            <label for="specialized">Specialized: <span class="text-red">*</span></label>
                                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="specialized" id="specialized" type="text" placeholder="Specialized..." value="" required />
                                        </div>
                                        <div class="academy">
                                            <label for="academy">Academy: <span class="text-red">*</span></label>
                                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="academy" id="academy" type="text" placeholder="Academy..." value="" required />
                                        </div>
                                        <div class="time_from">
                                            <label for="edu_from_date">From: <span class="text-red">*</span></label>
                                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="edu_from_date" id="edu_from_date" type="date" required />
                                        </div>
                                        <div class="time_to">
                                            <label for="edu_to_date">To: <span class="text-red">*</span></label>
                                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="edu_to_date" id="edu_to_date" type="date" required />
                                        </div>
                                        <div class="desc col-span-full">
                                            <label for="edu_discription">Decscription: <span class="text-red">*</span></label>
                                            <textarea class="w-full p-4 mt-2 border-line rounded-lg" name="edu_discription" id="edu_discription" rows="3" placeholder="Decscription..." required></textarea>
                                        </div>
                                        <div class="flex items-center gap-3 col-span-full">
                                            <span>Graduated:</span>
                                            <button type="button" name="graduated" id="graduated" class="toggle_btn active"></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        
                    </ul>
                    <button type="button" class="button-main -border gap-1 w-full mt-5">
                       
                        <strong class="text-button">Add Education</strong>
                    </button>
                </div>
                <div class="work_experience p-8 mt-7.5 rounded-lg bg-white shadow-sm">
                    <h5 class="heading5">Work Experience</h5>
                    <ul class="list grid gap-5 mt-5">
                        <li class="item px-5 rounded-lg border border-line">
                            <div class="toggle_item">
                                <div class="heading flex items-center gap-2 py-5">
                                    <button type="button" class="btn_delete ph-fill ph-x-circle text-red text-2xl flex-shrink-0 cursor-pointer"></button>
                                    <div class="flex items-center justify-between w-full cursor-pointer">
                                        <strong class="text-title">Experience </strong>
                                        <span class="ph ph-pencil-simple-line text-2xl"></span>
                                    </div>
                                </div>
                                <div class="toggle_menu py-5 border-t border-line hidden">
                                    <div class="form grid grid-cols-2 gap-5">
                                        <div class="job_title">
                                            <label for="job_title">Job title: <span class="text-red">*</span></label>
                                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="job_title" id="job_title" type="text" placeholder="Job title..." value="" required />
                                        </div>
                                        <div class="company">
                                            <label for="company">Company: <span class="text-red">*</span></label>
                                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="company" id="company" type="text" placeholder="Company..." value="" required />
                                        </div>
                                        <div class="time_from">
                                            <label for="exp_from_date">From: <span class="text-red">*</span></label>
                                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="exp_from_date" id="exp_from_date" type="date" required />
                                        </div>
                                        <div class="time_to">
                                            <label for="exp_to_date">To: <span class="text-red">*</span></label>
                                            <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" name="exp_to_date" id="exp_to_date" type="date" required />
                                        </div>
                                        <div class="desc col-span-full">
                                            <label for="exp_description">Decscription: <span class="text-red">*</span></label>
                                            <textarea class="w-full p-4 mt-2 border-line rounded-lg" name="exp_description" id="exp_description" rows="3" placeholder="Decscription..." required></textarea>
                                        </div>
                                        <div class="flex items-center gap-3 col-span-full">
                                            <span>Currently work here:</span>
                                            <button type="button" name="currently_working" id="currently_working" class="toggle_btn"></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                       
                    </ul>
                    <button type="button" class="button-main -border gap-1 w-full mt-5">
                        
                        <strong class="text-button">Add Experience</strong>
                    </button>
                    <br><br>
                    <div class="heading flex flex-wrap items-center justify-between gap-4">
                   
                    <button class="button-main max-sm:hidden" type="submit">Save</button>

                </div>
                    
                    
                </div>
            </form>
            <div class="lg:fixed bottom-0 left-0 z-[1] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
            </div>
        </div>
    </div>

     <!-- Menu mobile -->
     <div class="menu_mobile">
            <button class="menu_mobile_close flex items-center justify-center absolute top-5 left-5 w-8 h-8 rounded-full bg-surface">
                <span class="ph-bold ph-x"></span>
            </button>
            <div class="heading flex items-center justify-center mt-5">
                <a href="../index" class="logo">
                    <img src="../assets/images/logo.png" alt="logo" class="h-8" />
                </a>
            </div>
            <form class="form-search relative mt-4 mx-5">
                <button class="absolute left-3 top-1/2 -translate-y-1/2 cursor-pointer">
                    <i class="ph ph-magnifying-glass text-xl block"></i>
                </button>
                <input type="text" placeholder="What are you looking for?" class="h-12 rounded-lg border border-line text-sm w-full pl-10 pr-4" required />
            </form>
            <div class="mt-4">
                <ul class="nav_mobile">
                    <li class="nav_item py-2">
                        <a href="../index" class="text-xl font-semibold flex items-center justify-between">
                            Home

                        </a>

                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            For Candidates
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li class="nav_item">
                                        <a href="../jobs-grid" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse jobs

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../project-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse Projects

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../employer/employers-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse Employer

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../become-seller" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a seller </a>
                                    </li>
                                    <li class="nav_item">
                                        <a href="candidates-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Candidates Dashboard </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            For Employers
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li class="nav_item">
                                        <a href="../services-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse services

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="candidates-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse candidates

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../become-buyer" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a buyer </a>
                                    </li>
                                    <li class="nav_item">
                                        <a href="../employer/employers-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> employer Dashboard </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            Blogs
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <br>
                                    <li>
                                        <a href="../blog-list" class="inline-block text-xl font-semibold py-2 capitalize"> Blog list </a>
                                    </li>

                                    <li>
                                        <a href="../blog-detail" class="inline-block text-xl font-semibold py-2 capitalize"> Blog detail </a>
                                    </li>
                                    <br><br><br>

                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            Pages
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li>
                                        <a href="../about" class="inline-block text-xl font-semibold py-2 capitalize"> About Us </a>
                                    </li>

                                    <li>
                                        <a href="../pricing" class="inline-block text-xl font-semibold py-2 capitalize"> Pricing Plan </a>
                                    </li>
                                    <li>
                                        <a href="../contact" class="inline-block text-xl font-semibold py-2 capitalize"> Contact Us </a>
                                    </li>

                                    <li>
                                        <a href="../faqs" class="inline-block text-xl font-semibold py-2 capitalize"> Faqs </a>
                                    </li>
                                    <li>
                                        <a href="../term-of-use" class="inline-block text-xl font-semibold py-2 capitalize"> Terms of use </a>
                                    </li>

                                    <li>
                                        <a href="login" class="inline-block text-xl font-semibold py-2 capitalize"> Login </a>
                                    </li>
                                    <li>
                                        <a href="register" class="inline-block text-xl font-semibold py-2 capitalize"> Register </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

    <!-- Menu mobile -->

    <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/apexcharts.js"></script>
    <script src="../assets/js/quill.js"></script>
    <script src="../assets/js/main.js"></script>

    <script>
document.querySelector('form').addEventListener('submit', function (e) {
    if (!this.checkValidity()) {
        e.preventDefault();
        this.reportValidity();
        // No alert here, validation failed
    } else {
        alert('Saved Successfully');
        // let form submit normally
    }
});
</script>


</body>

</html>