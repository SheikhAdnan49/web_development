<?php
session_start();
include('../db-config.php');

// ✅ Check session
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page with redirect back to apply
    header("Location: login.php?redirect=apply");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request.");
}

// File upload handling
$avatarPath = '';
if (!empty($_FILES['avatar']['name'])) {
    $avatarName = time() . '_' . basename($_FILES['avatar']['name']);
    $avatarPath = 'uploads/' . $avatarName;
    if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $avatarPath)) {
        die("Failed to upload avatar.");
    }
}


// Validate and fetch POST data
$full_name = trim($_POST['full_name'] ?? '');
$dob = $_POST['dob'] ?? '';

if (!$full_name) {
    die("Full name is required.");
}

if (!$dob || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
    die("Valid date of birth is required (YYYY-MM-DD).");
}

// For simplicity, set other fields blank if not sent
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';
$gender = $_POST['gender'] ?? '';
$age = $_POST['age'] ?? null;
$salary = $_POST['salary'] ?? null;
$salary_type = $_POST['salary_type'] ?? '';
$experience = $_POST['experience'] ?? '';
$languague = $_POST['languague'] ?? '';
$categories = $_POST['categories'] ?? '';
$tools = $_POST['tools'] ?? '';
$description = $_POST['description'] ?? '';

$specialized = $_POST['specialized'] ?? '';
$academy = $_POST['academy'] ?? '';
$edu_from_date = $_POST['edu_from_date'] ?? null;
$edu_to_date = $_POST['edu_to_date'] ?? null;
$edu_description = $_POST['edu_description'] ?? '';

$job_title = $_POST['job_title'] ?? '';
$company = $_POST['company'] ?? '';
$exp_from_date = $_POST['exp_from_date'] ?? null;
$exp_to_date = $_POST['exp_to_date'] ?? null;
$exp_description = $_POST['exp_description'] ?? '';

// Prepare and execute SQL
$sql = "INSERT INTO candidates (user_id,
    full_name, dob, phone, email, gender, age,
    salary, salary_type, experience,
    languague, categories, tools, description,
    avatar_path, 
    specialized, academy, edu_from_date, edu_to_date, edu_description, 
    job_title, company, exp_from_date, exp_to_date, exp_description
) VALUES (?,
    ?, ?, ?, ?, ?, ?,
    ?, ?, ?,
    ?, ?, ?, ?,
    ?, 
    ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?
)";

$stmt = $pdo->prepare($sql);

try {
    $stmt->execute([$user_id,
        $full_name, $dob, $phone, $email, $gender, $age,
        $salary, $salary_type, $experience,
        $languague, $categories, $tools, $description,
        $avatarPath, 
        $specialized, $academy, $edu_from_date, $edu_to_date, $edu_description,
        $job_title, $company, $exp_from_date, $exp_to_date, $exp_description
    ]);
    echo "Application submitted successfully!";

    // Redirect to another page after 3 seconds (optional delay)
    header("Refresh: 1; URL=candidates-profile");
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
