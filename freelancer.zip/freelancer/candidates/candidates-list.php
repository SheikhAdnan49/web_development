<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>
 
<body>
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="breadcrumb_inner relative sm:mt-20 mt-16 lg:py-20 py-14">
            <div class="breadcrumb_bg absolute top-0 left-0 w-full h-full">
                <img src="../assets/images/components/breadcrumb_candidate.webp" alt="breadcrumb_candidate" class="w-full h-full object-cover" />
            </div>
            <div class="container relative h-full">
                <div class="breadcrumb_content flex flex-col items-start justify-center lg:w-[720px] md:w-5/6 w-full h-full">
                    <div class="list_breadcrumb flex items-center gap-2 animate animate_top" style="--i: 1">
                        <a href="../index" class="caption1 text-white">Home</a>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white">For Employers</span>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white opacity-60">Candidates</span>
                    </div>
                    <h3 class="heading3 text-white mt-2 animate animate_top" style="--i: 2">Candidates List</h3>
                    <div class="form_search z-[1] w-full mt-5 animate animate_top" style="--i: 3">
                        <form class="form_inner flex items-center justify-between max-sm:flex-wrap gap-6 gap-y-4 relative w-full p-3 rounded-lg bg-white">
                            <div class="form_input relative w-full">
                                <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-2 text-xl"></span>
                                <input type="text" class="input_search w-full h-full pl-10" placeholder="Job title, key words or company" required />
                            </div>
                            <div class="select_block flex-shrink-0 max-sm:w-full sm:pr-16 pr-7 sm:pl-6 pl-3 sm:border-l border-line">
                                <div class="select">
                                    <span class="selected" data-title="All Categories">All Categories</span>
                                    <ul class="list_option bg-white max-sm:w-full">
                                        <li data-item="Graphic & Design">Graphic & Design</li>
                                        <li data-item="Wrting">Wrting</li>
                                        <li data-item="Videos">Videos</li>
                                        <li data-item="Digital Marketing">Digital Marketing</li>
                                    </ul>
                                </div>
                                <span class="icon_down ph ph-caret-down sm:text-2xl text-xl sm:right-0 right-3"></span>
                            </div>
                            <button type="submit" class="button-main max-sm:w-1/3 text-center flex-shrink-0">Search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- List candidates -->
    <div class="candidates lg:py-20 sm:py-14 py-10">
        <div class="container flex flex-col items-center">
            <div class="filter flex flex-wrap items-center justify-between gap-8 gap-y-3 relative w-full">
                <button id="filter_btn" class="filter_btn inline-flex items-center gap-1.5 py-1.5 px-2.5 border border-line rounded-md duration-300 hover:bg-primary hover:text-white">
                    <span class="ph ph-sliders-horizontal text-xl"></span>
                    <span>Filters</span>
                </button>
                <ul class="list_layout flex items-center gap-2 sm:absolute sm:left-1/2 sm:-translate-x-1/2">
                    <li class="ml-1.5 max-xl:hidden">
                        <button class="layout_btn cols_3"></button>
                    </li>
                    <li class="max-xl:hidden">
                        <button class="layout_btn cols_2 active"></button>
                    </li>
                    <li class="xl:hidden">
                        <a href="candidates-default" class="layout_link cols_2"></a>
                    </li>
                    <li class="xl:hidden">
                        <a href="#!" class="layout_link list active"></a>
                    </li>
                </ul>
                <div class="select_filter flex items-center gap-3">
                    <span class="caption1">Sort by:</span>
                    <div class="select_block sm:pr-16 pr-10 pl-3 py-1 border border-line rounded">
                        <div class="select">
                            <span class="selected caption1 capitalize" data-title="sort default">default</span>
                            <ul class="list_option p-0 bg-white">
                                <li class="capitalize" data-item="default">sort by (default)</li>
                                <li class="capitalize" data-item="newest">newest</li>
                                <li class="capitalize" data-item="oldest">oldest</li>
                                <li class="capitalize" data-item="random">random</li>
                            </ul>
                        </div>
                        <span class="icon_down ph ph-caret-down right-3"></span>
                    </div>
                </div>
            </div>
            <div class="list_filtered flex flex-wrap items-center gap-3 w-full mt-5">
                <span class="quantity pr-3 border-r border-line">1,200+ Results</span>
                <div class="list flex flex-wrap items-center gap-3"></div>
                <button class="clear_all_btn inline-flex items-center gap-1 py-1 px-2 border border-red text-red rounded-full duration-300 hover:bg-red hover:text-white">
                    <span class="ph ph-x text-sm"></span>
                    <span class="caption1">Clear All</span>
                </button>
            </div>
            <ul class="list_layout_cols list_candidates grid md:grid-cols-2 lg:gap-7.5 gap-5 w-full md:mt-10 mt-7">
                <li class="candidates_item is_top_rate px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-13.webp" alt="IMG-13" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Devon Lane</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Las Vegas, USA</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$22</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-12.webp" alt="IMG-12" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Guy Hawkins</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Cape Town, South Africa</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$23</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item is_top_rate px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-11.webp" alt="IMG-11" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Kristin Watson</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Rio de Janeiro, Brazil</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$32</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-10.webp" alt="IMG-10" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Robert Fox</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Sydney, Australia</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$18</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item is_top_rate px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-9.webp" alt="IMG-9" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Dianne Russell</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Tokyo, Japan</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$22</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-8.webp" alt="IMG-8" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Theresa Webb</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Paris, France</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$23</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-7.webp" alt="IMG-7" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Marvin McKinney</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Cape Town, South Africa</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$32</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-6.webp" alt="IMG-6" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Arlene McCoy</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Las Vegas, USA</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$18</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item is_top_rate px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-5.webp" alt="IMG-5" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Courtney Henry</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Rio de Janeiro, Brazil</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$22</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
                <li class="candidates_item is_top_rate px-6 py-5 rounded-lg bg-white shadow-md duration-300 hover:shadow-xl">
                    <div class="candidates_info flex gap-4 relative w-full pb-4 border-b border-line">
                        <a href="candidates-detail" class="overflow-hidden flex-shrink-0 w-15 h-15 rounded-full">
                            <img src="../assets/images/avatar/IMG-4.webp" alt="IMG-4" class="candidates_avatar w-full h-full object-cover" />
                        </a>
                        <div class="candidates_content w-full">
                            <a href="candidates-detail" class="candidates_detail flex flex-col gap-1 mr-14 duration-300 hover:text-primary">
                                <strong class="candidates_name -style-1 w-fit text-title">Kristin Watson</strong>
                                <span class="flex items-center text-secondary">
                                    <span class="ph ph-map-pin text-lg"></span>
                                    <span class="candidates_address -style-1 caption1 pl-1">Cape Town, South Africa</span>
                                </span>
                            </a>
                            <div class="flex flex-wrap items-center justify-between gap-4 mt-1">
                                <div class="flex flex-wrap items-center gap-3">
                                    <strong class="candidates_status tag caption2 bg-background text-primary">Available now</strong>
                                    <div class="flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-sm"></span>
                                        <strong class="candidates_rate text-sm font-semibold">4.9</strong>
                                        <span class="candidates_rate_quantity caption1 text-secondary">(482 review)</span>
                                    </div>
                                </div>
                                <a href="candidates-detail" class="button-main -border">View Profile</a>
                            </div>
                        </div>
                        <button class="add_wishlist_btn absolute top-0 right-0 -border">
                            <span class="ph ph-heart text-xl"></span>
                            <span class="ph-fill ph-heart text-xl"></span>
                        </button>
                    </div>
                    <div class="candidates_more_info flex flex-wrap items-center justify-between gap-3 pt-4">
                        <div class="flex flex-wrap items-center gap-2.5">
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Full-Time</a>
                            <a href="candidates-default" class="candidates_tag caption1 tag bg-surface duration-300 hover:bg-primary hover:text-white">Web Design</a>
                        </div>
                        <div class="candidates_price">
                            <span class="price text-title">$23</span>
                            <span class="text-secondary">/Hours</span>
                        </div>
                    </div>
                </li>
            </ul>
            <ul class="list_pagination menu_tab flex items-center justify-center gap-2 w-full md:mt-10 mt-7" role="tablist">
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black active" role="tab" aria-selected="true">1</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">2</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">3</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">></a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    

    

    <!-- Menu mobile -->

    <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>



</html>