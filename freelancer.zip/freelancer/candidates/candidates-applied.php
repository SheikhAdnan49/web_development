<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/apexcharts.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body class="lg:overflow-hidden">

    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">
        
        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

        <div class="dashboard_applied scrollbar_custom w-full bg-surface">
            <div class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8">
                <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 lg:hidden" data-type="menu_dashboard">
                    <span class="ph ph-squares-four text-xl"></span>
                    <strong class="text-button">Menu</strong>
                </button>
                <h4 class="heading4 max-lg:mt-3">My Applied</h4>
                <div class="applied_block mt-7.5 rounded-lg bg-white">
                    <div class="flex flex-wrap items-center justify-between gap-5 pt-6 px-6">
                        <form class="relative w-[340px] h-12">
                            <input type="text" class="w-full h-full pl-4 pr-12 border border-line rounded-lg overflow-hidden" placeholder="Search by keyword" required />
                            <button type="submit" class="absolute top-1/2 -translate-y-1/2 right-4">
                                <span class="ph ph-magnifying-glass text-xl block"></span>
                            </button>
                        </form>
                        <div class="select_block sm:pr-16 pr-10 pl-3 py-2 border border-line rounded">
                            <div class="select">
                                <span class="selected caption1 capitalize" data-title="sort by (default)">sort by (default)</span>
                                <ul class="list_option scrollbar_custom max-h-[200px] p-0 bg-white">
                                    <li class="capitalize" data-item="default">sort by (default)</li>
                                    <li class="capitalize" data-item="title (a -> z)">title (a -> z)</li>
                                    <li class="capitalize" data-item="title (z -> a)">title (z -> a)</li>
                                    <li class="capitalize" data-item="date (newest)">date (newest)</li>
                                    <li class="capitalize" data-item="date (oldest)">date (oldest)</li>
                                    <li class="capitalize" data-item="cost (high to low)">cost (high to low)</li>
                                    <li class="capitalize" data-item="cost (low to high)">cost (low to high)</li>
                                    <li class="capitalize" data-item="status (submitted)">status (submitted)</li>
                                    <li class="capitalize" data-item="status (active)">status (active)</li>
                                    <li class="capitalize" data-item="status (expired)">status (expired)</li>
                                    <li class="capitalize" data-item="status (completed)">status (completed)</li>
                                </ul>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="list overflow-x-auto w-full py-5 px-6 rounded-xl">
                        <table class="w-full max-[1400px]:w-[1200px] max-md:w-[1000px]">
                            <thead class="border-b border-line">
                                <tr>
                                    <th scope="col" class="px-5 py-4 text-left text-sm font-bold uppercase text-secondary whitespace-nowrap">Title</th>
                                    <th scope="col" class="px-5 py-4 text-left text-sm font-bold uppercase text-secondary whitespace-nowrap">Date Applied</th>
                                    <th scope="col" class="px-5 py-4 text-left text-sm font-bold uppercase text-secondary whitespace-nowrap">Cost/time</th>
                                    <th scope="col" class="px-5 py-4 text-left text-sm font-bold uppercase text-secondary whitespace-nowrap">Status</th>
                                    <th scope="col" class="px-5 py-4 text-right text-sm font-bold uppercase text-secondary whitespace-nowrap">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info">
                                            <a href="../jobs-detail" class=" title heading6 duration-300 hover:underline">Full Stack Developer</a>
                                            <div class="flex flex-wrap items-center gap-4 mt-2">
                                                <a href="../employer/employers-detail" class=" employers flex items-center gap-2 text-secondary duration-300 hover:text-primary">
                                                    <img src="../assets/images/company/1.png" alt="company/1" class="flex-shrink-0 w-5 h-5" />
                                                    <span class="employers_name font-normal">PrimeEdge Solutions</span>
                                                </a>
                                                <div class="line flex-shrink-0 w-px h-4 bg-line"></div>
                                                <div class="address flex items-center gap-2 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Las Vegas, USA</span>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 29, 2024</td>
                                    <td class="p-5">
                                        <div class="candidates_price whitespace-nowrap">
                                            <span class="price text-title">$15-$20</span>
                                            <span class="text-secondary">/hour</span>
                                        </div>
                                    </td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-features text-features text-button">Submitted</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_view_job flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_view_job">
                                                <span class="ph ph-eye text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">View Job</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info">
                                            <a href="../jobs-detail" class=" title heading6 duration-300 hover:underline">Senior DevOps Engineer</a>
                                            <div class="flex flex-wrap items-center gap-4 mt-2">
                                                <a href="../employer/employers-detail" class=" employers flex items-center gap-2 text-secondary duration-300 hover:text-primary">
                                                    <img src="../assets/images/company/2.png" alt="company/2" class="flex-shrink-0 w-5 h-5" />
                                                    <span class="employers_name font-normal">Bright Future</span>
                                                </a>
                                                <div class="line flex-shrink-0 w-px h-4 bg-line"></div>
                                                <div class="address flex items-center gap-2 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Las Vegas, USA</span>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 24, 2024</td>
                                    <td class="p-5">
                                        <div class="candidates_price whitespace-nowrap">
                                            <span class="price text-title">$60-$80</span>
                                            <span class="text-secondary">/day</span>
                                        </div>
                                    </td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-primary text-primary text-button">Active</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_view_job flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_view_job">
                                                <span class="ph ph-eye text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">View job</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info">
                                            <a href="../project-detail" class=" title heading6 duration-300 hover:underline">Need a UX designer to design a website on figma</a>
                                            <div class="flex flex-wrap items-center gap-4 mt-2">
                                                <a href="../employer/employers-detail" class=" employers flex items-center gap-2 text-secondary duration-300 hover:text-primary">
                                                    <img src="../assets/images/company/3.png" alt="company/3" class="flex-shrink-0 w-5 h-5" />
                                                    <span class="employers_name font-normal">GlobalTech Partners</span>
                                                </a>
                                                <div class="line flex-shrink-0 w-px h-4 bg-line"></div>
                                                <div class="address flex items-center gap-2 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Las Vegas, USA</span>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 19, 2024</td>
                                    <td class="p-5">
                                        <div class="candidates_price whitespace-nowrap">
                                            <span class="price text-title">$850-$1000</span>
                                            <span class="text-secondary">/month</span>
                                        </div>
                                    </td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-red text-red text-button">Expired</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_view_project flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_view_project">
                                                <span class="ph ph-eye text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">View project</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info">
                                            <a href="../jobs-detail" class=" title heading6 duration-300 hover:underline">Social Media Marketing</a>
                                            <div class="flex flex-wrap items-center gap-4 mt-2">
                                                <a href="../employer/employers-detail" class=" employers flex items-center gap-2 text-secondary duration-300 hover:text-primary">
                                                    <img src="../assets/images/company/4.png" alt="company/4" class="flex-shrink-0 w-5 h-5" />
                                                    <span class="employers_name font-normal">Apex Innovations</span>
                                                </a>
                                                <div class="line flex-shrink-0 w-px h-4 bg-line"></div>
                                                <div class="address flex items-center gap-2 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Las Vegas, USA</span>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 16, 2024</td>
                                    <td class="p-5">
                                        <div class="candidates_price whitespace-nowrap">
                                            <span class="price text-title">$20-$25</span>
                                            <span class="text-secondary">/hour</span>
                                        </div>
                                    </td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-red text-red text-button">Expired</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_view_job flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_view_job">
                                                <span class="ph ph-eye text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">View job</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info">
                                            <a href="../project-detail" class=" title heading6 duration-300 hover:underline">Need a user interface designer to create an intuitive language and layout</a>
                                            <div class="flex flex-wrap items-center gap-4 mt-2">
                                                <a href="../employer/employers-detail" class=" employers flex items-center gap-2 text-secondary duration-300 hover:text-primary">
                                                    <img src="../assets/images/company/5.png" alt="company/5" class="flex-shrink-0 w-5 h-5" />
                                                    <span class="employers_name font-normal">GlobalTech Partners</span>
                                                </a>
                                                <div class="line flex-shrink-0 w-px h-4 bg-line"></div>
                                                <div class="address flex items-center gap-2 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Las Vegas, USA</span>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 12, 2024</td>
                                    <td class="p-5">
                                        <div class="candidates_price whitespace-nowrap">
                                            <span class="price text-title">$200-$250</span>
                                            <span class="text-secondary">/week</span>
                                        </div>
                                    </td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-success text-success text-button">completed</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_view_project flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_view_project">
                                                <span class="ph ph-eye text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">View project</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="item duration-300 hover:bg-background">
                                    <th scope="row" class="p-5 text-left">
                                        <div class="info">
                                            <a href="../project-detail" class=" title heading6 duration-300 hover:underline">Figma and photoshop expert needed for fulltime/part time long term contract</a>
                                            <div class="flex flex-wrap items-center gap-4 mt-2">
                                                <a href="../employer/employers-detail" class=" employers flex items-center gap-2 text-secondary duration-300 hover:text-primary">
                                                    <img src="../assets/images/company/6.png" alt="company/6" class="flex-shrink-0 w-5 h-5" />
                                                    <span class="employers_name font-normal">Apex Innovations</span>
                                                </a>
                                                <div class="line flex-shrink-0 w-px h-4 bg-line"></div>
                                                <div class="address flex items-center gap-2 text-secondary">
                                                    <span class="ph ph-map-pin text-xl"></span>
                                                    <span class="employers_address font-normal">Las Vegas, USA</span>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="p-5 whitespace-nowrap">Mar 02, 2024</td>
                                    <td class="p-5">
                                        <div class="candidates_price whitespace-nowrap">
                                            <span class="price text-title">$850-$900</span>
                                            <span class="text-secondary">/month</span>
                                        </div>
                                    </td>
                                    <td class="p-5">
                                        <span class="tag bg-opacity-10 bg-success text-success text-button">completed</span>
                                    </td>
                                    <td class="p-5">
                                        <div class="flex justify-end gap-2">
                                            <button class="btn_action btn_open_popup btn_view_project flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_view_project">
                                                <span class="ph ph-eye text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">View project</span>
                                            </button>
                                            <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                                <span class="ph ph-trash text-xl"></span>
                                                <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete</span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="flex flex-wrap items-center justify-between gap-4 p-6 border-t border-line">
                        <ul class="list_pagination menu_tab flex items-center justify-center gap-2 w-full md:mt-10 mt-7" role="tablist">
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black active" role="tab" aria-selected="true">1</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">2</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">3</a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">></a>
                            </li>
                        </ul>
                        <p class="text-secondary whitespace-nowrap">Showing <span class="start">1</span> to <span class="end">4</span> of <span class="total">16</span> entries</p>
                    </div>
                </div>
            </div>
            <div class="lg:fixed bottom-0 left-0 z-[1] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
            </div>
        </div>
    </div>

   <!-- Menu mobile -->

   <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/apexcharts.js"></script>
    <script src="../assets/js/main.js"></script>
</body>


</html>