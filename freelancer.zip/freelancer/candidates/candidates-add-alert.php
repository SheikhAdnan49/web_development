<!DOCTYPE html>
<html lang="en">



<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/apexcharts.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body class="lg:overflow-hidden">


    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->



    <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">

        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

        <div class="dashboard_alert scrollbar_custom w-full bg-surface">
            <form class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8" method="post" action="">
                <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 lg:hidden" data-type="menu_dashboard">
                    <span class="ph ph-squares-four text-xl"></span>
                    <strong class="text-button">Menu</strong>
                </button>
                <div class="flex flex-wrap items-center justify-between gap-4">
                    <h4 class="heading4 max-lg:mt-3">Jobs Alerts</h4>
                    <button type="submit" class="button-main">Create New Alerts</button>
                </div>
                <div class="alert_block grid sm:grid-cols-2 gap-5 sm:p-10 p-7 mt-7.5 rounded-lg bg-white">
                    <div class="name">
                        <label for="name">Alert Name <span class="text-red">*</span></label>
                        <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" id="name" type="text" placeholder="Alert Name..." required />
                    </div>
                    <div class="keyword">
                        <label for="keyword">Keyword</label>
                        <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" id="keyword" type="text" placeholder="Keyword..." />
                    </div>
                    <div class="region">
                        <label for="region">Job Region <span class="text-red">*</span></label>
                        <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" id="region" type="text" placeholder="Job Region..." required />
                    </div>
                    <div class="categories">
                        <label for="categories">Categories <span class="text-red">*</span></label>
                        <input class="w-full h-12 px-4 mt-2 border-line rounded-lg" id="categories" type="text" placeholder="Categories..." required />
                    </div>
                    <div class="tags">
                        <label>Tags <span class="text-red">*</span></label>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-4 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="landing">landing</span>
                                <ul class="list_option scrollbar_custom w-full max-h-[200px] bg-white">
                                    <li class="capitalize" data-item="landing">landing</li>
                                    <li class="capitalize" data-item="web">web</li>
                                    <li class="capitalize" data-item="app">app</li>
                                    <li class="capitalize" data-item="mobile">mobile</li>
                                    <li class="capitalize" data-item="logo">logo</li>
                                    <li class="capitalize" data-item="mockup">mockup</li>
                                </ul>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="type">
                        <label>Job Type <span class="text-red">*</span></label>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-4 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Fulltime">Fulltime</span>
                                <ul class="list_option scrollbar_custom w-full max-h-[200px] bg-white">
                                    <li class="capitalize" data-item="Fulltime">Fulltime</li>
                                    <li class="capitalize" data-item="Parttime">Parttime</li>
                                    <li class="capitalize" data-item="Remote">Remote</li>
                                    <li class="capitalize" data-item="Onsite">Onsite</li>
                                </ul>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="type">
                        <label>Email Frequency <span class="text-red">*</span></label>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-4 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="weekly">weekly</span>
                                <ul class="list_option -top scrollbar_custom w-full max-h-[200px] bg-white">
                                    <li class="capitalize" data-item="daily">daily</li>
                                    <li class="capitalize" data-item="weekly">weekly</li>
                                    <li class="capitalize" data-item="monthly">monthly</li>
                                </ul>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                </div>
            </form>
            <div class="lg:fixed bottom-0 left-0 z-[1] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
            </div>
        </div>
    </div>

    <!-- Menu mobile -->

    <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->


    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/apexcharts.js"></script>
    <script src="../assets/js/main.js"></script>
</body>

</html>