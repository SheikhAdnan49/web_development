<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/apexcharts.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body class="lg:overflow-hidden">

     <!-- Header -->
        <?php include('header.php'); ?>
        <!-- end -->

        <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">
            
        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

            <div class="dashboard_meeting scrollbar_custom w-full bg-surface">
                <div class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8">
                    <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 lg:hidden" data-type="menu_dashboard">
                        <span class="ph ph-squares-four text-xl"></span>
                        <strong class="text-button">Menu</strong>
                    </button>
                    <h4 class="heading4 max-lg:mt-3">Video Mettings</h4>
                    <div class="meeting_block p-6 mt-7.5 rounded-lg bg-white">
                        <ul class="list_meeting">
                            <li class="item flex flex-wrap items-center justify-between gap-4 p-5 border-b border-line rounded-lg duration-300 hover:bg-background">
                                <div class="left flex items-center gap-10">
                                    <div class="calendar_block overflow-hidden w-[76px] rounded">
                                        <div class="top py-1 bg-black text-sm font-bold uppercase text-white text-center">wed</div>
                                        <div class="days heading4 py-1 bg-surface text-center">26</div>
                                    </div>
                                    <div class="info">
                                        <strong class="title -style-1 heading6 hover:underline">UX/UI Designer</strong>
                                        <p class="caption1 text-secondary mt-1">Meeting with: <span class="name capitalize text-black">Dean</span></p>
                                        <div class="flex items-center gap-4 mt-2">
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-clock text-secondary"></span>
                                                <span class="hour caption1">10h:00 AM</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-hourglass text-secondary"></span>
                                                <span class="time caption1">30m</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="action flex justify-end gap-2">
                                    <button class="btn_action btn_open_popup btn_chat flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_chat">
                                        <span class="ph ph-chats text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Send Message</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_meeting">
                                        <span class="ph ph-calendar-blank text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Re-schedule Meeting</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                        <span class="ph ph-x text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete Metting</span>
                                    </button>
                                </div>
                            </li>
                            <li class="item flex flex-wrap items-center justify-between gap-4 p-5 border-b border-line rounded-lg duration-300 hover:bg-background">
                                <div class="left flex items-center gap-10">
                                    <div class="calendar_block overflow-hidden w-[76px] rounded">
                                        <div class="top py-1 bg-black text-sm font-bold uppercase text-white text-center">mon</div>
                                        <div class="days heading4 py-1 bg-surface text-center">17</div>
                                    </div>
                                    <div class="info">
                                        <strong class="title -style-1 heading6 hover:underline">Web Designer</strong>
                                        <p class="caption1 text-secondary mt-1">Meeting with: <span class="name capitalize text-black">Alexander</span></p>
                                        <div class="flex items-center gap-4 mt-2">
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-clock text-secondary"></span>
                                                <span class="hour caption1">10h:00 AM</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-hourglass text-secondary"></span>
                                                <span class="time caption1">30m</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="action flex justify-end gap-2">
                                    <button class="btn_action btn_open_popup btn_chat flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_chat">
                                        <span class="ph ph-chats text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Send Message</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_meeting">
                                        <span class="ph ph-calendar-blank text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Re-schedule Meeting</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                        <span class="ph ph-x text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete Metting</span>
                                    </button>
                                </div>
                            </li>
                            <li class="item flex flex-wrap items-center justify-between gap-4 p-5 border-b border-line rounded-lg duration-300 hover:bg-background">
                                <div class="left flex items-center gap-10">
                                    <div class="calendar_block overflow-hidden w-[76px] rounded">
                                        <div class="top py-1 bg-black text-sm font-bold uppercase text-white text-center">fri</div>
                                        <div class="days heading4 py-1 bg-surface text-center">14</div>
                                    </div>
                                    <div class="info">
                                        <strong class="title -style-1 heading6 hover:underline">Digital Marketing</strong>
                                        <p class="caption1 text-secondary mt-1">Meeting with: <span class="name capitalize text-black">Peter</span></p>
                                        <div class="flex items-center gap-4 mt-2">
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-clock text-secondary"></span>
                                                <span class="hour caption1">10h:00 AM</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-hourglass text-secondary"></span>
                                                <span class="time caption1">30m</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="action flex justify-end gap-2">
                                    <button class="btn_action btn_open_popup btn_chat flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_chat">
                                        <span class="ph ph-chats text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Send Message</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_meeting">
                                        <span class="ph ph-calendar-blank text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Re-schedule Meeting</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                        <span class="ph ph-x text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete Metting</span>
                                    </button>
                                </div>
                            </li>
                            <li class="item flex flex-wrap items-center justify-between gap-4 p-5 border-b border-line rounded-lg duration-300 hover:bg-background">
                                <div class="left flex items-center gap-10">
                                    <div class="calendar_block overflow-hidden w-[76px] rounded">
                                        <div class="top py-1 bg-black text-sm font-bold uppercase text-white text-center">thu</div>
                                        <div class="days heading4 py-1 bg-surface text-center">13</div>
                                    </div>
                                    <div class="info">
                                        <strong class="title -style-1 heading6 hover:underline">App Developement</strong>
                                        <p class="caption1 text-secondary mt-1">Meeting with: <span class="name capitalize text-black">William</span></p>
                                        <div class="flex items-center gap-4 mt-2">
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-clock text-secondary"></span>
                                                <span class="hour caption1">10h:00 AM</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-hourglass text-secondary"></span>
                                                <span class="time caption1">30m</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="action flex justify-end gap-2">
                                    <button class="btn_action btn_open_popup btn_chat flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_chat">
                                        <span class="ph ph-chats text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Send Message</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_meeting">
                                        <span class="ph ph-calendar-blank text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Re-schedule Meeting</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                        <span class="ph ph-x text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete Metting</span>
                                    </button>
                                </div>
                            </li>
                            <li class="item flex flex-wrap items-center justify-between gap-4 p-5 border-b border-line rounded-lg duration-300 hover:bg-background">
                                <div class="left flex items-center gap-10">
                                    <div class="calendar_block overflow-hidden w-[76px] rounded">
                                        <div class="top py-1 bg-black text-sm font-bold uppercase text-white text-center">sat</div>
                                        <div class="days heading4 py-1 bg-surface text-center">8</div>
                                    </div>
                                    <div class="info">
                                        <strong class="title -style-1 heading6 hover:underline">SEO Marketing</strong>
                                        <p class="caption1 text-secondary mt-1">Meeting with: <span class="name capitalize text-black">Jackson</span></p>
                                        <div class="flex items-center gap-4 mt-2">
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-clock text-secondary"></span>
                                                <span class="hour caption1">10h:00 AM</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-hourglass text-secondary"></span>
                                                <span class="time caption1">30m</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="action flex justify-end gap-2">
                                    <button class="btn_action btn_open_popup btn_chat flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_chat">
                                        <span class="ph ph-chats text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Send Message</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_meeting flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_meeting">
                                        <span class="ph ph-calendar-blank text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Re-schedule Meeting</span>
                                    </button>
                                    <button class="btn_action btn_open_popup btn_delete flex items-center justify-center relative w-10 h-10 rounded border border-line duration-300 hover:bg-primary hover:text-white" data-type="modal_delete">
                                        <span class="ph ph-x text-xl"></span>
                                        <span class="flag absolute -top-10 left-1/2 py-0.5 px-1.5 rounded border border-line bg-white caption1 capitalize text-black whitespace-nowrap">Delete Metting</span>
                                    </button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="lg:fixed bottom-0 left-0 z-[1] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                    <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
                </div>
            </div>
        </div>

        <!-- Menu mobile -->
        <div class="menu_mobile">
            <button class="menu_mobile_close flex items-center justify-center absolute top-5 left-5 w-8 h-8 rounded-full bg-surface">
                <span class="ph-bold ph-x"></span>
            </button>
            <div class="heading flex items-center justify-center mt-5">
                <a href="../index" class="logo">
                    <img src="../assets/images/logo.png" alt="logo" class="h-8" />
                </a>
            </div>
            <form class="form-search relative mt-4 mx-5">
                <button class="absolute left-3 top-1/2 -translate-y-1/2 cursor-pointer">
                    <i class="ph ph-magnifying-glass text-xl block"></i>
                </button>
                <input type="text" placeholder="What are you looking for?" class="h-12 rounded-lg border border-line text-sm w-full pl-10 pr-4" required />
            </form>
            <div class="mt-4">
                <ul class="nav_mobile">
                    <li class="nav_item py-2">
                        <a href="../index" class="text-xl font-semibold flex items-center justify-between">
                            Home

                        </a>

                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            For Candidates
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li class="nav_item">
                                        <a href="../jobs-grid" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse jobs

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../project-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse Projects

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../employer/employers-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse Employer

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../become-seller" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a seller </a>
                                    </li>
                                    <li class="nav_item">
                                        <a href="candidates-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Candidates Dashboard </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            For Employers
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li class="nav_item">
                                        <a href="../services-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse services

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="candidates-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                            Browse candidates

                                        </a>

                                    </li>
                                    <li class="nav_item">
                                        <a href="../become-buyer" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a buyer </a>
                                    </li>
                                    <li class="nav_item">
                                        <a href="../employer/employers-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> employer Dashboard </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            Blogs
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <br>
                                    <li>
                                        <a href="../blog-list" class="inline-block text-xl font-semibold py-2 capitalize"> Blog list </a>
                                    </li>

                                    <li>
                                        <a href="../blog-detail" class="inline-block text-xl font-semibold py-2 capitalize"> Blog detail </a>
                                    </li>
                                    <br><br><br>

                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav_item py-2">
                        <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                            Pages
                            <span class="text-right">
                                <i class="ph ph-caret-right text-xl"></i>
                            </span>
                        </a>
                        <div class="sub_nav_mobile">
                            <button class="back_btn flex items-center gap-3">
                                <i class="ph ph-caret-left text-xl"></i>
                                Back
                            </button>
                            <div class="list-nav-item w-full pt-2 pb-6">
                                <ul>
                                    <li>
                                        <a href="../about" class="inline-block text-xl font-semibold py-2 capitalize"> About Us </a>
                                    </li>

                                    <li>
                                        <a href="../pricing" class="inline-block text-xl font-semibold py-2 capitalize"> Pricing Plan </a>
                                    </li>
                                    <li>
                                        <a href="../contact" class="inline-block text-xl font-semibold py-2 capitalize"> Contact Us </a>
                                    </li>

                                    <li>
                                        <a href="../faqs" class="inline-block text-xl font-semibold py-2 capitalize"> Faqs </a>
                                    </li>
                                    <li>
                                        <a href="../term-of-use" class="inline-block text-xl font-semibold py-2 capitalize"> Terms of use </a>
                                    </li>

                                    <li>
                                        <a href="login" class="inline-block text-xl font-semibold py-2 capitalize"> Login </a>
                                    </li>
                                    <li>
                                        <a href="register" class="inline-block text-xl font-semibold py-2 capitalize"> Register </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

       <!-- Menu mobile -->

    <?php include('mobile-menu.php'); ?>
    
    <!-- </> -->

        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/phosphor-icons.js"></script>
        <script src="../assets/js/slick.min.js"></script>
        <script src="../assets/js/leaflet.js"></script>
        <script src="../assets/js/swiper-bundle.min.js"></script>
        <script src="../assets/js/apexcharts.js"></script>
        <script src="../assets/js/main.js"></script>
</body>

</html>