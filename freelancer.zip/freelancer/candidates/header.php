<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$is_candidate_logged_in = isset($_SESSION['candidate_logged_in']) && $_SESSION['candidate_logged_in'] === true;
?>
<header id="header" class="header -style-white relative">
        <div
            class="header_inner absolute flex items-center justify-between top-0 left-0 right-0 z-[1] w-full sm:h-20 h-16 min-[1600px]:px-15 lg:px-9 px-4 border-b border-light">
            <div class="left flex items-center gap-15 h-full max-[1600px]:gap-6">
                <h1>
                    <a href="../index">
                        <img src="../assets/images/logo-white.png" alt="logo-white"
                            class="logo-white md:h-[42px] h-8 w-auto" />
                        <img src="../assets/images/logo.png" alt="logo" class="logo-black md:h-[42px] h-8 w-auto hidden" />
                    </a>
                </h1>

            </div>
            <div class="navigator h-full max-[1400px]:hidden">
                <ul class="list flex items-center gap-5 h-full">
                    <li class="h-full relative">
                        <a href="../index" class="flex items-center gap-1 h-full text-white duration-300 ">
                            <span class="text-title relative">Home</span>

                        </a>

                    </li>
                    <li class="h-full relative">
                        <a href="#" class="flex items-center gap-1 h-full text-white duration-300">
                            <span class="text-title relative">For Candidates</span>
                            <span class="ph-bold ph-caret-down"></span>
                        </a>
                        <div class="sub_menu absolute p-3 -left-10 w-max bg-white rounded-lg">
                            <ul>
                                <li>
                                    <a href="../jobs-grid"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Browse jobs

                                    </a>

                                </li>
                                <li>
                                    <a href="../project-list"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Browse Projects

                                    </a>

                                </li>
                                <li>
                                    <a href="../employers-list"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Browse Employer

                                    </a>

                                </li>
                                <li>
                                    <a href="../become-seller"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Become a seller </a>
                                </li>
                              
                            </ul>
                        </div>
                    </li>
                    <li class="h-full relative">
                        <a href="#!" class="flex items-center gap-1 h-full text-white duration-300">
                            <span class="text-title relative">For Employers</span>
                            <span class="ph-bold ph-caret-down"></span>
                        </a>
                        <div class="sub_menu absolute p-3 -left-10 w-max bg-white rounded-lg">
                            <ul>
                                <li>
                                    <a href="../services-list"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Browse Services

                                    </a>

                                </li>
                                <li>
                                    <a href="../candidates-list"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Browse Candidates

                                    </a>

                                </li>
                                <li>
                                    <a href="../become-buyer"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Become a buyer </a>
                                </li>
                               
                            </ul>
                        </div>
                    </li>
                    <li class="h-full relative">
                        <a href="#!" class="flex items-center gap-1 h-full text-white duration-300">
                            <span class="text-title relative">Blogs</span>
                            <span class="ph-bold ph-caret-down"></span>
                        </a>
                        <div class="sub_menu absolute p-3 -left-10 w-max bg-white rounded-lg">
                            <ul>

                                <li>
                                    <a href="../blog-list"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Blog list </a>
                                </li>
                                <li>
                                    <a href="../blog-detail"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Blog details </a>
                                </li>

                            </ul>
                        </div>
                    </li>
                    <li class="h-full relative">
                        <a href="#!" class="flex items-center gap-1 h-full text-white duration-300">
                            <span class="text-title relative">Pages</span>
                            <span class="ph-bold ph-caret-down"></span>
                        </a>
                        <div class="sub_menu absolute p-3 -left-10 w-max bg-white rounded-lg">
                            <ul>
                                <li>
                                    <a href="../about"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        About Us </a>
                                </li>

                                <li>
                                    <a href="../pricing"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Pricing Plan </a>
                                </li>
                                <li>
                                    <a href="../contact"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Contact Us </a>
                                </li>

                                <li>
                                    <a href="../faqs"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Faqs </a>
                                </li>
                                <li>
                                    <a href="../term-of-use"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Terms of use </a>
                                </li>

                                <li>
                                    <a href="login"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Login </a>
                                </li>
                                <li>
                                    <a href="register"
                                        class="link flex items-center justify-between gap-2 w-full text-button py-[11px] px-6 rounded duration-300">
                                        Register </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="list_action flex items-center gap-5">
                <div class="help_block max-sm:hidden">
                    <a href="../term-of-use" class="block">
                        <span class="ph ph-question text-white text-2xl block"></span>
                    </a>
                </div>
                <div class="notification_block relative max-sm:hidden">
                    <button class="relative block">
                        <span class="ph ph-bell text-white text-2xl block"></span>
                        <span class="absolute -top-0.5 right-0.5 w-2 h-2 bg-primary rounded-full"></span>
                    </button>
                    <div class="notification_submenu absolute w-[400px] p-5 top-[3.25rem] -left-9 bg-white rounded-xl">
                        <h6 class="heading6 pb-3">Notifications</h6>
                        <ul class="list_notification w-full">
                            <li
                                class="notification_item w-full py-3 border-t border-line duration-300 hover:bg-background">
                                <a href="#!" class="flex gap-3 w-full">
                                    <span
                                        class="ic_noti flex flex-shrink-0 items-center justify-center w-8 h-8 rounded-full bg-surface">
                                        <span class="ph-fill ph-bell text-lg text-secondary"></span>
                                    </span>
                                    <div class="notification_detail">
                                        <p class="notification_desc text-secondary">The application is rejected on your
                                            job <span class="text-black">UI Designer</span> by <span
                                                class="text-black">Employer</span>.</p>
                                        <span class="notification_time caption2 text-placehover">25 mins ago</span>
                                    </div>
                                </a>
                            </li>
                            <li
                                class="notification_item w-full py-3 border-t border-line duration-300 hover:bg-background">
                                <a href="#!" class="flex gap-3 w-full">
                                    <span
                                        class="ic_noti flex flex-shrink-0 items-center justify-center w-8 h-8 rounded-full bg-surface">
                                        <span class="ph-fill ph-bell text-lg text-secondary"></span>
                                    </span>
                                    <div class="notification_detail">
                                        <p class="notification_desc text-secondary">The application is rejected on your
                                            job <span class="text-black">Internet Security</span> by <span
                                                class="text-black">Employer</span>.</p>
                                        <span class="notification_time caption2 text-placehover">1 hours ago</span>
                                    </div>
                                </a>
                            </li>
                            <li
                                class="notification_item w-full py-3 border-t border-line duration-300 hover:bg-background">
                                <a href="#!" class="flex gap-3 w-full">
                                    <span
                                        class="ic_noti flex flex-shrink-0 items-center justify-center w-8 h-8 rounded-full bg-surface">
                                        <span class="ph-fill ph-bell text-lg text-secondary"></span>
                                    </span>
                                    <div class="notification_detail">
                                        <p class="notification_desc text-secondary">The application is rejected on your
                                            job <span class="text-black">Social Media Marketing</span> by <span
                                                class="text-black">Employer</span>.</p>
                                        <span class="notification_time caption2 text-placehover">5 hours ago</span>
                                    </div>
                                </a>
                            </li>
                            <li
                                class="notification_item w-full py-3 border-t border-line duration-300 hover:bg-background">
                                <a href="#!" class="flex gap-3 w-full">
                                    <span
                                        class="ic_noti flex flex-shrink-0 items-center justify-center w-8 h-8 rounded-full bg-surface">
                                        <span class="ph-fill ph-bell text-lg text-secondary"></span>
                                    </span>
                                    <div class="notification_detail">
                                        <p class="notification_desc text-secondary">The application is rejected on your
                                            job <span class="text-black">Social Media Marketing</span> by <span
                                                class="text-black">Employer</span>.</p>
                                        <span class="notification_time caption2 text-placehover">12 hours ago</span>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <a href="../become-seller" class="button-main max-sm:hidden">Become A Seller</a>
                <div class="user_block relative max-sm:hidden">
                    <button class="user_infor flex items-center gap-2 text-white">
                        <img src="https://www.w3schools.com/howto/img_avatar.png" alt="IMG-7"
                            class="user_avatar flex-shrink-0 w-9 h-9 rounded-full" />
                        <strong class="user_name text-title">Employer</strong>
                        <span class="ph ph-caret-down"></span>
                    </button>
                    <ul class="list_action_user absolute w-[240px] p-3 top-14 right-0 bg-white rounded-lg">
                        <li class="action_item">
                            <a href="../employer/employers-dashboard"
                                class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph ph-squares-four text-2xl text-secondary"></span>
                                <strong class="text-title">Dashboard</strong>
                            </a>
                        </li>
                        <li class="action_item">
                            <a href="../employer/employers-profile"
                                class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                                <span class="ph ph-user-circle text-2xl text-secondary"></span>
                                <strong class="text-title">My Profile</strong>
                            </a>
                        </li>
                        <?php if ($is_candidate_logged_in): ?>
            <!-- Show Log Out -->
            <li class="action_item">
                <a href="logout.php"
                    class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                    <span class="ph ph-sign-out text-2xl text-secondary"></span>
                    <strong class="text-title">Log Out</strong>
                </a>
            </li>
        <?php else: ?>
            <!-- Show Login -->
            <li class="action_item">
                <a href="login.php"
                    class="link flex items-center gap-3 w-full py-3 px-6 rounded-lg duration-300 hover:bg-background">
                    <span class="ph ph-sign-in text-2xl text-secondary"></span>
                    <strong class="text-title">Log In</strong>
                </a>
            </li>
        <?php endif; ?>
                    </ul>
                </div>
                <button class="humburger_btn min-[1400px]:hidden">
                    <span class="ph-bold ph-list text-white text-2xl block"></span>
                </button>
            </div>
        </div>

    </header>

    <div class="menu_mobile">
        <button
            class="menu_mobile_close flex items-center justify-center absolute top-5 left-5 w-8 h-8 rounded-full bg-surface">
            <span class="ph-bold ph-x"></span>
        </button>
        <div class="heading flex items-center justify-center mt-5">
            <a href="../index" class="logo">
                <img src="../assets/images/logo.png" alt="logo" class="h-8" />
            </a>
        </div>
        <form class="form-search relative mt-4 mx-5">
            <button class="absolute left-3 top-1/2 -translate-y-1/2 cursor-pointer">
                <i class="ph ph-magnifying-glass text-xl block"></i>
            </button>
            <input type="text" placeholder="What are you looking for?"
                class="h-12 rounded-lg border border-line text-sm w-full pl-10 pr-4" required />
        </form>
        <div class="mt-4">
            <ul class="nav_mobile">
                <li class="nav_item py-2">
                    <a href="../index" class="text-xl font-semibold flex items-center justify-between">
                        Home

                    </a>

                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        For Candidates
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li class="nav_item">
                                    <a href="../jobs-grid"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse jobs

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="../project-list"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse Projects

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="../employer/employers-list"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse Employer

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="../become-seller"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Become a seller </a>
                                </li>
                                <li class="nav_item">
                                    <a href="candidates-dashboard"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Candidates Dashboard </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        For Employers
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li class="nav_item">
                                    <a href="../services-list"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse services

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="candidates-list"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse candidates

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="../become-buyer"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Become a buyer </a>
                                </li>
                                <li class="nav_item">
                                    <a href="../employer/employers-dashboard"
                                        class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        employer Dashboard </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        Blogs
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <br>
                                <li>
                                    <a href="../blog-list" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Blog list </a>
                                </li>

                                <li>
                                    <a href="../blog-detail"
                                        class="inline-block text-xl font-semibold py-2 capitalize"> Blog detail </a>
                                </li>
                                <br><br><br>

                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        Pages
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li>
                                    <a href="../about" class="inline-block text-xl font-semibold py-2 capitalize">
                                        About Us </a>
                                </li>

                                <li>
                                    <a href="../pricing" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Pricing Plan </a>
                                </li>
                                <li>
                                    <a href="../contact" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Contact Us </a>
                                </li>

                                <li>
                                    <a href="../faqs" class="inline-block text-xl font-semibold py-2 capitalize"> Faqs
                                    </a>
                                </li>
                                <li>
                                    <a href="../term-of-use "
                                        class="inline-block text-xl font-semibold py-2 capitalize"> Terms of use </a>
                                </li>

                                <li>
                                    <a href="login" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Login </a>   
                                </li>
                                <li>
                                    <a href="register" class="inline-block text-xl font-semibold py-2 capitalize">
                                        Register </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
