<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM candidates WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Profile not found.";
    exit;
}

$candidate = $result->fetch_assoc();

function formatDate($date)
{
    return date("F Y", strtotime($date));
}
?>


<!DOCTYPE html>
<html lang="en"> 

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="../assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="../assets/css/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/slick.css" />
    <link rel="stylesheet" href="../assets/css/apexcharts.css" />
    <link rel="stylesheet" href="../assets/css/style.css" />
    <link rel="stylesheet" href="../dist/output-tailwind.css" />
    <link rel="stylesheet" href="../dist/output-scss.css" />
</head>

<body class="lg:overflow-hidden">

    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <div class="dashboard_main overflow-hidden lg:w-screen lg:h-screen flex sm:pt-20 pt-16">

        <!-- <> -->
        <?php include('sidebar.php'); ?>
        <!-- </> -->

        <div class="dashboard_profile scrollbar_custom w-full bg-surface">
            <div class="container h-fit lg:pt-15 lg:pb-30 max-lg:py-12 max-sm:py-8">
                <button class="btn_open_popup btn_menu_dashboard flex items-center gap-2 min-[1400px]:hidden" data-type="menu_dashboard">
                    <span class="ph ph-squares-four text-xl"></span>
                    <strong class="text-button">Menu</strong>
                </button>
                <div class="heading flex flex-wrap items-center justify-between gap-4">
                    <h4 class="heading4 max-lg:mt-3">My Profile</h4>
                    <a href="candidates-profile-setting.php" class="button-main">Edit Profile</a>
                </div>

                <div class="profile_block overflow-hidden flex max-lg:flex-col-reverse gap-y-10 w-full mt-7.5">
                    <!-- Left Sidebar -->
                    <div class="left flex-shrink-0 lg:w-[29.5%]">
                        <div class="info_overview p-8 rounded-lg bg-white shadow-sm">
                            <h5 class="heading5">Info Overview</h5>
                            <ul class="candidates_info pt-1">
                                <li class="industry flex flex-wrap items-center justify-between gap-1 w-full py-4 border-b border-line">
                                    <span class="text-secondary">Name:</span>
                                    <strong class="text-title"><?= htmlspecialchars($candidate['full_name'] ?: 'Not specified') ?></strong>
                                </li>
                                <li class="industry flex flex-wrap items-center justify-between gap-1 w-full py-4 border-b border-line">
                                    <span class="text-secondary">Career Finding:</span>
                                    <strong class="text-title"><?= htmlspecialchars($candidate['job_title'] ?: 'Not specified') ?></strong>
                                </li>
                                <li class="location flex flex-wrap items-center justify-between gap-1 w-full py-4 border-b border-line">
                                    <span class="text-secondary">Location:</span>
                                    <strong class="text-title"><?= htmlspecialchars($candidate['academy'] ?: 'Not specified') ?></strong>
                                </li>
                                <li class="phone flex flex-wrap items-center justify-between gap-1 w-full py-4 border-b border-line">
                                    <span class="text-secondary">Phone:</span>
                                    <strong class="text-title"><?= htmlspecialchars($candidate['phone']) ?></strong>
                                </li>
                                <li class="email flex flex-wrap items-center justify-between gap-1 w-full py-4 border-b border-line">
                                    <span class="text-secondary">Email:</span>
                                    <strong class="text-title"><?= htmlspecialchars($candidate['email']) ?></strong>
                                </li>
                                <li class="salary flex flex-wrap items-center justify-between gap-1 w-full py-4 border-b border-line">
                                    <span class="text-secondary">Offered Salary:</span>
                                    <strong class="text-title">
                                        <?= htmlspecialchars($candidate['salary']) ?>
                                        <?= htmlspecialchars($candidate['salary_type']) ? '/' . htmlspecialchars($candidate['salary_type']) : '' ?>
                                    </strong>
                                </li>
                                <li class="experience flex flex-wrap items-center justify-between gap-1 w-full py-4 border-b border-line">
                                    <span class="text-secondary">Experience:</span>
                                    <strong class="text-title"><?= htmlspecialchars($candidate['experience']) ?></strong>
                                </li>
                                <li class="age flex flex-wrap items-center justify-between gap-1 w-full pt-4">
                                    <span class="text-secondary">Age:</span>
                                    <strong class="text-title"><?= htmlspecialchars($candidate['age']) ?> Years Old</strong>
                                </li>
                            </ul>
                        </div>


                    </div>

                    <!-- Right Content -->
                    <div class="right lg:w-[70.5%] lg:pl-7.5">
                        <div class="about p-8 rounded-lg bg-white shadow-sm">
                            <h5 class="heading5">About me</h5>
                            <div class="desc mt-3">
                                <p class="body2 text-secondary">
                                    <?= nl2br(htmlspecialchars($candidate['description'])) ?>
                                </p>
                            </div>
                        </div>

                        <div class="tools p-8 mt-7.5 rounded-lg bg-white shadow-sm">
                            <h5 class="heading5">Tools</h5>
                            <div class="list flex flex-wrap items-center gap-3 mt-5">
                                <?php
                                $tools = array_filter(array_map('trim', explode(',', $candidate['tools'])));
                                foreach ($tools as $tool) {
                                    echo '<span class="tag bg-surface caption1">' . htmlspecialchars($tool) . '</span>';
                                }
                                ?>
                            </div>
                        </div>

                       
                    </div>
                </div>
            </div>
            <div class="lg:fixed bottom-0 left-0 z-[2] lg:pl-[280px] flex items-center justify-center w-full h-15 bg-white duration-300 shadow-md">
                <span class="copyright caption1 text-secondary">©2024 FreelanHub. All Rights Reserved</span>
            </div>
        </div>
    </div>

    <!-- Menu mobile -->
    <div class="menu_mobile">
        <button class="menu_mobile_close flex items-center justify-center absolute top-5 left-5 w-8 h-8 rounded-full bg-surface">
            <span class="ph-bold ph-x"></span>
        </button>
        <div class="heading flex items-center justify-center mt-5">
            <a href="../index" class="logo">
                <img src="../assets/images/logo.png" alt="logo" class="h-8" />
            </a>
        </div>
        <form class="form-search relative mt-4 mx-5">
            <button class="absolute left-3 top-1/2 -translate-y-1/2 cursor-pointer">
                <i class="ph ph-magnifying-glass text-xl block"></i>
            </button>
            <input type="text" placeholder="What are you looking for?" class="h-12 rounded-lg border border-line text-sm w-full pl-10 pr-4" required />
        </form>
        <div class="mt-4">
            <ul class="nav_mobile">
                <li class="nav_item py-2">
                    <a href="../index" class="text-xl font-semibold flex items-center justify-between">
                        Home

                    </a>

                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        For Candidates
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li class="nav_item">
                                    <a href="../jobs-grid" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse jobs

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="../project-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse Projects

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="../employer/employers-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse Employer

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="../become-seller" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a seller </a>
                                </li>
                                <li class="nav_item">
                                    <a href="candidates-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Candidates Dashboard </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        For Employers
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li class="nav_item">
                                    <a href="../services-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse services

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="candidates-list" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize">
                                        Browse candidates

                                    </a>

                                </li>
                                <li class="nav_item">
                                    <a href="../become-buyer" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> Become a buyer </a>
                                </li>
                                <li class="nav_item">
                                    <a href="../employer/employers-dashboard" class="link flex items-center justify-between w-full py-2 text-xl font-semibold capitalize"> employer Dashboard </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        Blogs
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <br>
                                <li>
                                    <a href="../blog-list" class="inline-block text-xl font-semibold py-2 capitalize"> Blog list </a>
                                </li>

                                <li>
                                    <a href="../blog-detail" class="inline-block text-xl font-semibold py-2 capitalize"> Blog detail </a>
                                </li>
                                <br><br><br>

                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav_item py-2">
                    <a href="#!" class="text-xl font-semibold flex items-center justify-between">
                        Pages
                        <span class="text-right">
                            <i class="ph ph-caret-right text-xl"></i>
                        </span>
                    </a>
                    <div class="sub_nav_mobile">
                        <button class="back_btn flex items-center gap-3">
                            <i class="ph ph-caret-left text-xl"></i>
                            Back
                        </button>
                        <div class="list-nav-item w-full pt-2 pb-6">
                            <ul>
                                <li>
                                    <a href="../about" class="inline-block text-xl font-semibold py-2 capitalize"> About Us </a>
                                </li>

                                <li>
                                    <a href="../pricing" class="inline-block text-xl font-semibold py-2 capitalize"> Pricing Plan </a>
                                </li>
                                <li>
                                    <a href="../contact" class="inline-block text-xl font-semibold py-2 capitalize"> Contact Us </a>
                                </li>

                                <li>
                                    <a href="../faqs" class="inline-block text-xl font-semibold py-2 capitalize"> Faqs </a>
                                </li>
                                <li>
                                    <a href="../term-of-use" class="inline-block text-xl font-semibold py-2 capitalize"> Terms of use </a>
                                </li>

                                <li>
                                    <a href="login" class="inline-block text-xl font-semibold py-2 capitalize"> Login </a>
                                </li>
                                <li>
                                    <a href="register" class="inline-block text-xl font-semibold py-2 capitalize"> Register </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>

    <!-- Modal -->
    <!-- Menu mobile -->

    <?php include('mobile-menu.php'); ?>

    <!-- </> -->

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/phosphor-icons.js"></script>
    <script src="../assets/js/slick.min.js"></script>
    <script src="../assets/js/leaflet.js"></script>
    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/apexcharts.js"></script>
    <script src="../assets/js/main.js"></script>
</body>

</html>