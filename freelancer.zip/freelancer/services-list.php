<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/css/leaflet.css" />
    <link rel="stylesheet" href="assets/css/slick.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="dist/output-tailwind.css" />
    <link rel="stylesheet" href="dist/output-scss.css" />
</head>

<body>
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="breadcrumb_inner relative sm:mt-20 mt-16 lg:py-20 py-14">
            <div class="breadcrumb_bg absolute top-0 left-0 w-full h-full">
                <img src="assets/images/components/breadcrumb_service.webp" alt="breadcrumb_service" class="w-full h-full object-cover" />
            </div>
            <div class="container relative h-full">
                <div class="breadcrumb_content flex flex-col items-start justify-center xl:w-[1000px] lg:w-[848px] md:w-5/6 w-full h-full">
                    <div class="list_breadcrumb flex items-center gap-2 animate animate_top" style="--i: 1">
                        <a href="index" class="caption1 text-white">Home</a>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white">For Employers</span>
                        <span class="caption1 text-white opacity-40">/</span>
                        <span class="caption1 text-white opacity-60">Services</span>
                    </div>
                    <h3 class="heading3 text-white mt-2 animate animate_top" style="--i: 2">Services List</h3>
                    <div class="form_search z-[1] w-full mt-5 animate animate_top" style="--i: 3">
                        <form class="form_inner flex items-center justify-between max-sm:flex-wrap gap-6 gap-y-4 relative w-full p-3 rounded-lg bg-white">
                            <div class="form_input relative w-full">
                                <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-2 text-xl"></span>
                                <input type="text" class="input_search w-full h-full pl-10" placeholder="Job title, key words or company" required />
                            </div>
                            <div class="select_block flex-shrink-0 max-sm:w-full sm:pr-16 pr-7 sm:pl-6 pl-3 sm:border-l border-line">
                                <div class="select">
                                    <span class="selected" data-title="City, State or Zip">City, State or Zip</span>
                                    <ul class="list_option bg-white max-sm:w-full">
                                        <li data-item="Las Vegas, USA">Las Vegas, USA</li>
                                        <li data-item="Cape Town, South Africa">Cape Town, South Africa</li>
                                        <li data-item="Sydney, Australia">Sydney, Australia</li>
                                        <li data-item="Tokyo, Japan">Tokyo, Japan</li>
                                    </ul>
                                </div>
                                <span class="icon_down ph ph-caret-down sm:text-2xl text-xl sm:right-0 right-3"></span>
                            </div>
                            <div class="select_block flex-shrink-0 max-sm:w-full sm:pr-16 pr-7 sm:pl-6 pl-3 sm:border-l border-line">
                                <div class="select">
                                    <span class="selected" data-title="All Categories">All Categories</span>
                                    <ul class="list_option bg-white max-sm:w-full">
                                        <li data-item="Graphic & Design">Graphic & Design</li>
                                        <li data-item="Wrting">Wrting</li>
                                        <li data-item="Videos">Videos</li>
                                        <li data-item="Digital Marketing">Digital Marketing</li>
                                    </ul>
                                </div>
                                <span class="icon_down ph ph-caret-down sm:text-2xl text-xl sm:right-0 right-3"></span>
                            </div>
                            <button type="submit" class="button-main max-sm:w-1/3 text-center flex-shrink-0">Search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- List services -->
    <div class="services lg:py-20 sm:py-14 py-10">
        <div class="container flex flex-col items-center">
            <div class="filter flex flex-wrap items-center justify-between gap-8 gap-y-3 relative w-full">
                <button id="filter_btn" class="filter_btn inline-flex items-center gap-1.5 py-1.5 px-2.5 border border-line rounded-md duration-300 hover:bg-primary hover:text-white">
                    <span class="ph ph-sliders-horizontal text-xl"></span>
                    <span>Filters</span>
                </button>
                <ul class="list_layout flex items-center gap-2 sm:absolute sm:left-1/2 sm:-translate-x-1/2">
                    <li class="max-xl:hidden">
                        <button class="layout_btn cols_2 active"></button>
                    </li>
                    <li class="max-xl:hidden">
                        <button class="layout_btn cols_1 list"></button>
                    </li>
                    <li class="xl:hidden">
                        <a href="services-default" class="layout_link cols_2"></a>
                    </li>
                    <li class="xl:hidden">
                        <a href="#!" class="layout_link list active"></a>
                    </li>
                </ul>
                <div class="select_filter flex items-center gap-3">
                    <span class="caption1">Sort by:</span>
                    <div class="select_block sm:pr-16 pr-10 pl-3 py-1 border border-line rounded">
                        <div class="select">
                            <span class="selected caption1 capitalize" data-title="sort default">default</span>
                            <ul class="list_option p-0 bg-white">
                                <li class="capitalize" data-item="default">sort by (default)</li>
                                <li class="capitalize" data-item="newest">newest</li>
                                <li class="capitalize" data-item="oldest">oldest</li>
                                <li class="capitalize" data-item="random">random</li>
                            </ul>
                        </div>
                        <span class="icon_down ph ph-caret-down right-3"></span>
                    </div>
                </div>
            </div>
            <div class="list_filtered flex flex-wrap items-center gap-3 w-full mt-5">
                <span class="quantity pr-3 border-r border-line">1,200+ Results</span>
                <div class="list flex flex-wrap items-center gap-3"></div>
                <button class="clear_all_btn inline-flex items-center gap-1 py-1 px-2 border border-red text-red rounded-full duration-300 hover:bg-red hover:text-white">
                    <span class="ph ph-x text-sm"></span>
                    <span class="caption1">Clear All</span>
                </button>
            </div>
            <ul class="list_layout_cols list grid lg:grid-cols-2 gap-7.5 w-full md:mt-10 mt-7">
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/1.webp" alt="1" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Photography</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will create stunning logo designs for your business</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-1.webp" alt="IMG-1" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Floyd Miles</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$75</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/2.webp" alt="2" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Development</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will write engaging blog posts that drive traffic</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-2.webp" alt="IMG-2" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Eleanor Pena</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$82</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/3.webp" alt="3" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">UI/UX Design</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">High-quality video editing for your marketing campaign</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-3.webp" alt="IMG-3" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Dianne Russell</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$99</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/4.webp" alt="4" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Digital Marketing</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will do figma UI UX design for websites & landing page</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-4.webp" alt="IMG-4" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Robert Fox</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$94</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/5.webp" alt="5" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">UI/UX Design</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">Professional voiceover services for your videos</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-5.webp" alt="IMG-5" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Theresa Webb</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$91</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/6.webp" alt="6" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Development</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will translate your documents with accuracy and precision</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-6.webp" alt="IMG-6" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Marvin McKinney</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$83</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/7.webp" alt="7" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Photography</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will design wordpress website with elementor pro</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-7.webp" alt="IMG-7" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Floyd Miles</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$75</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/8.webp" alt="8" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Programming</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will do figma UI UX design for websites & landing page</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-8.webp" alt="IMG-8" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Floyd Miles</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$75</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/9.webp" alt="9" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Programming</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will do background illustration and environment concept art</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-9.webp" alt="IMG-9" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Floyd Miles</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$75</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/10.webp" alt="10" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Digital Marketing</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will draw vector line art illustration image</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-10.webp" alt="IMG-10" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Floyd Miles</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$75</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/11.webp" alt="11" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Programming</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will design wordpress website with elementor pro</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-11.webp" alt="IMG-11" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Floyd Miles</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$75</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="item h-full">
                    <div class="service_item -style-list overflow-hidden sm:flex relative h-full rounded-lg bg-white shadow-lg duration-300 hover:shadow-2xl">
                        <div class="service_thumb flex-shrink-0 relative sm:w-[44%] w-full">
                            <a href="services-detail" class="block">
                                <img src="assets/images/service/12.webp" alt="12" class="w-full h-full object-cover" />
                            </a>
                            <button class="add_wishlist_btn">
                                <span class="ph ph-heart text-xl"></span>
                                <span class="ph-fill ph-heart text-xl"></span>
                            </button>
                        </div>
                        <div class="service_info flex flex-col justify-between w-full py-5 px-6">
                            <div class="service_detail_info">
                                <div class="flex items-center justify-between">
                                    <a href="services-default" class="tag caption2 bg-surface hover:bg-primary hover:text-white">Digital Marketing</a>
                                    <div class="rate flex items-center gap-1">
                                        <span class="ph-fill ph-star text-yellow text-xs"></span>
                                        <strong class="service_rate text-button-sm">4.9</strong>
                                        <span class="service_rate_quantity caption1 text-secondary">(482)</span>
                                    </div>
                                </div>
                                <a href="services-detail" class="service_title text-title pt-2 duration-300 hover:text-primary">I will do figma UI UX design for websites & landing page</a>
                            </div>
                            <div class="service_more_info flex items-center justify-between gap-1 mt-4 pt-4 border-t border-line">
                                <a href="candidates/candidates-detail" class="service_author flex items-center gap-2">
                                    <img src="assets/images/avatar/IMG-12.webp" alt="IMG-12" class="service_author_avatar w-8 h-8 rounded-full" />
                                    <span class="service_author_name -style-1">Floyd Miles</span>
                                </a>
                                <div class="service_price whitespace-nowrap">
                                    <span class="text-secondary">From </span>
                                    <span class="price text-title">$75</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
            <ul class="list_pagination menu_tab flex items-center justify-center gap-2 w-full md:mt-10 mt-7" role="tablist">
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black active" role="tab" aria-selected="true">1</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">2</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">3</a>
                </li>
                <li role="presentation">
                    <a href="#" class="tab_btn -fill flex items-center justify-center w-10 h-10 rounded border border-line text-title duration-300 hover:border-black" role="tab" aria-selected="false">></a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    <!-- footer start  -->
    <?php include('footer.php'); ?>

    <!-- end  -->


    <!-- Menu mobile -->
    
    <!-- Modal -->
    <div class="modal">
        <div class="sidebar min-[390px]:w-[348px] w-[80vw] h-full bg-white">
            <form class="h-full">
                <div class="block_filter h-full py-4 px-6">
                    <div class="filter_section search">
                        <strong class="text-button">search</strong>
                        <div class="form_input relative w-full h-12 mt-2">
                            <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-xl"></span>
                            <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Job title, key words or company" />
                        </div>
                    </div>
                    <div class="filter_section category relative z-[2] mt-6">
                        <strong class="text-button">category</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select category">Select category</span>
                                <div class="list_option w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find category..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="Accounting & Consulting">Accounting & Consulting</li>
                                        <li class="capitalize" data-item="Admin Support">Admin Support</li>
                                        <li class="capitalize" data-item="Customer Service">Customer Service</li>
                                        <li class="capitalize" data-item="Design & Creative">Design & Creative</li>
                                        <li class="capitalize" data-item="Data Science & Analytics">Data Science & Analytics</li>
                                        <li class="capitalize" data-item="Design & Creative">Design & Creative</li>
                                        <li class="capitalize" data-item="Engineering & Architecture">Engineering & Architecture</li>
                                        <li class="capitalize" data-item="IT & Networking">IT & Networking</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="filter_section experience mt-6">
                        <strong class="text-button">Seller level</strong>
                        <div class="list_level flex flex-col gap-2 mt-2">
                            <div class="checkbox_block">
                                <input type="checkbox" class="checkbox" id="entry" data-label="entry" />
                                <span class="ph-fill ph-check-square text-xl check_icon"></span>
                                <label class="label pl-6" for="entry">Entry Level</label>
                            </div>
                            <div class="checkbox_block">
                                <input type="checkbox" class="checkbox" id="intermediate" data-label="intermediate" />
                                <span class="ph-fill ph-check-square text-xl check_icon"></span>
                                <label class="label pl-6" for="intermediate">Intermediate</label>
                            </div>
                            <div class="checkbox_block">
                                <input type="checkbox" class="checkbox" id="expert" data-label="expert" />
                                <span class="ph-fill ph-check-square text-xl check_icon"></span>
                                <label class="label pl-6" for="expert">Expert</label>
                            </div>
                        </div>
                    </div>
                    <div class="filter_section filter_price mt-6">
                        <strong class="text-button">Budget</strong>
                        <div class="tow_bar_block mt-5">
                            <div class="progress"></div>
                        </div>
                        <div class="range_input">
                            <input class="input range_min" type="range" min="0" max="3000" value="0" />
                            <input class="input range_max" type="range" min="0" max="3000" value="3000" />
                        </div>
                        <div class="price_block flex items-center justify-between mt-4">
                            <div class="price_min flex items-center overflow-hidden relative w-32 h-10">
                                <span class="text-button text-secondary absolute top-1/2 -translate-y-1/2 left-3">$</span>
                                <input type="number" class="caption1 w-full h-full pl-7 pr-10 border border-line rounded-lg" value="0" />
                                <span class="caption1 text-placehover absolute top-1/2 -translate-y-1/2 right-3">min</span>
                            </div>
                            <span class="ph-bold ph-minus text-xl"></span>
                            <div class="price_max flex items-center overflow-hidden relative w-32 h-10">
                                <span class="text-button text-secondary absolute top-1/2 -translate-y-1/2 left-3">$</span>
                                <input type="number" class="caption1 w-full h-full pl-7 pr-10 border border-line rounded-lg" value="3000" />
                                <span class="caption1 text-placehover absolute top-1/2 -translate-y-1/2 right-3">max</span>
                            </div>
                        </div>
                    </div>
                    <div class="filter_section delivery mt-6">
                        <strong class="text-button">Delivery</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select delivery">Select delivery</span>
                                <div class="list_option w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find location..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="Express 24H">Express 24H</li>
                                        <li class="capitalize" data-item="ViettelPost">ViettelPost</li>
                                        <li class="capitalize" data-item="GHN">GHN</li>
                                        <li class="capitalize" data-item="GHTK">GHTK</li>
                                        <li class="capitalize" data-item="Aha Move">Aha Move</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="filter_section location mt-6">
                        <strong class="text-button">Location</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select location">Select location</span>
                                <div class="list_option w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find location..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="Africa">Africa</li>
                                        <li class="capitalize" data-item="Americas">Americas</li>
                                        <li class="capitalize" data-item="Antarctica">Antarctica</li>
                                        <li class="capitalize" data-item="Asia">Asia</li>
                                        <li class="capitalize" data-item="Europe">Europe</li>
                                        <li class="capitalize" data-item="Oceania">Oceania</li>
                                        <li class="capitalize" data-item="Australia and New Zealand">Australia and New Zealand</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="filter_section timezone mt-6">
                        <strong class="text-button">timezone</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select timezone">Select timezone</span>
                                <div class="list_option -top w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find timezone..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="(UTC-11:00) Midway Island">(UTC-11:00) Midway Island</li>
                                        <li class="capitalize" data-item="(UTC-10:00) Hawaii">(UTC-10:00) Hawaii</li>
                                        <li class="capitalize" data-item="(UTC-08:00) Alaska">(UTC-08:00) Alaska</li>
                                        <li class="capitalize" data-item="(UTC-07:00) Pacific Time">(UTC-07:00) Pacific Time</li>
                                        <li class="capitalize" data-item="(UTC-07:00) Arizona">(UTC-07:00) Arizona</li>
                                        <li class="capitalize" data-item="(UTC-06:00) Mountain Time ">(UTC-06:00) Mountain Time</li>
                                        <li class="capitalize" data-item="(UTC-05:00) Eastern Time">(UTC-05:00) Eastern Time</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                    <div class="filter_section english mt-6">
                        <strong class="text-button">English Level</strong>
                        <div class="select_block flex items-center w-full h-12 pr-10 pl-3 mt-2 border border-line rounded-lg">
                            <div class="select">
                                <span class="selected capitalize" data-title="Select english level">Select english level</span>
                                <div class="list_option -top w-full bg-white">
                                    <div class="form_input relative w-full h-11">
                                        <span class="icon_search ph-bold ph-magnifying-glass absolute top-1/2 -translate-y-1/2 left-3 text-lg"></span>
                                        <input type="text" class="input_search w-full h-full pl-10 pr-3 border border-line rounded-lg" placeholder="Find level..." />
                                    </div>
                                    <ul class="list_result mt-3">
                                        <li class="capitalize" data-item="Basic">Basic</li>
                                        <li class="capitalize" data-item="Conversational">Conversational</li>
                                        <li class="capitalize" data-item="Fluent">Fluent</li>
                                        <li class="capitalize" data-item="Native Or Bilingual">Native Or Bilingual</li>
                                        <li class="capitalize" data-item="Professional">Professional</li>
                                    </ul>
                                </div>
                            </div>
                            <span class="icon_down ph ph-caret-down right-3"></span>
                        </div>
                    </div>
                </div>
                <div class="block_btn absolute right-0 bottom-0 left-0 z-[1] bg-white h-[68px] py-2.5 px-6">
                    <button class="button-main w-full text-center">Find Services</button>
                </div>
            </form>
        </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/phosphor-icons.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/leaflet.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>


</html>