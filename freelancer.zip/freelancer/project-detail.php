<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/css/leaflet.css" />
    <link rel="stylesheet" href="assets/css/slick.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="dist/output-tailwind.css" />
    <link rel="stylesheet" href="dist/output-scss.css" />
</head>

<body class="lg:overflow-unset">
    <!-- header start  -->
    <?php include('header.php'); ?>

    <!-- end  -->

    <!-- Breadcrumb -->
    <section class="breadcrumb bg-[#F9F2EC] sm:pt-35 pt-30 py-15">
        <div class="container flex max-lg:flex-col lg:items-center justify-between gap-5 gap-y-3">
            <div class="breadcrumb_info">
                <h3 class="heading3">Need a UX designer to design a website on figma</h3>
                <ul class="list flex flex-wrap items-center gap-4 mt-3">
                    <li class="time_area flex items-center gap-1 pr-4 border-r border-line">
                        <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                        <span class="time body2">2 days ago</span>
                    </li>
                    <li class="address_area flex items-center gap-1 pr-4 border-r border-line">
                        <span class="ph ph-map-pin text-xl text-secondary"></span>
                        <span class="address body2">Las Vegas, USA</span>
                    </li>
                    <li class="spent_area flex items-center gap-1 pr-4">
                        <span class="body2">$</span>
                        <span class="spent body2">2.8K</span>
                        <span class="body2 text-secondary">spent</span>
                    </li>
                </ul>
            </div>
            <div class="breadcrumb_action flex flex-col max-lg:flex-col-reverse lg:items-end lg:gap-5 gap-3">
                <div class="flex gap-3">
                    <button class="button_share flex items-center justify-center w-12 h-12 border border-line rounded-full bg-white duration-300 hover:border-black">
                        <span class="ph ph-share-network text-2xl"></span>
                        <ul class="social">
                            <li class="social_item">
                                <a href="https://www.facebook.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-facebook"></span>
                                </a>
                            </li>
                            <li class="social_item">
                                <a href="https://www.linkedin.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-linkedin"></span>
                                </a>
                            </li>
                            <li class="social_item">
                                <a href="https://www.twitter.com/" target="_blank" class="social_link w-9 h-9 flex items-center justify-center border border-line text-white rounded-full duration-300 hover:bg-white hover:text-black">
                                    <span class="icon-twitter"></span>
                                </a>
                            </li>
                        </ul>
                    </button>
                    <button class="add_wishlist_btn -relative -border w-12">
                        <span class="ph ph-heart text-2xl"></span>
                        <span class="ph-fill ph-heart text-2xl"></span>
                    </button>
                </div>
                <div class="price_area whitespace-nowrap">
                    <span class="body2 text-secondary">Budget</span>
                    <strong class="heading5 ml-0.5">$900</strong>
                </div>
            </div>
        </div>
    </section>

    <section class="project_detail lg:py-20 sm:py-14 py-10">
        <div class="container flex max-lg:flex-col gap-y-10">
            <div class="project_info w-full lg:pr-15">
                <div class="overview">
                    <h6 class="heading6">Projects Overview</h6>
                    <ul class="list_overview grid sm:grid-cols-3 grid-cols-2 gap-6 w-full mt-4">
                        <li class="flex items-center gap-3">
                            <span class="ph ph-calendar-blank flex-shrink-0 text-4xl"></span>
                            <div>
                                <span class="block text-secondary">Date Posted:</span>
                                <strong class="text-button">April 20, 2024</strong>
                            </div>
                        </li>
                        <li class="flex items-center gap-3">
                            <span class="ph ph-suitcase-simple flex-shrink-0 text-4xl"></span>
                            <div>
                                <span class="block text-secondary">Project Type:</span>
                                <strong class="text-button">Fixed</strong>
                            </div>
                        </li>
                        <li class="flex items-center gap-3">
                            <span class="ph ph-clock-countdown flex-shrink-0 text-4xl"></span>
                            <div>
                                <span class="block text-secondary">Project Duration:</span>
                                <strong class="text-button">100 hours</strong>
                            </div>
                        </li>
                        <li class="flex items-center gap-3">
                            <span class="ph ph-hourglass flex-shrink-0 text-4xl"></span>
                            <div>
                                <span class="block text-secondary">Hours:</span>
                                <strong class="text-button">35h /week</strong>
                            </div>
                        </li>
                        <li class="flex items-center gap-3">
                            <span class="ph ph-chart-bar flex-shrink-0 text-4xl"></span>
                            <div>
                                <span class="block text-secondary">Experience:</span>
                                <strong class="text-button">4 Year</strong>
                            </div>
                        </li>
                        <li class="flex items-center gap-3">
                            <span class="ph ph-translate flex-shrink-0 text-4xl"></span>
                            <div>
                                <span class="block text-secondary">English Level:</span>
                                <strong class="text-button">Fluent</strong>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="description md:mt-10 mt-7">
                    <h6 class="heading6">Projects description</h6>
                    <div class="flex flex-col gap-4 mt-4 body2 text-secondary">
                        <p>Actively Looking For A Freelance/Open Format UI/UX Fullstack Developer Versatile In MERN For Rectifying UI & Make UI responsive to Devices on Recently Launched Website</p>
                        <p>As a Lead User Experience Designer, you will collaborate closely with our Creative Directors and Associate Creative Directors to conceptualize and execute innovative campaigns and digital experiences. You'll play a key role in making strategic UX decisions and creating wireframes that guide the user journey.</p>
                    </div>
                </div>
                <div class="requirements md:mt-10 mt-7">
                    <h6 class="heading6">Requirements:</h6>
                    <ul class="list_requirements w-full mt-4">
                        <li class="flex body2 text-secondary">
                            <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                            <p>10-12 Pages : 6 Similar Pages</p>
                        </li>
                        <li class="flex body2 text-secondary">
                            <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                            <p>Dual Environment : Logged-In & Logged Out/Universal</p>
                        </li>
                        <li class="flex body2 text-secondary">
                            <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                            <p>Micro Tasks On Each Page & Code Alterations : Header Alignment, Footer Alignment, Card Alignments, Overlap Rectification, Square Movement, Back Ground Video Alteration etc.</p>
                        </li>
                        <li class="flex body2 text-secondary">
                            <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                            <p>Pre-Defined Content Cards</p>
                        </li>
                        <li class="flex body2 text-secondary">
                            <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                            <p>Pre-Defined Design Format</p>
                        </li>
                        <li class="flex body2 text-secondary">
                            <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                            <p>Source Codes Available</p>
                        </li>
                        <li class="flex body2 text-secondary">
                            <span class="ph-fill ph-dot-outline mt-1 mr-1"></span>
                            <p>Server Deplorable</p>
                        </li>
                    </ul>
                </div>
                <div class="attachments md:mt-10 mt-7">
                    <h6 class="heading6">Attachments:</h6>
                    <ul class="list_attachments flex flex-wrap gap-7.5 gap-y-5 mt-4">
                        <li>
                            <a href="#!" class="flex items-center justify-between gap-3 w-[240px] h-[76px] p-3 rounded-lg bg-surface duration-300 hover:bg-background">
                                <div>
                                    <span class="text-sm font-bold text-secondary uppercase">file_name_pdf</span>
                                    <strong class="block mt-1 text-title cursor-pointer">PDF</strong>
                                </div>
                                <span class="ph ph-file-pdf flex-shrink-0 text-4xl text-primary"></span>
                            </a>
                        </li>
                        <li>
                            <a href="#!" class="flex items-center justify-between gap-3 w-[240px] h-[76px] p-3 rounded-lg bg-surface duration-300 hover:bg-background">
                                <div>
                                    <span class="text-sm font-bold text-secondary uppercase">file_name_doc</span>
                                    <strong class="block mt-1 text-title cursor-pointer">DOC</strong>
                                </div>
                                <span class="ph ph-file-doc flex-shrink-0 text-4xl text-primary"></span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="skills md:mt-10 mt-7">
                    <h6 class="heading6">Skills Required:</h6>
                    <ul class="list_skills flex flex-wrap gap-3 gap-y-5 mt-4">
                        <li>
                            <a href="project-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Website Design </a>
                        </li>
                        <li>
                            <a href="project-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Mobile App </a>
                        </li>
                        <li>
                            <a href="project-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Animation </a>
                        </li>
                        <li>
                            <a href="project-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Adobe Photoshop </a>
                        </li>
                        <li>
                            <a href="project-default" class="tag -large text-sm font-semibold bg-surface hover:bg-primary hover:text-white"> Figma </a>
                        </li>
                    </ul>
                </div>
                <div class="bid md:mt-10 mt-7">
                    <h6 class="heading6">Bid range:</h6>
                    <ul class="list_bid flex flex-wrap gap-5 mt-4">
                        <li>
                            <span class="text-secondary mr-0.5">Low:</span>
                            <strong class="text-button">$650</strong>
                        </li>
                        <li>
                            <span class="text-secondary mr-0.5">Avg:</span>
                            <strong class="text-button">$750</strong>
                        </li>
                        <li>
                            <span class="text-secondary mr-0.5">High:</span>
                            <strong class="text-button">$900</strong>
                        </li>
                    </ul>
                </div>
                <div class="related lg:mt-15 mt-8">
                    <h5 class="heading5">Related Projects</h5>
                    <ul class="list_related flex flex-col md:gap-7.5 gap-6 w-full mt-5">
                        <li>
                            <div class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                                <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                                    <div class="project_info">
                                        <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Figma mockup needed for a new website for Electrical contractor business website</a>
                                        <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                            <div class="project_date flex items-center gap-1">
                                                <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                                <span class="caption1 text-secondary">2 days ago</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-map-pin text-xl text-secondary"></span>
                                                <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                            </div>
                                            <div class="project_spent flex items-center gap-1">
                                                <span class="caption1 text-secondary">$</span>
                                                <span class="caption1 text-secondary">2.8K</span>
                                                <span class="caption1 text-secondary">spent</span>
                                            </div>
                                            <div class="project_rate flex items-center gap-1">
                                                <span class="rate caption1 text-secondary">4.8</span>
                                                <span class="ph-fill ph-star text-yellow -mt-0.5"></span>
                                            </div>
                                        </div>
                                        <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                                        <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                            <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                            <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                            <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                                        </div>
                                    </div>
                                    <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                                    <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                                        <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                            <span class="ph ph-heart text-xl"></span>
                                            <span class="ph-fill ph-heart text-xl"></span>
                                        </button>
                                        <div class="max-sm:w-full max-sm:order-[-1]">
                                            <div class="project_proposals sm:text-end">
                                                <span class="text-secondary">Proposals: </span>
                                                <span class="proposals">50+</span>
                                            </div>
                                            <div class="project_price sm:text-end mt-1">
                                                <span class="price text-title">$170</span>
                                                <span class="text-secondary">/fixed-price</span>
                                            </div>
                                        </div>
                                        <a href="project-detail" class="button-main -border h-fit">See more</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="project_item py-5 px-6 rounded-lg bg-white duration-300 shadow-md">
                                <div class="project_innner flex max-sm:flex-col items-center justify-between xl:gap-9 gap-6 h-full">
                                    <div class="project_info">
                                        <a href="project-detail" class="project_name heading6 duration-300 hover:underline">Web & Responsive for an Online Tutoring Website</a>
                                        <div class="project_related_info flex flex-wrap items-center gap-3 mt-3">
                                            <div class="project_date flex items-center gap-1">
                                                <span class="ph ph-calendar-blank text-xl text-secondary"></span>
                                                <span class="caption1 text-secondary">2 days ago</span>
                                            </div>
                                            <div class="flex items-center gap-1">
                                                <span class="ph ph-map-pin text-xl text-secondary"></span>
                                                <span class="project_address -style-1 caption1 text-secondary">Las Vegas, USA</span>
                                            </div>
                                            <div class="project_spent flex items-center gap-1">
                                                <span class="caption1 text-secondary">$</span>
                                                <span class="caption1 text-secondary">2.8K</span>
                                                <span class="caption1 text-secondary">spent</span>
                                            </div>
                                            <div class="project_rate flex items-center gap-1">
                                                <span class="rate caption1 text-secondary">4.8</span>
                                                <span class="ph-fill ph-star text-yellow -mt-0.5"></span>
                                            </div>
                                        </div>
                                        <p class="project_desc mt-3 text-secondary">I am looking for a talented UX/UI Designer to create screens for my basic product idea. The project involves designing a web application, you may be missing out on some big opportunities.</p>
                                        <div class="list_tag flex items-center gap-2.5 flex-wrap mt-3">
                                            <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Graphic Design</a>
                                            <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Website Design</a>
                                            <a href="project-default" class="project_tag tag bg-surface caption1 hover:text-white hover:bg-primary">Figma</a>
                                        </div>
                                    </div>
                                    <div class="line flex-shrink-0 w-px h-full bg-line max-sm:hidden"></div>
                                    <div class="project_more_info flex flex-shrink-0 max-sm:flex-wrap sm:flex-col sm:items-end items-start sm:gap-7 gap-4 max-sm:w-full sm:h-full">
                                        <button class="add_wishlist_btn -relative -border max-sm:order-1">
                                            <span class="ph ph-heart text-xl"></span>
                                            <span class="ph-fill ph-heart text-xl"></span>
                                        </button>
                                        <div class="max-sm:w-full max-sm:order-[-1]">
                                            <div class="project_proposals sm:text-end">
                                                <span class="text-secondary">Proposals: </span>
                                                <span class="proposals">50+</span>
                                            </div>
                                            <div class="project_price sm:text-end mt-1">
                                                <span class="price text-title">$170</span>
                                                <span class="text-secondary">/fixed-price</span>
                                            </div>
                                        </div>
                                        <a href="project-detail" class="button-main -border h-fit">See more</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="project_sidebar lg:sticky lg:top-24 flex-shrink-0 lg:w-[380px] w-full h-fit">
                <div class="apply overflow-hidden rounded-xl bg-white shadow-md duration-300">
                    <div class="flex items-center justify-between px-5 py-4 border-b border-line">
                        <h6 class="heading6">Bidding ends</h6>
                        <div class="countdown_time flex items-center gap-1 text-red">
                            <span class="ph ph-clock text-2xl"></span>
                            <span class="hour heading6">40h</span>
                            <span class="heading6">:</span>
                            <span class="minute heading6">32m</span>
                            <span class="heading6">:</span>
                            <span class="second heading6">30s</span>
                        </div>
                    </div>
                    <form class="p-5">
                        <div class="amount">
                            <label for="bid_amount" class="label caption1">Set your bid amount <span class="text-red">*</span></label>
                            <input type="text" id="bid_amount" name="bid_amount" class="w-full h-12 mt-2 px-4 border border-line rounded text-title" placeholder="Enter your bid amount" required />
                        </div>
                        <div class="delivery mt-5">
                            <label for="set_days" class="label caption1">Set your delivery in days <span class="text-red">*</span></label>
                            <div class="flex items-center gap-2 w-full mt-2">
                                <span class="minus_btn flex flex-shrink-0 items-center justify-center w-12 h-12 border border-line rounded cursor-pointer duration-300 hover:border-primary">
                                    <span class="ph ph-minus text-xl"></span>
                                </span>
                                <div class="days flex items-center justify-center gap-1 w-full h-12 border border-line rounded">
                                    <input type="text" id="set_days" name="set_days" class="field text-title border-none" value="30" maxlength="3" required />
                                    <strong class="text-title">days</strong>
                                </div>
                                <span class="plus_btn flex flex-shrink-0 items-center justify-center w-12 h-12 border border-line rounded cursor-pointer duration-300 hover:border-primary">
                                    <span class="ph ph-plus text-xl"></span>
                                </span>
                            </div>
                        </div>
                        <button class="btn_open_popup apply_btn button-main w-full mt-5 text-center" data-type="modal_apply">Apply Now</button>
                    </form>
                </div>
                <div class="about overflow-hidden mt-7.5 rounded-xl bg-white shadow-md duration-300">
                    <div class="flex items-center justify-between px-5 py-4 border-b border-line">
                        <h6 class="heading6">About the Employer</h6>
                    </div>
                    <div class="employer_info p-5">
                        <a href="employers-detail" class="flex items-center gap-5 w-full">
                            <img src="assets/images/company/1.png" alt="company/1" class="flex-shrink-0 w-20 h-20" />
                            <div>
                                <div class="rate flex items-center pb-1">
                                    <span class="ph-fill ph-star text-yellow"></span>
                                    <span class="ph-fill ph-star text-yellow"></span>
                                    <span class="ph-fill ph-star text-yellow"></span>
                                    <span class="ph-fill ph-star text-yellow"></span>
                                    <span class="ph-fill ph-star text-placehover"></span>
                                </div>
                                <strong class="employers_name heading6">PrimeEdge Solutions</strong>
                                <span class="employers_establish text-secondary">Since December 11, 2020</span>
                            </div>
                        </a>
                        <div class="industry flex items-center justify-between w-full py-5 border-b border-line">
                            <span class="text-secondary">Industry:</span>
                            <strong class="text-button">Internet Publishing</strong>
                        </div>
                        <div class="size flex items-center justify-between w-full py-5 border-b border-line">
                            <span class="text-secondary">Company size:</span>
                            <strong class="text-button">150 Employees</strong>
                        </div>
                        <div class="address flex items-center justify-between w-full py-5 border-b border-line">
                            <span class="text-secondary">Address:</span>
                            <strong class="text-button">3 SValley , Las Vegas, USA</strong>
                        </div>
                        <div class="list_social flex flex-wrap items-center justify-between gap-4 w-full py-5">
                            <span class="text-secondary">Socials:</span>
                            <ul class="list flex flex-wrap items-center gap-3">
                                <li>
                                    <a href="https://www.facebook.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-facebook text-lg"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-linkedin text-lg"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.twitter.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-twitter text-lg"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.instagram.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-instagram text-lg"></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.pinterest.com/" target="_blank" class="w-10 h-10 flex items-center justify-center border border-line rounded-full text-black duration-300 hover:bg-primary">
                                        <span class="icon-pinterest text-lg"></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <a href="candidates/candidates-messages" class="button-main w-full text-center">Send Message</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    <!-- footer start  -->
    <?php include('footer.php'); ?>

    <!-- end  -->

    <!-- Menu mobile -->
    
    <!-- Modal -->
    <div class="modal">
        <div class="modal_item modal_apply overflow-hidden md:w-[660px] w-[90vw] rounded-xl bg-white" data-type="modal_apply">
            <div class="flex items-center justify-between px-7.5 py-6 border-b border-line">
                <h6 class="heading6">Apply Projects</h6>
                <button class="close_popup_btn">
                    <span class="ph ph-x text-2xl"></span>
                </button>
            </div>
            <form class="p-7.5">
                <div class="cover_letter">
                    <label for="cover_letter" class="label caption1">Cover letter <span class="text-red">*</span></label>
                    <textarea id="cover_letter" name="cover_letter" class="w-full h-32 mt-2 px-4 py-3 border border-line rounded" placeholder="Enter your cover letter" required></textarea>
                </div>
                <div class="file mt-5">
                    <label for="file_attached" class="label caption1">Attach file: <span class="text-red">*</span></label>
                    <div class="flex flex-wrap items-center gap-2 w-full mt-2">
                        <div class="upload_file flex items-center gap-3 w-[220px] px-3 py-2 border border-line rounded">
                            <label for="file_attached" class="caption2 py-1 px-3 rounded bg-line whitespace-nowrap cursor-pointer">Choose File</label>
                            <input type="file" name="file_attached" id="file_attached" class="caption2 cursor-pointer" required />
                        </div>
                        <span class="caption2 text-secondary">Up to 200 MB</span>
                    </div>
                </div>
                <button class="button-main w-full mt-5 text-center">Apply Now</button>
            </form>
        </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/phosphor-icons.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/leaflet.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>