-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2025 at 12:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `freelancer`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `avatar_path` varchar(100) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `salary` decimal(10,2) NOT NULL,
  `salary_type` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `languague` text NOT NULL,
  `categories` text NOT NULL,
  `tools` text NOT NULL,
  `description` text NOT NULL,
  `specialized` varchar(255) NOT NULL,
  `academy` varchar(255) NOT NULL,
  `edu_from_date` date NOT NULL,
  `edu_to_date` date NOT NULL,
  `edu_description` text NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `exp_from_date` date NOT NULL,
  `exp_to_date` date NOT NULL,
  `exp_description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `user_id`, `avatar_path`, `full_name`, `dob`, `phone`, `email`, `gender`, `age`, `salary`, `salary_type`, `experience`, `languague`, `categories`, `tools`, `description`, `specialized`, `academy`, `edu_from_date`, `edu_to_date`, `edu_description`, `job_title`, `company`, `exp_from_date`, `exp_to_date`, `exp_description`, `created_at`) VALUES
(1, 0, '', 'Muhammad Adnan', '2025-05-14', '03287211653', 'madnan5790789@gmail.com', 'Male', 22, 10000.00, 'Month', '2 year', '', 'web developer', 'Html', 'kljhcvlhaspdcioqa', 'web development', '', '2025-05-15', '2025-05-30', '', 'Web development', 'Master Fare Pvt Ltd', '2025-01-15', '2025-05-13', 'lkdhc;voasidh;vqsdi', '2025-05-22 10:39:21'),
(2, 0, '', 'Muhammad Adnan', '2025-05-15', '03287211653', 'madnan5790789@gmail.com', 'Male', 22, 10000.00, 'Month', '2 year', '', 'web developer', 'Html', 'lkdocdsDC', 'web development', '', '2025-05-13', '2025-05-14', '', 'Web development', 'Master Fare Pvt Ltd', '2025-05-14', '2025-05-14', 'knolcsdkc', '2025-05-22 11:41:10'),
(3, 0, '', 'Muhammad Adnan', '2025-05-15', '03287211653', 'madnan5790789@gmail.com', 'Male', 22, 10000.00, 'Month', '2 year', '', 'web developer', 'Html', 'lkdocdsDC', 'web development', '', '2025-05-13', '2025-05-14', '', 'Web development', 'Master Fare Pvt Ltd', '2025-05-14', '2025-05-14', 'knolcsdkc', '2025-05-22 11:46:09'),
(4, 0, '', 'Muhammad Adnan', '2025-05-14', '03287211653', 'madnan5790789@gmail.com', 'Male', 22, 10000.00, 'Month', '2 year', '', 'web developer', 'Html', 'kvhjlhkglhvl', 'web development', '', '2025-05-15', '2025-05-20', '', 'Web development', 'Master Fare Pvt Ltd', '2025-05-08', '2025-05-13', 'jhcljhckchvkjvk', '2025-05-22 13:03:15'),
(5, 13, '', 'Muhammad Ahmad', '2025-05-15', '03184948614', 'madnan5790789@gmail.com', 'Male', 22, 10000.00, 'Month', '2 year', 'english', 'web developer', 'Html,css, javascript,php, react, mongoDB,SQL', 'Hi, I am a front-end website designer. If you need any kind of Figma to HTML, PSD to HTML, Xd to HTML, Sketch to HTML, inVision to HTML, Zeplin to HTML, or anything to HTML CSS website design you can hire me because I professionally work with HTML CSS, bootstrap, tailwind CSS, jQuery, and JavaScript, with all browser – responsive website designs.\r\n\r\nI have 3+ years of experience creating HTML CSS web pages with fully responsive website design. You can give me any kind of design and I will create the page exactly as you need the design.', 'web development', 'ict', '2025-05-06', '2025-05-27', 'Hi, I am a front-end website designer. If you need any kind of Figma to HTML, PSD to HTML, Xd to HTML, Sketch to HTML, inVision to HTML, Zeplin to HTML, or anything to HTML CSS website design you can hire me because I professionally work with HTML CSS, bootstrap, tailwind CSS, jQuery, and JavaScript, with all browser – responsive website designs.\r\n\r\nI have 3+ years of experience creating HTML CSS web pages with fully responsive website design. You can give me any kind of design and I will create the page exactly as you need the design.', 'Web development', 'Master Fare Pvt Ltd', '2025-05-16', '2025-05-15', 'Hi, I am a front-end website designer. If you need any kind of Figma to HTML, PSD to HTML, Xd to HTML, Sketch to HTML, inVision to HTML, Zeplin to HTML, or anything to HTML CSS website design you can hire me because I professionally work with HTML CSS, bootstrap, tailwind CSS, jQuery, and JavaScript, with all browser – responsive website designs.\r\n\r\nI have 3+ years of experience creating HTML CSS web pages with fully responsive website design. You can give me any kind of design and I will create the page exactly as you need the design.', '2025-05-22 13:25:40'),
(6, 15, '', 'Waseem Ashraf', '2025-05-02', '030012123333', 'waseem@gmail.com', 'Male', 23, 10000.00, 'Month', '2 year', 'English', 'web developer', 'Html, css,', 'Hi, I am a front-end website designer. If you need any kind of Figma to HTML, PSD to HTML, Xd to HTML, Sketch to HTML, inVision to HTML, Zeplin to HTML, or anything to HTML CSS website design you can hire me because I professionally work with HTML CSS, bootstrap, tailwind CSS, jQuery, and JavaScript, with all browser – responsive website designs.\r\n\r\nI have 3+ years of experience creating HTML CSS web pages with fully responsive website design. You can give me any kind of design and I will create the page exactly as you need the design.', 'web development', 'ict', '2025-05-15', '2025-05-14', '', 'Web development', 'Master Fare Pvt Ltd', '2025-05-01', '2025-05-16', 'Hi, I am a front-end website designer. If you need any kind of Figma to HTML, PSD to HTML, Xd to HTML, Sketch to HTML, inVision to HTML, Zeplin to HTML, or anything to HTML CSS website design you can hire me because I professionally work with HTML CSS, bootstrap, tailwind CSS, jQuery, and JavaScript, with all browser – responsive website designs.\r\n\r\nI have 3+ years of experience creating HTML CSS web pages with fully responsive website design. You can give me any kind of design and I will create the page exactly as you need the design.', '2025-05-22 14:38:22');

-- --------------------------------------------------------

--
-- Table structure for table `employers`
--

CREATE TABLE `employers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `avatar_path` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `founded` varchar(100) NOT NULL,
  `company_size` varchar(100) NOT NULL,
  `category` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employers`
--

INSERT INTO `employers` (`id`, `user_id`, `name`, `avatar_path`, `email`, `phone`, `website`, `founded`, `company_size`, `category`, `video_url`, `description`, `address`, `created_at`) VALUES
(1, 13, 'Muhammad Adnan', 'uploads/1748165220_cv-.png', 'madnan5790789@gmail.com', '03184948614', '', '2025', 'Master Fare Pvt Ltd', '', 'save_employer.php', 'Motivated and adaptable individual with a strong foundation in technology and a keen interest in customer service. Known for excellent verbal and written communication skills, a calm demeanor, and the ability to handle high-pressure situations with professionalism. Passionate about helping customers, solving problems, and ensuring a smooth service experience.\r\nQuick to learn new tools and procedures, with a strong work ethic and a commitment to delivering quality support. Comfortable with both phone and written communication in English and Urdu. Seeking an opportunity in a reputable call center to begin a meaningful career in customer care while bringing added value to the team through technical knowledge and interpersonal skills.', 'Chenab Boys Hostel G1 Phase Ahbab Society Lahore , Pakistan', '2025-05-25 09:27:00');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `email`, `password`) VALUES
(13, 'madnan5790789@gmail.com', '$2y$10$o.8MUg.Kd/jDcw2qqmrckO9wf9dplPCafVqPB1bAncocIaU7gfGD2'),
(14, 'mahmad4948614@gmail.com', '$2y$10$bagafp52rkxGlFSTvvr7SeUkoB4VuGR1qI0O2nN5Mpy/YmiFPVrdu'),
(15, 'waseem@gmail.com', '$2y$10$2b5tRH77UFPo7DvkDtA2.Od9czK90lfFZuFBN3p4jv4CaNqIE.qFC');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `title-link` varchar(255) NOT NULL,
  `employe_name` varchar(255) NOT NULL,
  `start_price` varchar(50) NOT NULL,
  `description_1` text NOT NULL,
  `description_2` text NOT NULL,
  `my_services` varchar(255) NOT NULL,
  `image_2` varchar(255) NOT NULL,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `image`, `title`, `title-link`, `employe_name`, `start_price`, `description_1`, `description_2`, `my_services`, `image_2`, `status`) VALUES
(1, '1.webp', 'Professional seo services to boost your website\'s visibility.', 'services-detail', 'Floyd Miles', '75', 'Hi, I am a front-end website designer. If you need any kind of Figma to HTML, PSD to HTML, Xd to HTML, Sketch to HTML, inVision to HTML, Zeplin to HTML, or anything to HTML CSS website design you can hire me because I professionally work with HTML CSS, bootstrap, tailwind CSS, jQuery, and JavaScript, with all browser – responsive website designs.', 'I have 3+ years of experience creating HTML CSS web pages with fully responsive website design. You can give me any kind of design and I will create the page exactly as you need the design.', 'Figma to HTML, PSD to HTML, XD to HTML, AI to HTML, PDF to HTML, Sketch to HTML', '2.webp', '1'),
(2, '2.webp', 'I will create stunning logo designs for your business', 'services-detail', 'Cameron', '80', 'Hi, I am a front-end website designer. If you need any kind of Figma to HTML, PSD to HTML, Xd to HTML, Sketch to HTML, inVision to HTML, Zeplin to HTML, or anything to HTML CSS website design you can hire me because I professionally work with HTML CSS, bootstrap, tailwind CSS, jQuery, and JavaScript, with all browser – responsive website designs.', 'I have 3+ years of experience creating HTML CSS web pages with fully responsive website design. You can give me any kind of design and I will create the page exactly as you need the design.', 'Figma to HTML, PSD to HTML, XD to HTML, AI to HTML, PDF to HTML, Sketch to HTML', '3.webp', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employers`
--
ALTER TABLE `employers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employers`
--
ALTER TABLE `employers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
