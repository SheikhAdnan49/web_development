<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="FreelanHub - Job Board & Freelance Marketplace" />
    <title>FreelanHub - Job Board & Freelance Marketplace</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/css/leaflet.css" />
    <link rel="stylesheet" href="assets/css/slick.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="dist/output-tailwind.css" />
    <link rel="stylesheet" href="dist/output-scss.css" />
</head>

<body class="lg:overflow-unset">
    <!-- Header -->
    <?php include('header.php'); ?>
    <!-- end -->

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="breadcrumb_inner sm:pt-20 pt-16">
            <div class="content relative w-full h-full">
                <div class="breadcrumb_bg absolute top-0 left-0 w-full h-full">
                    <img src="assets/images/components/breadcrumb_candidate.webp" alt="breadcrumb_candidate" class="w-full h-full object-cover" />
                </div>
                <div class="container relative h-full lg:py-20 sm:py-14 py-10">
                    <div class="breadcrumb_content flex flex-col items-start justify-center xl:w-[1000px] lg:w-[848px] md:w-5/6 w-full h-full">
                        <div class="list_breadcrumb flex items-center gap-2 animate animate_top" style="--i: 1">
                            <a href="index" class="caption1 text-white">Home</a>
                            <span class="caption1 text-white opacity-40">/</span>
                            <span class="caption1 text-white">Pages</span>
                            <span class="caption1 text-white opacity-40">/</span>
                            <span class="caption1 text-white opacity-60">FAQs</span>
                        </div>
                        <h3 class="heading3 text-white mt-2 animate animate_top" style="--i: 2">Frequently Asked Questions</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQs -->
    <section class="faqs lg:py-20 sm:py-14 py-10">
        <div class="container flex max-lg:flex-col justify-between gap-15 gap-y-10">
            <div class="content w-full">
                <div class="faqs_section">
                    <h4 class="heading4">Support Questions</h4>
                    <div class="list_faqs flex flex-col w-full mt-5">
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">How do I post a job or find a freelancer?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">To post a job or find a freelancer, join platforms like Upwork or Fiverr. Create a detailed job post or search for freelancers by expertise. Review profiles, ratings, and portfolios. Once you find the right freelancer, discuss requirements clearly and hire.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">Is there a fee for using your services?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">Yes, most platforms charge a fee for their services. Clients may pay a percentage of the project cost as a service fee, while freelancers are charged a commission on their earnings. Fees vary by platform and plan, so review the pricing details before starting.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">Can I request advice or support from your team?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">Yes, most platforms offer customer support and advice through live chat, email, or help centers. You can seek guidance on using features, resolving issues, or improving project outcomes. Check the platform’s support section for resources and contact options.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">How do I pay for the freelancers or businesses I hire?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">You pay freelancers through the platform using secure methods like credit cards, PayPal, or bank transfers. Funds are held in escrow until project milestones are met or the work is completed. Once satisfied, you release payment to the freelancer.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">How can I ensure that I receive quality services?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">To ensure quality services, clearly outline your project requirements and expectations. Review freelancer profiles, portfolios, and reviews before hiring. Use milestone payments to track progress and request updates regularly. Communicate openly and provide feedback throughout the project.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faqs_section lg:mt-15 sm:mt-12 mt-8">
                    <h4 class="heading4">Services Questions</h4>
                    <div class="list_faqs flex flex-col w-full mt-5">
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">What types of services are offered on FreelanHub?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">FreelanHub offers a wide range of services, including web development, graphic design, content writing, digital marketing, video editing, translation, and more. Freelancers with various skills and expertise are available to help with projects across different industries.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">Are there specific categories or industries that FreelanHub specializes in?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">FreelanHub specializes in categories like web development, graphic design, digital marketing, content writing, mobile app development, and IT support. It caters to industries such as technology, e-commerce, entertainment, healthcare, and finance, offering specialized services for each.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">How do I browse and explore the available services on the platform?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">To browse and explore available services on FreelanHub, use the search bar or navigate through categories listed on the platform. Filter results based on skills, ratings, pricing, or project types. You can also view freelancer profiles and portfolios to find services that meet your specific needs.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">Can I request custom services that are not listed on the platform?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">Yes, you can request custom services on FreelanHub. If you don’t find a specific service listed, you can post a custom job or reach out to freelancers directly, detailing your requirements. Freelancers can then propose solutions tailored to your needs.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">Tools available to help me find the right service for my needs?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">FreelanHub offers various tools to help you find the right service, including search filters by skill, rating, price, and location. You can also view freelancer portfolios, reviews, and past work to assess their expertise. Additionally, the platform offers job posting features to attract relevant freelancers based on your project needs.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faqs_section lg:mt-15 sm:mt-12 mt-8">
                    <h4 class="heading4">Refund Questions</h4>
                    <div class="list_faqs flex flex-col w-full mt-5">
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">What is the refund policy for services purchased on FreelanHub?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">FreelanHub’s refund policy typically depends on the project’s terms and agreement with the freelancer. If you’re dissatisfied with the work, you can request revisions or open a dispute. Refunds are issued based on the platform's resolution process, which may involve mediating between the client and freelancer. Always review the platform’s terms before purchasing.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">Are there specific criteria that must be met to qualify for a refund?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">To qualify for a refund on FreelanHub, certain criteria must be met, such as project non-delivery, incomplete work, or significant discrepancies from the agreed-upon terms. You may need to provide evidence or communicate with the freelancer to resolve issues. Refund eligibility is determined based on the platform’s dispute resolution process.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">How long does it take to process a refund request?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">The processing time for a refund request on FreelanHub can vary, typically ranging from a few days to a week. The platform may require time to review the dispute, assess the evidence, and communicate with both parties. You will be notified once the request has been processed and a decision made.</p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">Can I cancel a service and receive a refund if I'm not satisfied with the results?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">Yes, you can cancel a service and request a refund if you're dissatisfied, subject to platform criteria. A dispute may be initiated if issues remain unresolved./p>
                            </div>
                        </div>
                        <div class="faq_item py-5 border-b border-line cursor-pointer">
                            <div class="heading flex items-center justify-between gap-2">
                                <strong class="title text-title">Are there any fees or deductions associated with refund requests?</strong>
                                <span class="icon_arrow ph-bold ph-caret-down text-2xl duration-[400ms]"></span>
                            </div>
                            <div class="answer mt-3">
                                <p class="body2 text-secondary">Refund requests on FreelanHub may incur fees or deductions, depending on the platform’s policies. These could include transaction fees or service charges, which are typically outlined in the terms and conditions.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form_area lg:sticky lg:top-24 flex-shrink-0 lg:w-[380px] w-full h-fit p-6 rounded-xl bg-white shadow-lg duration-300">
                <h4 class="heading4">Ask Your Question</h4>
                <p class="text-secondary mt-2">Ask Anything, We're Here to Help</p>
                <form class="form flex flex-col gap-5 mt-4">
                    <div class="name">
                        <label for="username">Name</label>
                        <input class="w-full mt-2 px-4 py-3 border-line rounded-lg" id="username" type="text" placeholder="Your Name" required />
                    </div>
                    <div class="mail">
                        <label for="email">Email</label>
                        <input class="w-full mt-2 px-4 py-3 border-line rounded-lg" id="email" type="email" placeholder="Your Email" required />
                    </div>
                    <div class="message">
                        <label for="message">Message</label>
                        <textarea class="border w-full mt-2 px-4 py-3 border-line rounded-lg" id="message" name="message" rows="3" placeholder="Message content..." required></textarea>
                    </div>
                    <button class="button-main w-full text-center mt-1">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Scroll to top -->
    <button class="scroll-to-top-btn"><span class="ph-bold ph-caret-up"></span></button>

    <!-- footer start  -->
    <?php include('footer.php'); ?>

    <!-- end  -->

    <!-- Menu mobile -->
    

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/phosphor-icons.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/leaflet.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>