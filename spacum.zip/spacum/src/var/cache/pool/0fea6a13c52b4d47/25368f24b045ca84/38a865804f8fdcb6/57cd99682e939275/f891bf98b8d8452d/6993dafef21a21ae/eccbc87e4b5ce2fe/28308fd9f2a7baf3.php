<?php 
/* Cachekey: cache/stash_default/parsedmenu/3/ */
/* Type: array */
/* Expiration: 2025-04-08T16:37:09+06:00 */



$loaded = true;
$expiration = 1744108629;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTo0OntpOjU3O2E6Njp7czo5OiJwYXJlbnRfaWQiO2k6MDtzOjEwOiJpdGVtX2xhYmVsIjtzOjE0OiJQcml2YWN5IFBvbGljeSI7czo4OiJpdGVtX3VybCI7czoyMToiL3BhZ2VzL3ByaXZhY3ktcG9saWN5IjtzOjc6Iml0ZW1faWQiO2k6NTc7czoxMDoiaXRlbV9jbGFzcyI7czowOiIiO3M6OToiaXRlbV9pY29uIjtzOjA6IiI7fWk6NTY7YTo2OntzOjk6InBhcmVudF9pZCI7aTowO3M6MTA6Iml0ZW1fbGFiZWwiO3M6MTA6IkNvbnRhY3QgVXMiO3M6ODoiaXRlbV91cmwiO3M6MTc6Ii9wYWdlcy9jb250YWN0LXVzIjtzOjc6Iml0ZW1faWQiO2k6NTY7czoxMDoiaXRlbV9jbGFzcyI7czowOiIiO3M6OToiaXRlbV9pY29uIjtzOjA6IiI7fWk6NTU7YTo2OntzOjk6InBhcmVudF9pZCI7aTowO3M6MTA6Iml0ZW1fbGFiZWwiO3M6ODoiQWJvdXQgVXMiO3M6ODoiaXRlbV91cmwiO3M6MTU6Ii9wYWdlcy9hYm91dC11cyI7czo3OiJpdGVtX2lkIjtpOjU1O3M6MTA6Iml0ZW1fY2xhc3MiO3M6MDoiIjtzOjk6Iml0ZW1faWNvbiI7czowOiIiO31pOjU4O2E6Njp7czo5OiJwYXJlbnRfaWQiO2k6MDtzOjEwOiJpdGVtX2xhYmVsIjtzOjE2OiJUZXJtcyBvZiBTZXJ2aWNlIjtzOjg6Iml0ZW1fdXJsIjtzOjIzOiIvcGFnZXMvdGVybXMtb2Ytc2VydmljZSI7czo3OiJpdGVtX2lkIjtpOjU4O3M6MTA6Iml0ZW1fY2xhc3MiO3M6MDoiIjtzOjk6Iml0ZW1faWNvbiI7czowOiIiO319'));

/* Child Type: integer */
$data['createdOn'] = 1744023105;
