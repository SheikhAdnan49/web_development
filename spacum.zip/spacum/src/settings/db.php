<?php
/**
 * Put your database details here after you've imported the SQL file
 *
 * @return array
 */

// Database host.
$db['dbhost'] = 'localhost';

// Name of your database
$db['dbname'] = 'spacum';

// Database Username
$db['username'] = 'root';

// Database password
$db['password'] = '';

// Database port, 3306 in most cases
$db['dbport'] = '3306';


// DON'T CHANGE BELOW THIS
$db['prefix'] = 'based_';

return $db;
