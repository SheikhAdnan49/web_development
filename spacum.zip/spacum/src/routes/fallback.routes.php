<?php
/**
 * This file contains routes that are ambigious, or usually an wildcard fallback
 * That's why they are loaded at the very end, so we don't waste much time parsing through them
 */
