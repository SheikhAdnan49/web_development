// Shared history logic to be used in both home.php and header.php
function storeHistory(query, link, forceStore = false) {
    if (!query || !link) return console.warn("⚠ Invalid history data:", { query, link });

    let history = JSON.parse(localStorage.getItem("searchHistory")) || [];

    // Check for duplicates based on link
    const isDuplicate = history.some(entry => entry.link === link);
    if (isDuplicate && !forceStore) {
        console.log("🔄 Duplicate detected, not storing:", { query, link });
        return;
    }

    history.unshift({ query, link, timestamp: new Date().toLocaleString() });
    localStorage.setItem("searchHistory", JSON.stringify(history));
    console.log("✅ History Stored:", { query, link });
}
