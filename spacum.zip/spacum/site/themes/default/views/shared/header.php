<?php
/**
 * Header Template
 *
 * This template contains the global header of the theme. Mainly the navbar
 */

defined('SPARKIN') or die('xD');
?>
<div id="site-navbar" class="site-navbar">
    <div class="searchbar">
        <div class="container search-container">
            <div class="row">
                <div class="mr-2 d-flex align-items-center searchbar-logo-wrap">
                    <a href="<?php echo e_attr(url_for('site.home')); ?>" class="sp-link">
                        <img src="<?php echo e_attr($t['search_logo_url']); ?>" alt="<?php echo e_attr(get_option('site_name')); ?>" class="search-logo">
                    </a>
                </div>
                <div class="col-md-6 mt-sm-0 mt-4">
                    <form method="GET" action="<?php echo e_attr(url_for('site.search')); ?>" id="headerSearchForm" data-ajax-form="true" data-before-callback="preventEmptySubmit">
                        <input type="hidden" name="engine" value="<?php echo e_attr($t['current_engine_id'] ? $t['current_engine_id'] : $t['default_engine']); ?>" id="engine">
                        <div class="form-group searchbox-group searchbar-group">
                            <input type="text" class="form-control search-input" name="q" data-autocomplete="true" autocorrect="off" autocapitalize="off" autocomplete="off" spellcheck="false" value="<?php echo e_attr($t['search_query']); ?>" data-search-input="true">
                            <button type="submit" class="has-spinner search-btn right-0"><span class="btn-text"><?php echo svg_icon('search', 'svg-md'); ?></span>
                             <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        const searchForm = document.getElementById("searchForm");
        const searchInput = document.getElementById("home-search-input");
        const historyButton = document.getElementById("historyButton");
        const historyPopup = document.getElementById("historyPopup");
        const historyList = document.getElementById("historyList");
        const closeHistoryBtn = document.getElementById("closeHistory");
        const clearHistoryBtn = document.getElementById("clearHistory");
        const homeLogo = document.querySelector(".sp-link"); // Logo Click Detection

        function updateHistoryPopup() {
            let history = JSON.parse(localStorage.getItem("searchHistory")) || [];
            historyList.innerHTML = history.length
                ? history.map(h => `<li class="list-group-item"><a href="${h.link}" target="_blank">${h.query} - ${h.timestamp}</a></li>`).join("")
                : `<li class="list-group-item text-center">No history available</li>`;
        }

        function openHistoryPopup() {
            updateHistoryPopup();
            historyPopup.classList.add("show");
        }

        function closeHistoryPopup() {
            historyPopup.classList.remove("show");
        }

        if (searchForm) {
            searchForm.addEventListener("submit", function (event) {
                const query = searchInput.value.trim();
                if (query) {
                    const searchURL = this.action + "?q=" + encodeURIComponent(query);
                    let history = JSON.parse(localStorage.getItem("searchHistory")) || [];
                    history.unshift({ query, link: searchURL, timestamp: new Date().toLocaleString() });
                    localStorage.setItem("searchHistory", JSON.stringify(history));
                }
            });
        }

        if (historyButton) {
            historyButton.addEventListener("click", function () {
                openHistoryPopup();
            });
        }

        if (closeHistoryBtn) {
            closeHistoryBtn.addEventListener("click", function () {
                closeHistoryPopup();
            });
        }

        if (clearHistoryBtn) {
            clearHistoryBtn.addEventListener("click", function () {
                localStorage.removeItem("searchHistory");
                updateHistoryPopup();
            });
        }

        if (homeLogo) {
            homeLogo.addEventListener("click", function (event) {
                event.preventDefault();
                window.location.href = homeLogo.href;
            });
        }

        document.addEventListener("click", function (event) {
            const link = event.target.closest("a");

            if (link && link.href && !link.href.startsWith(window.location.origin)) {
                event.preventDefault();
                const externalURL = link.href;

                if (typeof Spacum !== 'undefined' && typeof Spacum.open === 'function') {
                    Spacum.open(externalURL);
                    console.log("✅ Opening link in Spacum:", externalURL);
                } else {
                    console.warn("⚠ Spacum function not found! Opening link in the same Spacum browser.");
                    window.location.assign(externalURL); // Open link in the same Spacum browser
                }
            }
        });

        // Initial update of history popup
        updateHistoryPopup();
    });
</script>