<footer class="main-footer footer bg-light  py-4" style="background:rgb(255, 195, 255); color: black;">
    <div class="container">
        <div class="row">
            <!-- Learn More -->
            <div class="col-md-3">
                <hr>
                <h6>LEARN MORE</h6>
                <ul class="list-unstyled">
                    <li><a href="#">About Spacum</a></li>
                    <li><a href="#">About Our Browser</a></li>
                    <li><a href="#">What's New</a></li>
                    <li><a href="#">Compare Privacy</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Newsletter</a></li>
                </ul>
            </div>

            <!-- Navigation Menu -->
            <div class="col-md-3">
                <hr>
                <h6>Other Resources</h6>
                <ul class="list-unstyled text-small">
                    <?php
                    echo render_nav_menu(
                        'footer-nav',
                        [
                            'no_container' => true,
                            'menu_class' => 'list-unstyled text-small',
                            'link_class' => 'nav-link footer-link',
                            'fallback_text' => __('no-menu-set', _T)
                        ]
                    );
                    ?>
                </ul>
            </div>

            <!-- About Spacum -->
            <div class="col-md-6">
                <hr>
                <h6>ABOUT SPACUM</h6>
                <p>
                    Spacum is the independent Internet privacy company for anyone who's tired of being tracked online and wants an easy solution. 
                    Unlike Chrome and other browsers, our free, go-to browser comes with over a dozen powerful privacy protections built-in, including 
                    our search engine that replaces Google and doesn’t track your search history. The Spacum browser’s uniquely comprehensive 
                    privacy protections are used by millions of people to protect their everyday online activities, from searching to browsing, emailing, 
                    and more. Available for download on 
                    <a href="#">Mac</a>, <a href="#">Windows</a>, <a href="#">iOS</a>, and <a href="#">Android</a>.
                </p>
            </div>
        </div>

        <!-- Bottom Section -->
        <div class="row align-items-center mt-3">
            <!-- Right: Copyright Text -->
            <div class="col-md-12 text-center">
                <small class="text-muted">
                    <?php echo __('footer-copyright', _T, ['year' => date('Y'), 'sitename' => get_option('site_name')]); ?>
                </small>
            </div>
        </div>
    </div>
</footer>

<!-- Footer Styling -->
<style>
    .footer {
        background: linear-gradient(to right,rgb(255, 243, 244), #FFFFFF) !important; 
        color: black !important;
        font-size: 14px;
    }
    .footer h6 {
        font-weight: bold;
        font-size: 14px;
        text-transform: uppercase;
        margin-bottom: 10px;
    }
    .footer a {
        color: black !important;
        text-decoration: none;
    }
    .footer a:hover {
        text-decoration: underline;
    }
    .footer small {
        color: black !important;
    }
</style>
