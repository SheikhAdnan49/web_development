<?php

/**
 * Template for the homepage
 *
 */
defined('SPARKIN') or die('xD');
?>

<?php insert('shared/offcanvas_menu.php'); ?>
<!-- Dimmer for dimming the background when searchbox is focused -->
<!-- Include Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"> -->
<link rel="stylesheet" href="site\assets\css\style.css">


<div id="dimmer" class="dimmer"></div>

<nav class="navbar navbar-expand-sm navbar-expand-xm bg-white justify-content-center">
    <!-- Logo Section -->
    <a href="<?php e_attr(url_for('site.home')); ?>" id="homeLogo" class="sp-link d-inline-flex align-items-center mt-0 mb-3 logo">
        <img src="<?php echo e_attr($t['logo_url']); ?>" alt="<?php echo e_attr(get_option('site_name')); ?>" class="home-logo">
    </a>

    <!-- Centered and Responsive Search Bar -->
    <form method="GET"
        action="<?php echo e_attr(url_for('site.search')); ?>"
        id="searchForm"
        data-ajax-form="true"
        data-before-callback="preventEmptySubmit"
        class="d-flex w-100">

        <!-- Hidden Engine Input -->
        <input type="hidden" name="engine" value="<?php echo e_attr($t['default_engine']); ?>" id="engine">

        <!-- Search Input and Button -->
        <div class="form-group searchbox-group search w-50">
            <input type="text"
                class="form-control search-input"
                name="q"
                data-autocomplete="true"
                autocomplete="off"
                spellcheck="false"
                autocorrect="off"
                id="home-search-input">

            <button type="submit" class="has-spinner search-btn right-0">
                <span class="btn-text search-button">
                    <?php echo svg_icon('search', 'svg-md'); ?>
                </span>
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            </button>
        </div>
    </form>


    <!-- Navbar Right Icons -->
    <ul class="navbar-nav ms-auto menuBar">
        <li class="nav-item">
            <a href="javascript:void(0);" id="historyButton" class="nav-link d-flex align-items-center">
                <i class="fas fa-history me-1"></i> <span>History</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="javascript:void(0);" data-target="#offcanvas" data-toggle="navdrawer" class="nav-link">
                <?php echo svg_icon('menu', 'svg-md'); ?>
            </a>
        </li>
    </ul>
</nav>

<!-- Custom Popup for History -->
<div id="historyPopup" class="history-popup">
    <div class="history-popup-content">
        <h5>Search History</h5>
        <ul id="historyList" class="list-group">
            <li class="list-group-item text-center">No history available</li>
        </ul>
        <div class="popup-buttons">
            <button id="clearHistory" class="btn btn-danger">Clear History</button>
            <button id="closeHistory" class="btn btn-secondary">Close</button>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        initializeApp();
        displaySearchHistory(); // Load history when page loads
    });


    document.addEventListener("DOMContentLoaded", function() {
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        $('[data-bs-toggle="tooltip"]').each(function() {
            if (!$(this).data('bs.tooltip')) {
                $(this).tooltip();
            }
        });
    });

    function initializeApp() {
        attachHistoryButtonEvent();
        setupSearchHistory();
        preserveHistoryPopupState();
        setupExternalLinkTracking();
        setupHomeLogoReload();
    }

    function setupExternalLinkTracking() {
        // Example: Track all external links clicked
        document.querySelectorAll('a').forEach(link => {
            if (link.hostname !== window.location.hostname) {
                link.addEventListener('click', function() {
                    console.log('External link clicked:', link.href);
                    // Optionally, send this data to your analytics or log it
                });
            }
        });
    }

    // ✅ Attach event to history button (open popup without refresh)
    function attachHistoryButtonEvent() {
        const historyButton = document.getElementById("historyButton");
        if (!historyButton) return;

        historyButton.addEventListener("click", function(event) {
            event.preventDefault();
            openHistoryPopup();
        });
    }

    // ✅ Open and close history popup
    function openHistoryPopup() {
        updateHistoryPopup();
        document.getElementById("historyPopup").classList.add("show");
        sessionStorage.setItem("historyVisible", "true");
    }

    function closeHistoryPopup() {
        document.getElementById("historyPopup").classList.remove("show");
        sessionStorage.removeItem("historyVisible");
    }

    // ✅ Preserve history popup visibility after reload
    function preserveHistoryPopupState() {
        if (sessionStorage.getItem("historyVisible") === "true") {
            openHistoryPopup();
        }
    }

    // ✅ Update history popup with stored searches and external links (latest first)
    function updateHistoryPopup() {
        const historyList = document.getElementById("historyList");
        let history = JSON.parse(localStorage.getItem("searchHistory")) || [];

        historyList.innerHTML = history.length ?
            history
            .slice()
            .reverse() // 🔥 Show latest searches first
            .map(h => `<li class="list-group-item"><a href="${h.link}" target="_blank">${h.query} - ${h.timestamp}</a></li>`)
            .join("") :
            `<li class="list-group-item text-center">No history available</li>`;
    }

    
    function displayRecentLinks() {
    let container = document.getElementById("search-history");
    let recentLinks = JSON.parse(localStorage.getItem("recentLinks")) || [];

    container.innerHTML = recentLinks.length
        ? recentLinks
              .map(link => `<div class="history-item">
                    <a href="${link.url}" target="_blank">
                        <img src="${link.favicon}" alt="icon" width="30" height="30">
                    </a>
                </div>`)
              .join("")
        : "<p>No recent searches</p>";
}



document.addEventListener("DOMContentLoaded", function () {
    loadRecentLinks(); // Load recent links on page load
    trackClickedLinks();
});

// Function to track clicks on search result links
function trackClickedLinks() {
    document.body.addEventListener("click", function (event) {
        let link = event.target.closest("a");
        if (link && link.href.startsWith("http")) {
            let url = link.href;
            let favicon = `https://www.google.com/s2/favicons?sz=32&domain_url=${new URL(url).hostname}`;
            storeRecentLink(url, favicon);
        }
    });
}

// Function to store clicked links in localStorage
function storeRecentLink(url, favicon) {
    let recentLinks = JSON.parse(localStorage.getItem("recentLinks")) || [];

    // Prevent duplicates
    if (!recentLinks.some(entry => entry.url === url)) {
        recentLinks.push({ url, favicon });
        localStorage.setItem("recentLinks", JSON.stringify(recentLinks));
    }

    displayRecentLinks(); // Update UI
}

// Function to load and display recent links
function loadRecentLinks() {
    displayRecentLinks();
}



    function setupSearchHistory() {
        const searchForm = document.getElementById("searchForm");
        const searchInput = document.getElementById("home-search-input");
        if (!searchForm || !searchInput) return;

        searchForm.addEventListener("submit", function(event) {
            const query = searchInput.value.trim();
            if (!query) return; // Prevent storing empty searches

            const searchURL = this.action + "?q=" + encodeURIComponent(query);

            // 🔥 Store search query before navigation
            storeHistoryEntry(query, searchURL);

            // 🔥 Update UI after storing history
            displaySearchHistory();

            // 🔥 Save in sessionStorage to restore later if needed
            sessionStorage.setItem("lastSearchQuery", JSON.stringify({
                query,
                searchURL
            }));
        });
    }


    function storeHistoryEntry(query, link) {
        let history = JSON.parse(localStorage.getItem("searchHistory")) || [];

        // 🔥 Ensure the same search query isn't stored multiple times
        const exists = history.some(entry => entry.query === query && entry.link === link);
        if (!exists) {
            history.push({
                query,
                link,
                timestamp: new Date().toLocaleString()
            }); // Maintain proper order
            localStorage.setItem("searchHistory", JSON.stringify(history));

            console.log('History saved:', history); // Debugging line
        }
    }

    // ✅ Ensure the last search query is stored if it wasn't saved before navigation
    function storeUnstoredQuery() {
        const lastSearch = JSON.parse(sessionStorage.getItem("lastSearchQuery"));
        if (lastSearch) {
            storeHistoryEntry(lastSearch.query, lastSearch.searchURL);
            sessionStorage.removeItem("lastSearchQuery"); // Remove after storing
        }
    }

    // ✅ Preserve history after clicking the home logo
    function setupHomeLogoReload() {
        const homeLogo = document.getElementById("homeLogo");
        if (!homeLogo) return;

        homeLogo.addEventListener("click", function(event) {
            event.preventDefault();
            sessionStorage.setItem("reloadHistory", "true");
            window.location.href = homeLogo.href;
        });

        if (sessionStorage.getItem("reloadHistory") === "true") {
            updateHistoryPopup();
            sessionStorage.removeItem("reloadHistory");
        }
    }

    // ✅ Restore query when user navigates back using browser buttons
    window.addEventListener("pageshow", function() {
        storeUnstoredQuery(); // 🔥 Ensure last search is always stored
    });

    // ✅ Event delegation for history popup buttons (close & clear)
    document.body.addEventListener("click", function(event) {
        if (event.target.closest("#historyButton")) {
            openHistoryPopup();
        } else if (event.target.closest("#closeHistory")) {
            closeHistoryPopup();
        } else if (event.target.closest("#clearHistory")) {
            localStorage.removeItem("searchHistory");
            updateHistoryPopup();
        } else if (event.target === document.getElementById("historyPopup")) {
            closeHistoryPopup();
        }
    });
</script>

<style>
    .history-popup {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 9999;
        justify-content: center;
        align-items: center;
    }

    .history-popup.show {
        display: flex;
    }

    .history-popup-content {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        width: 90%;
        text-align: center;
        animation: fadeIn 0.3s ease-in-out;
    }

    .history-popup-content h5 {
        margin-bottom: 15px;
    }

    .history-popup-content ul {
        list-style: none;
        padding: 0;
        max-height: 200px;
        overflow-y: auto;
    }

    .history-popup-content ul li {
        padding: 8px;
        border-bottom: 1px solid #ddd;
    }

    .history-popup-content ul li:last-child {
        border-bottom: none;
    }

    .popup-buttons {
        display: flex;
        justify-content: space-between;
        margin-top: 15px;
    }

    /* Animation */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* .recent-searches {
    margin-top: 20px;
} */

.history-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center; /* Start icons from center */
    align-items: center;
    gap: 10px;
    border-top: 1px solid #ccc;
    padding: 10px;
    background: #fff;
    margin-top: -9px;
    position: relative;
}

/* Ensure new icons are inserted in the center */
.history-item {
    padding: 5px;
    cursor: pointer;
    background-color: #f9f9f9;
    border-radius: 50%; /* Make it circular */
    width: 50px;
    height: 50px;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: all 0.3s ease-in-out;
    position: relative;
}

/* When hovered, slightly enlarge */
.history-item:hover {
    background-color: #f1f1f1;
    transform: scale(1.1);
}

/* Ensures the latest icons appear at the center */
.history-list .history-item:nth-child(odd) {
    order: -1; /* Pushes alternating items to sides */
}

.history-list .history-item:nth-child(even) {
    order: 1; /* Moves even items toward center */
}

</style>
<div class="text-center bg-light">
    <h4 class="text-dark">
        Recent Searches
    </h4>
</div>

<div id="search-history" class=" history-list"></div>



<div class="outer">
    <div class="container home-container" style="margin-top: 90px;">
        <!-- Homepage logo section -->
        <div class="container text-center">
            <h2 class="fw-bold text-dark">
                Switch to Spacum. It’s private and free!
            </h2>

            <div class="container-box d-flex flex-wrap gap-3 justify-content-center">
                <!-- Card 1 -->
                <div class="card p-3">
                    <div class="d-flex justify-content-center" style="height: 134px;">
                        <img src="site/assets/img/set-as-default.d95c3465.svg" alt="" style="width: 150px; height: 100px;">
                    </div>
                    <p id="status" class="fw-semibold text-center">
                        Make Spacum your default search engine.
                    </p>
                    <button class="btn btn-outline-primary w-100"
                        onclick="setAsDefaultSearch()"
                        style="border-color: #007bff; color: #007bff;">
                        Set As Default Search
                    </button>
                </div>

                <!-- Card 2 with Drop-up Dropdown -->
                <div class="card p-3 position-relative" style="overflow: visible;">
                    <span class="best-privacy fw-bold mb-2" style="margin-left:0px;">
                        BEST PRIVACY
                    </span>
                    <div class="d-flex justify-content-center" style="height: 100px;">
                        <img src="site/assets/img/download.svg" alt="" style="width: 150px; height: 100px;">
                    </div>
                    <p class="fw-semibold text-center">
                        Get our free browser for even more privacy.
                    </p>

                    <!-- Drop-up Button and Menu -->
                    <div class="dropdown drop-up" style="overflow: visible;">
                        <button class="btn btn-primary dropdown-toggle w-100"
                            type="button"
                            id="downloadButton"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            style="border-radius: 50px;">
                            Download Browser
                        </button>

                        <ul class="dropdown-menu w-100 shadow-lg rounded-3 border-0"
                            aria-labelledby="downloadButton"
                            style="z-index: 1050;">
                            <!-- <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumInstaller.exe">Windows</a></li> -->
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/Spacum-Setup.exe">Windows</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumMac64.exe">macOS</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr">Android</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="https://apps.apple.com/in/app/spacum/id6475772694">IOS</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/Spacum-linux-x64.zip">Linux</a></li>

                        </ul>
                    </div>
                </div>
            </div>

            <!-- Additional Content -->
            <p class="mt-5 mb-5 text-dark" style="font-weight: 300; color: #383838;">
                Trusted by millions worldwide!
            </p>

            <a href="#" class="d-block text-decoration-none text-dark" style="margin-top: 90px; font-weight: 620;">
                <span class="fw-bold">Learn more</span>
                <br>
                <span>&darr;</span>
            </a>
        </div>
    </div>
    <section class="hero-section mb-5" style="position: relative; z-index: 1;">
        <div class="container">
            <div class="hero-content row align-items-center">
                <!-- Left Side: Content -->
                <div class="hero-text col-lg-6 mb-4 mb-lg-0">
                    <h1>Free. Fast. Private. Get our browser on all your devices.</h1>
                    <p>
                        Search and browse more privately with the Spacum browser.
                        Unlike Chrome and other browsers, we don't track you.
                    </p>

                    <!-- Button for Large Screens (Default Position) -->
                    <div class="dropdown d-none d-lg-block" style="position: relative; z-index: 2;">
                        <button class="btn btn-primary dropdown-toggle w-50" type="button"
                            id="downloadButton" data-bs-toggle="dropdown" aria-expanded="false">
                            Download Spacum Browser
                        </button>
                        <ul class="dropdown-menu w-50 shadow-lg rounded-3 border-0"
                            aria-labelledby="downloadButton" style="position: absolute; z-index: 3;">
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumInstaller.exe">Windows</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumMac64.exe">macOS</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr">Android</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="https://apps.apple.com/in/app/spacum/id6475772694">iOS</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/Spacum-linux-x64.zip">Linux</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Right Side: Image and Button for Medium/Small Screens -->
                <div class="hero-image col-lg-6 position-relative">
                    <img src="site/assets/img/devices-light.png" alt="Spacum Browser" class="img-fluid">

                    <!-- Button for Medium and Small Screens -->
                    <div class="dropdown d-lg-none mt-3 p-5 text-center" style="position: relative; z-index: 2;">
                        <button class="btn btn-primary dropdown-toggle w-25" type="button"
                            id="downloadButtonMobile" data-bs-toggle="dropdown" aria-expanded="false">
                            Download Spacum Browser
                        </button>
                        <ul class="dropdown-menu w-50 shadow-lg rounded-3 border-0"
                            aria-labelledby="downloadButtonMobile" style="position: absolute; z-index: 3;">
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumInstaller.exe">Windows</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumMac64.exe">macOS</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr">Android</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="https://apps.apple.com/in/app/spacum/id6475772694">iOS</a></li>
                            <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/Spacum-linux-x64.zip">Linux</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container mb-5">
        <div class="row text-center browser-links p-4 rounded">
            <!-- Desktop & Mobile Browser -->
            <div class="col-12">
                <h5 class="text-muted mb-3">DESKTOP & MOBILE BROWSER</h5>
                <div class="d-flex flex-wrap justify-content-center gap-5">
                    <!-- MAC Link -->

                    <a href="/site/assets/browsers/SpacumInstaller.exe"
                        class="text-decoration-none text-dark text-center cursor-pointer d-flex flex-column mx-3 my-2">
                        <img src="site/assets/img/macos.61889438.png" alt="Mac"
                            class="icon img-fluid mb-2" style="max-width: 80px;">
                        <p class="mt-2">MAC</p>
                    </a>

                    <!-- iPHONE Link -->
                    <a href="https://apps.apple.com/in/app/spacum/id6475772694"
                        class="text-decoration-none text-dark text-center cursor-pointer d-flex flex-column mx-3 my-2">
                        <img src="site/assets/img/app-store.501fe17a.png" alt="iPhone"
                            class="icon img-fluid mb-2" style="max-width: 80px;">
                        <p class="mt-2">iPHONE</p>
                    </a>

                    <!-- ANDROID Link -->
                    <a href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr"
                        class="text-decoration-none text-dark text-center cursor-pointer d-flex flex-column mx-3 my-2">
                        <img src="site/assets/img/play-store.e5d5ed36.png" alt="Android"
                            class="icon img-fluid mb-2" style="max-width: 80px;">
                        <p class="mt-2">ANDROID</p>
                    </a>

                </div>
            </div>

            <!-- Desktop Browser Extension -->
            <!-- <div class="col-md-6 col-12">
                <h5 class="text-muted mb-3">DESKTOP BROWSER EXTENSION</h5>
                <div class="d-flex justify-content-center gap-3">
                    <div>
                        <img src="site/assets/img/chrome-lg.a4859fb2.png" alt="Chrome" class="icon">
                        <p class="mt-2">CHROME</p>
                    </div>
                    <div>
                        <img src="site/assets/img/firefox-lg.8efad702.png" alt="Firefox" class="icon">
                        <p class="mt-2">FIREFOX</p>
                    </div>
                    <div>
                        <img src="site/assets/img/opera-lg.237c4418.png" alt="Opera" class="icon">
                        <p class="mt-2">OPERA</p>
                    </div>
                </div>
            </div> -->
        </div>
    </div>



    <!-- Comparison Section -->
    <section class="comparison-section" style="margin-top:110px;">
        <div class="container">
            <h2 class="comparison-heading" style="line-height:50px;">See how our<br> browser compares.</h2>
            <p class="comparison-subheading">Switch to the Spacum browser and get more privacy, for free.</p>
            <table class="feature-table">
                <thead>
                    <tr>
                        <th></th>
                        <th>Spacum Browser</th>
                        <th>Google</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Blocks 3rd-party trackers</td>
                        <td><i class="fas fa-check icon tick"></i></td>
                        <td><i class="fas fa-times icon cross"></i></td>
                    </tr>
                    <tr>
                        <td>Searches are private by default</td>
                        <td><i class="fas fa-check icon tick"></i></td>
                        <td><i class="fas fa-times icon cross"></i></td>
                    </tr>
                    <tr>
                        <td>Blocks tracking ads</td>
                        <td><i class="fas fa-check icon tick"></i></td>
                        <td><i class="fas fa-times icon cross"></i></td>
                    </tr>
                    <tr>
                        <td>Blocks cookie pop-ups</td>
                        <td><i class="fas fa-check icon tick"></i></td>
                        <td><i class="fas fa-times icon cross"></i></td>
                    </tr>
                    <tr>
                        <td>Blocks email tracker</td>
                        <td><i class="fas fa-check icon tick"></i></td>
                        <td><i class="fas fa-times icon cross"></i></td>
                    </tr>
                    <tr>
                        <td>Prog: You/Get videos without targeted ads</td>
                        <td><i class="fas fa-check icon tick"></i></td>
                        <td><i class="fas fa-times icon cross"></i></td>
                    </tr>
                    <tr>
                        <td>Items file data you don't want with use button</td>
                        <td><i class="fas fa-check icon tick"></i></td>
                        <td><i class="fas fa-times icon cross"></i></td>
                    </tr>
                    <tr>
                        <td>Global Privacy Centre</td>
                        <td><i class="fas fa-check icon tick"></i></td>
                        <td><i class="fas fa-times icon cross"></i></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

    <!-- Download Button -->
    <!-- Download Button -->
    <div class="text-center mt-0 mb-5">
        <div class="dropdown d-inline-block">
            <button class="btn btn-primary dropdown-toggle" type="button"
                id="downloadButton" data-bs-toggle="dropdown" aria-expanded="false">
                Download Spacum Browser
            </button>

            <!-- Responsive Dropdown Menu -->
            <ul class="dropdown-menu shadow-lg rounded-3 border-0"
                aria-labelledby="downloadButton"
                style="min-width: 285px; max-width: 300px;">
                <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumInstaller.exe">Windows</a></li>
                <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumMac64.exe">macOS</a></li>
                <li><a class="dropdown-item py-2 text-dark" href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr">Android</a></li>
                <li><a class="dropdown-item py-2 text-dark" href="https://apps.apple.com/in/app/spacum/id6475772694">iOS</a></li>
                <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/Spacum-linux-x64.zip">Linux</a></li>
            </ul>
        </div>
    </div>
</div>

</div>

<!-- DOWNLOAD SECTION -->
<div class="comparison-section" style="padding-top:110px;">
    <div class="container" style="background: white"
        id="main-container">

        <div>
            <h2 class="text-center" style="color: black; font-weight: 700; font-size: 2rem">
                Download All Spacum Browsers
            </h2>
        </div>
        <div class="p-4 rounded-4 w-100">
            <div class="m-3 d-flex align-items-center justify-content-between">
                <img src="site/assets/img/logo-for-dark.png" width="90" class="me-3" alt="Spacum">
                <i class="fa-solid fa-xmark minimize-btn ms-auto" id="minimize-btn" style="cursor: pointer; font-size: 1.5rem;"></i>
            </div>

            <div class="list-group rounded-4">
                <!-- Windows -->
                <div class="bb list-group-item d-flex justify-content-between align-items-center flex-column flex-md-row p-2">
                    <div class="spc d-flex align-items-center">
                        <i class="itag fa-brands fa-windows" style="margin-right: 1rem"></i>
                        <span><strong>Spacum Browser</strong> for <span class="text-primary">Windows</span></span>
                    </div>
                    <div class="d-flex flex-column flex-md-row align-items-center">
                        <div class="offline-download text-center me-md-4">
                            <span>Download the offline package:</span>
                            <div>
                                <a href="/site/assets/browsers/SpacumInstaller.exe">64 bit</a> /
                                <a href="/site/assets/browsers/SpacumInstaller32.exe">32 bit</a> /
                                <a href="/site/assets/browsers/SpacumInstallerARM64.exe">ARM</a>
                            </div>
                        </div>
                        <a href="/site/assets/browsers/SpacumInstaller.exe" download class="dow-now btn btn-primary rounded-2 d-flex align-items-center justify-content-center p-4">
                            <!-- <i class="fa-brands fa-windows"></i> -->
                            <span class="p-2">Download now</span>
                        </a>
                    </div>
                </div>

                <!-- Mac -->
                <div class="bb list-group-item d-flex justify-content-between align-items-center flex-column flex-md-row p-2">
                    <div class="spc d-flex align-items-center">
                        <i class="itag fa-brands fa-apple" style="margin-right: 1rem"></i>
                        <span><strong>Spacum Browser</strong> for <span class="text-primary">Mac</span></span>
                    </div>
                    <div class="d-flex flex-column flex-md-row align-items-center">
                        <div class="offline-download text-center me-md-4">
                            <span>Prefer to Install Spacum later?</span>
                            <div>
                                <a href="/site/assets/browsers/SpacumMac64.exe">Download the offline package</a>
                            </div>
                        </div>
                        <a href="/site/assets/browsers/SpacumMac64.exe" download class="btn btn-primary rounded-3 d-flex align-items-center justify-content-center p-4">
                            <!-- <i class="fa-brands fa-apple me-2"></i> -->
                            <span class="p-2">Download now</span>
                        </a>
                    </div>
                </div>

                <!-- Linux -->
                <div class="bb list-group-item d-flex justify-content-between align-items-center flex-column flex-md-row p-2">
                    <div class="spc d-flex align-items-center">
                        <i class="itag fa-brands fa-linux" style="margin-right: 1rem"></i>
                        <span><strong>Spacum Browser</strong> for <span class="text-primary">Linux</span></span>
                    </div>
                    <div class="d-flex flex-column flex-md-row align-items-center">
                        <div class="offline-download text-center me-md-4">
                            <span>Prefer another package?</span>
                            <div>
                                <a href="/site/assets/browsers/Spacum-linux-x64.zip">RPM</a> /
                                <a href="/site/assets/browsers/Spacum-linux-x64.zip">SNAP</a>
                            </div>
                        </div>
                        <a href="/site/assets/browsers/Spacum-linux-x64.zip" download class="btn btn-primary rounded-3 d-flex align-items-center justify-content-center p-4">
                            <!-- <i class="fa-brands fa-linux"></i> -->
                            <span class="p-2">Download now</span>
                        </a>
                    </div>
                </div>

                <!-- Chromebook -->
                <div class="bb list-group-item d-flex justify-content-between align-items-center flex-column flex-md-row p-2">
                    <div class="spc d-flex align-items-center">
                        <i class="itag fa-brands fa-chrome"></i>
                        <span><strong>Spacum Browser</strong> for <span class="text-primary">Chromebook</span></span>
                    </div>
                    <div class="d-flex flex-column flex-md-row align-items-center">
                        <div class="offline-download text-center me-md-4">
                            <span>Don't have Google Play?</span>
                            <div>
                                <a href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr">Download the app here</a>
                            </div>
                        </div>
                        <a href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr" class="store-button-c" target="_blank">
                            <img src="site/assets/img/google-play.png" alt="Google Play">
                        </a>
                    </div>
                </div>

                <!-- Android -->
                <div class="bb list-group-item d-flex justify-content-between align-items-center flex-column flex-md-row p-2">
                    <div class="spc d-flex align-items-center">
                        <i class="itag fa-brands fa-android" style="margin-right: 1rem"></i>
                        <span><strong>Spacum Browser</strong> for <span class="text-primary">Android</span></span>
                    </div>
                    <div class="d-flex flex-column flex-md-row align-items-center">
                        <div class="offline-download text-center me-md-4">
                            <span>Don't have Google Play?</span>
                            <div>
                                <a href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr">Download the app here</a>
                            </div>
                        </div>
                        <a href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr" class="store-button-c" target="_blank">
                            <img src="site/assets/img/google-play.png" alt="Google Play">
                        </a>
                    </div>
                </div>

                <!-- iOS -->
                <div class="list-group-item d-flex justify-content-between align-items-center p-2">
                    <div class="spc d-flex align-items-center">
                        <i class="itag fa-brands fa-apple" style="margin-right: 1rem"></i>
                        <span><strong>Spacum Browser</strong> for <span class="text-primary">iOS</span></span>
                    </div>
                    <a href="https://apps.apple.com/in/app/spacum/id6475772694" class="store-button-c" target="_blank">
                        <img src="site/assets/img/app-store.png" alt="App Store">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Search Protection Section -->
<section class="search-protection-section">
    <div class="container">
        <p style="color:#555;text-align:center" class="mb-4">HOW IT WORKS </p>
        <div class="search-protection-content">
            <!-- Left Side: Text -->
            <div class="search-protection-text">
                <p>SEARCH PROTECTION</p>
                <h2>Search without being <br> tracked.</h2>

                <p>Other search engines track your every search,<br>from where you go to what you <br> We don't track you. Ever.</p>
                <a href="#">Learn more</a>
            </div>
            <!-- Right Side: Images -->
            <div class="search-protection-images">
                <img src="site/assets/img/search-protection-front-light.png" alt="Search Protection Image 1">
                <img src="site/assets/img/search-protection-back-light.png" alt="Search Protection Image 2">
            </div>
        </div>
    </div>
</section>

<section class="web-protection-section">
    <div class="container">
        <div class="web-protection-content">
            <!-- Right Side: Images -->
            <div class="web-protection-images">
                <img src="site/assets/img/web-protection-front-light.png" alt="Search Protection Image 2">
                <img src="site/assets/img/web-protection-back-light.png" alt="Search Protection Image 1">
            </div>
            <!-- Left Side: Text -->
            <div class="web-protection-text">
                <p>WEB TRACKING PROTECTION</p>
                <h2>Stop creepy tracking<br>from Facebook and Google.</h2>
                <p>Spectrum's powerful tracker blocking in our browser and extension stops trackers and creepy ads before they even load, evading hidden data collectors and speeding up websites.</p>
                <a href="#">Learn more</a>
            </div>
        </div>
</section>

<section class="email-protection-section">
    <div class="container">
        <div class="email-protection-content">
            <!-- Left Side: Text -->
            <div class="email-protection-text">
                <p>EMAIL PROTECTION</p>
                <h2>Intercept and remove<br>email trackers.</h2>
                <p>85% of emails sent through Spacum addresses contained hidden email trackers before we stripped them out. Email Protection zaps most trackers and forwards email to your regular inbox so you can read in peace.</p>
                <a href="#">Learn more</a>
            </div>
            <!-- Right Side: Images -->
            <div class="email-protection-images">
                <img src="site/assets/img/email-protection-front-light.png" alt="Email Protection Image 1">
                <img src="site/assets/img/email-protection-back-light.png" alt="Email Protection Image 2">
            </div>
        </div>
    </div>
</section>

<section class="app-protection-section">
    <div class="container">
        <div class="app-protection-content">
            <!-- Right Side: Images -->
            <div class="app-protection-images">
                <img src="site/assets/img/app-protection-front-light.png" alt="Search Protection Image 2">
                <img src="site/assets/img/app-protection-back-light.png" alt="Search Protection Image 1">
            </div>
            <!-- Left Side: Text -->
            <div class="app-protection-text">
                <p>APP TRACKING PROTECTION</p>
                <h2>Block app trackers,<br>day and night.</h2>
                <p>Over 96% of popular free Android apps we tested allow other companies to invade your >privacy, like using your location to map everywhere you go. Stop most of their spying and take back control on Android!</p>
                <a href="#">Learn more</a>
            </div>
        </div>
</section>

<section class="myth-section">
    <div class="container">
        <div class="myth-content">
            <h2>It's a myth that companies need to track you to make money.</h2>
            <p>Spacum has been free to use since day one, and private search ads have kept us profitable for nearly a decade. When you search for "car", we show you a car ad—it's that simple.</p>
            <a href="#">See how we make money</a>
        </div>
    </div>
</section>

<section class="privacy-hero-section">
    <div>
        <h1>Get the same internet,but with more privacy</h1>
    </div>
</section>

<div class="gradient-bg">
    <div class="container">
        <div class="row g-4"> <!-- g-4 adds gap between columns -->
            <!-- First Row - First Column -->
            <div class="col-md-8 col-lg-4 col-sm-8 mb-4"> <!-- mb-4 adds margin at the bottom of the row for spacing between rows -->
                <div class="card-custom mb-4 mt-4 " style="background-color:#F2D2BD">
                    <img src="site/assets/img/widget-big@2x.a260ccf6.png" alt="Search Protection Image 2" class="main-img">
                    <div class="bottom-right">
                        <img src="site/assets/img/download (1).svg" alt="Search Protection Image 2" class="small-img">
                        <span class="widget-text">App Widget</span>
                    </div>
                </div>

                <div class="card-custom p-5" style="color:black;background-color:#F2D2BD">
                    <p style="font-weight:500">Voice Search &nbsp Favorites &nbsp Downloads &nbsp Bookmarks &nbsp Smarter &nbspEncryption</p>
                    <h4 style="font-weight:700">Tracker Blocking</h4>
                    <p style="font-weight:500">Local Search &nbsp !Bang shortCuts &nbsp Application Lock &nbsp Custom themes &nbsp Maps</p>
                </div>
            </div>

            <!-- First Row - Second Column -->
            <div class="col-md-8 col-lg-4 col-sm-8 mb-4 mt-4">
                <div class="custom-card" style="background-color:#F2D2BD">
                    <div class="image-placeholder">
                        <img src="site/assets/img/burn@2x.be0bd36d.png" alt="Search Protection Image 2" class="main-img">
                    </div>
                    <img src="site/assets/img/flame@2x.40e1cfa0.png" alt="Search Protection Image 2" class="second-img">
                    <p class="card-text dark-text">Burn After Reading</p>
                    <p class="card-text">Clear your tabs and browsing data with one tap.</p>
                </div>
            </div>

            <!-- First Row - Third Column -->
            <div class="col-md-8 col-lg-4 col-sm-8 mb-4 mt-4">
                <div class="third-custom-card" style="background-color:#00008A">
                    <div class="third-card-header">
                        <img src="site/assets/img/night@2x.4ca79636.png" alt="Search Protection Image 2" class="second-img">
                        <div class="third-header-text">Dark Mode</div>
                    </div>
                    <div class="third-card-body">
                        <img src="site/assets/img/dark-mode@2x.3e150d01.png" alt="Dark Mode Image" class="third-bottom-img">
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<div style="background: linear-gradient(to bottom, #FF9A9E, #ffc0cb);">
    <div class="container mt-5">
        <div class="trusted-section">

            <div class="text-center">
                <h2>Trusted by millions worldwide!</h2>
                <div class="trusted-stats-container">
                    <div class="trusted-stats">
                        <div>100%</div>
                        <span>Free</span>
                    </div>
                    <div class="trusted-stats">
                        <div>Millions</div>
                        <span>Monthly Searches</span>
                    </div>
                    <div class="trusted-stats">
                        <div>100k</div>
                        <span>Monthly Downloads</span>
                    </div>
                </div>
            </div>




            <div class="download-section" id="download-section">
                <h5 style="color:black;text-align:center;font-weight:550">Get our free browser today</h5>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle p-4 w-75
                        fs-4 fs-md-5 fs-lg-3"
                        type="button"
                        id="downloadButton"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                        style="border-radius: 50px; min-width: 315px;margin-right:22px;font-size: 1.15rem;">
                        Download Spacum Browser
                    </button>
                    <ul class="dropdown-menu w-75 shadow-lg rounded-3 border-0" aria-labelledby="downloadButton">
                        <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumInstaller.exe">Windows</a></li>
                        <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/SpacumMac64.exe">macOS</a></li>
                        <li><a class="dropdown-item py-2 text-dark" href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr">Android</a></li>
                        <li><a class="dropdown-item py-2 text-dark" href="https://apps.apple.com/in/app/spacum/id6475772694">IOS</a></li>
                        <li><a class="dropdown-item py-2 text-dark" href="/site/assets/browsers/Spacum-linux-x64.zip">Linux</a></li>

                    </ul>
                </div>
                <div class="download-buttons">
                    <!-- App Store Button -->
                    <a href="https://apps.apple.com/us/app/spacum/id6475772694" class="store-button" style="text-decoration:none" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-apple"></i>
                        <div>
                            <strong>App Store</strong>
                        </div>
                    </a>

                    <!-- Google Play Button -->
                    <a href="https://play.google.com/store/apps/details?id=com.cfcc.spacum&hl=mr" class="store-button" style="text-decoration:none" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-google-play"></i>
                        <div>
                            <strong>Google Play</strong>
                        </div>
                    </a>
                </div>
                <div class="ratings">
                    <div class="rating">
                        <div class="stars" style="color:black">★★★★★ 4.9</div>
                        <!-- <div class="millions" style="color:black">1.8 million ratings</div> -->
                    </div>
                    <div class="rating">
                        <div class="stars" style="color:black">★★★★★ 4.7</div>
                        <!-- <div class="millions" style="color:black">2.1 million reviews</div> -->
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- Correctly closed the main container here -->
</div> <!-- Correctly closed the main container here -->




<section class="faq-section" style="background: linear-gradient(to bottom, #ffc0cb,rgb(255, 255, 255));">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-5">
                <h2>Still have questions?</h2>
            </div>

            <div class="col-md-12 col-lg-7">
                <div class="faq-item">
                    <div class="faq-question" style="font-weight: bold; background-color: white; ">
                        <h3 style="margin: 0;">What is Spacum?</h3>
                        <span class="arrow">&#9650;</span> <!-- Up arrow -->
                    </div>
                    <p class="answer" style="display: block; font-size: 1rem; line-height: 1.6; color: #555;">
                        Spacum is an independent Internet privacy company that aims to make getting privacy simple and accessible for everyone. Our
                        <a href="#" style="color: #007bff; text-decoration: underline;">free web browser</a> for
                        <a href="#" style="color: #007bff; text-decoration: underline;">iOS</a>,
                        <a href="#" style="color: #007bff; text-decoration: underline;">Android</a>,
                        <a href="#" style="color: #007bff; text-decoration: underline;">Mac</a>, and
                        <a href="#" style="color: #007bff; text-decoration: underline;">Windows</a> lets you search and browse the web, but - unlike Google Search and Chrome - we don't track your searches and browsing history, and we block other companies from trying to tracj you, all by default.
                        <br><a href="#" style="color: #007bff; text-decoration: underline;">Learn More</a>
                    </p>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <h3>How does Spacum protect my privacy?</h3>
                        <span class="arrow">&#9660;</span>
                    </div>
                    <p class="answer">Spacum protects your privacy by blocking trackers and encrypting your data, ensuring that your online activities remain private and secure.</p>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Does Spacum block all trackers on websites I visit?</h3>
                        <span class="arrow">&#9660;</span>
                    </div>
                    <p class="answer">Yes, Spacum blocks most trackers on websites you visit, preventing them from collecting your data.</p>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>How many people use Spacum?</h3>
                        <span class="arrow">&#9660;</span>
                    </div>
                    <p class="answer">Spacum is used by millions of people worldwide who value their privacy and security online.</p>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>How does Spacum make money?</h3>
                        <span class="arrow">&#9660;</span>
                    </div>
                    <p class="answer">Spacum makes money through private search ads and premium features, ensuring that we can continue to provide our services without tracking you.</p>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Why use Spacum instead of Google?</h3>
                        <span class="arrow">&#9660;</span>
                    </div>
                    <p class="answer">Spacum offers better privacy protection compared to Google, as we do not track your searches or browsing activities.</p>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Is Incognito mode private?</h3>
                        <span class="arrow">&#9660;</span>
                    </div>
                    <p class="answer">Incognito mode in most browsers does not provide complete privacy, as it only prevents your browsing history from being saved locally. Spacum offers more comprehensive privacy protection.</p>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>How do Spacum Search results compare to Google's?</h3>
                        <span class="arrow">&#9660;</span>
                    </div>
                    <p class="answer">Spacum Search results are designed to be as relevant as Google's, but without tracking your searches or personal data.</p>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Is Spacum owned by Google or any other entity?</h3>
                        <span class="arrow">&#9660;</span>
                    </div>
                    <p class="answer">No, Spacum is an independent company and is not owned by Google or any other entity.</p>
                </div>
            </div>
        </div>
    </div>
</section>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const container = document.getElementById("main-container");
        const minimizeBtn = document.getElementById("minimize-btn");

        if (minimizeBtn && container) {
            minimizeBtn.addEventListener("click", function() {
                container.style.transition = "opacity 0.5s ease-out";
                container.style.opacity = "0";
                setTimeout(() => {
                    container.style.display = "none";
                }, 500);
            });
        }
    });

    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.answer');
        const arrow = item.querySelector('.arrow');

        question.addEventListener('click', () => {
            const isVisible = answer.style.display === 'block';
            // Hide all answers and reset arrows
            document.querySelectorAll('.answer').forEach(a => a.style.display = 'none');
            document.querySelectorAll('.arrow').forEach(a => a.innerHTML = '&#9660;');

            if (!isVisible) {
                answer.style.display = 'block';
                arrow.innerHTML = '&#9650;'; // Pointing up (arrow rotated)
            }
        });
    });

    function scrollToDownloadSection() {
        // Get the download section by its ID
        const downloadSection = document.getElementById("download-section");

        // Scroll to the section smoothly
        downloadSection.scrollIntoView({
            behavior: "smooth"
        });
    }
    // Function to set a default search engine and store it in localStorage
    function setAsDefaultSearch() {
        // Storing in localStorage to simulate setting the default search engine
        localStorage.setItem('defaultSearch', 'Spacum');

        // Providing feedback to the user
        alert("Spacum has been set as your default search engine!");

        // Update the status after setting the default search
        updateStatus();
    }

    // Function to update the status based on localStorage
    function updateStatus() {
        const statusElement = document.getElementById('status');

        // Check if a default search engine is set in localStorage
        if (localStorage.getItem('defaultSearch')) {
            statusElement.innerText = `Your default search engine is: ${localStorage.getItem('defaultSearch')}`;
        } else {
            statusElement.innerText = "No default search engine set yet.";
        }
    }

    // Call updateStatus when the page is loaded
    window.onload = updateStatus;
</script>


<style>
    .itag {
        margin-right: 1rem;
        margin-left: 1rem;
    }

    .bb {
        border-bottom: 1px solid rgb(186, 186, 186);
    }

    .spc i {
        font-size: 1.8rem;
    }

    .offline-download {
        text-align: center;
        padding: 0.6rem 1rem;
        border: 2px solid #ddd;
        border-radius: 1rem;
        font-size: 0.8rem;
        font-weight: bold;
        max-width: 360px;
        margin-right: 5px;

    }

    .offline-download a {
        text-decoration: none;
        color: #6c63ff;
        font-weight: bold;
    }

    .store-button-c {
        width: 160px;
        height: 50px;
        overflow: hidden;
        border-radius: 0.5rem;
    }

    .store-button-c img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: inherit;
    }

    .store-button-c:hover {
        transform: translateY(-2px);
    }

    @media (max-width: 992px) {

        .dow-now i {
            font-size: 0.5rem !important;
        }

        .dow-now {
            display: flex;
        }

        .btn-primary {
            width: 14rem !important;
            padding: 0.6rem !important;
            font-size: 1rem;
            white-space: nowrap;
            /* Prevent text from wrapping */
        }


        .list-group-item {
            flex-direction: column;
            text-align: center;
            padding: 1.2rem;
        }

        .list-group-item .d-flex {
            flex-direction: column;
            align-items: center;
            width: 100%;
            gap: 10px;
        }

        .offline-download {
            width: 100%;
            max-width: 360px;
            margin-bottom: 10px;
        }

        .store-button-c {
            display: inline-block;
            text-decoration: none;
            width: 180px;
            height: 50px;
            overflow: hidden;
            border-radius: 0.5rem;
        }

        .store-button-c img {
            width: 100% !important;
        }

        .spc i {
            font-size: 1.3rem;
        }

        .itag {
            margin-right: 0;
            margin-left: 0;
        }
    }

    /*
@media (max-width: 768px) {
    .dow-now i{
        font-size: 0.1rem;
    }
    h3 {
        font-size: 1.4rem;
        text-align: center;
    }

    .card {
        text-align: center;
        padding: 1.5rem;
    }

    .list-group-item i {
        font-size: 1.8rem;
        margin-bottom: 10px;
    }

    .offline-download {

        max-width: 300px;
        font-size: 13px;
    }

    .btn-primary {
        width: 100%;
        font-size: 1rem;
        padding: 0.8rem;
        white-space: nowrap;
    }

  

    .store-button-c {
        display: inline-block;
        text-decoration: none;
        width: 180px;
        height: auto;
        overflow: hidden;
        border-radius: 0.5rem;
    }

  
    .d-flex {
        flex-direction: column !important;
        align-items: center !important;
        text-align: center;
    }

    .text-nowrap {
        white-space: nowrap;
    }
}*/


    .privacy-hero-section {
        background:
            url('site/assets/img/flame.1241f020.png') center/cover no-repeat,
            linear-gradient(to bottom, white 10%, #FFD43F 100%);
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        color: black;
        text-align: center;
        border-bottom: none !important;
        /* Removes any border-bottom */
    }

    .hero-section {
        background-image: url('site/assets/img/homepage-btf-light.png');
        /* Add your background image */
        background-size: cover;
        /* Ensure the image covers the entire section */
        background-position: center;
        /* Center the background image */
        background-repeat: no-repeat;
        /* Prevent the image from repeating */
        padding: 60px 0;
        position: relative;
        overflow: hidden;
    }

    .hero-section {
        overflow: visible;
    }
</style>