 <!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Edification - Responsive Education HTML5 Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <!-- all css here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!--color css-->
    <link rel="stylesheet" id="triggerColor" href="assets/css/triggerplate/color-0.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- prealoader area end -->
    
    <!-- header area start -->

   <?php include('header.php');?>

    <!-- header area end -->
    <!-- offset search area start -->
    <div class="offset-search">
        <form action="#">
            <input type="text" name="search" placeholder="Sarch here...">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>
    </div>
    <!-- offset search area end -->
    <!-- body overlay area start -->
    <div class="body_overlay"></div>
    <!-- body overlay area end -->
    <!-- hero area start -->

    <?php
        include('db.php');
        $sql = "SELECT * FROM `home_banner` WHERE show_on_home=1 ";
        $result = $conn->query($sql);
        ?>
        <?php while($row = $result->fetch_assoc()){?>

    <div class="slider_item has-color" style="background: url(assets/images/bg/<?php echo $row['image'];?>) center/cover no-repeat;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1">
                    <div class="hero-content">
                   

                        <h1 class="mb-5"><span class="primary-color">Build your Successful</span><b class="line-break"></b><?php echo $row['title'];?></h1>
                        <p class="text-white-50"><?php echo $row['sub_title'];?></p>

                        <form method="POST">
                            <div class="form-input mt-5">
                                <input type="text" name="search" required placeholder="Enter your keyword...">
                                <button class="btn btn-primary btn-round" type="submit">Seacrh</button>
                                <i class="fa fa-search"></i>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php } ?>

   <!-- hero area end  -->

    <!-- course area start -->
    <div class="course-area  ptb--120" id="courses">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 black-title title-tb text-center">
                        <span>Build your career</span>
                        <h2 class="primary-color">Featured Courses</h2>
                    </div>
                </div>
            </div>
  
            <div class="commn-carousel owl-carousel card-deck"> 

            <?php
                include('db.php');
                $sql = "SELECT * FROM `courses` WHERE status=1 limit 3";
                $result = $conn->query($sql);
                ?>
                <?php while($row = $result->fetch_assoc()){?>

                <div class="card mb-5">
                    <div class="course-thumb">
                        <img src="assets/images/course/<?php echo $row['image'];?>" alt="image">
                        <span class="cs-price primary-bg">30% off</span>
                    </div>
                    <div class="card-body  p-25"> 
                        <div class="course-meta-title mb-4">
                            <div class="course-meta-text">
                                <h4><a href="courses-detail.php?id=<?php echo $row['id'];?>"><?php echo $row['name'];?></a></h4>
                
                            </div> 
                            
                        </div>
                        <p><?php echo $row['short_description'];?></p> 
                            <a href="courses-detail.php?id=<?php echo $row['id'];?>" class="btn btn-primary btn-round btn-sm"><?php echo $row['button'];?></a>
                  </div><!-- card-body -->
                </div><!-- card -->

                <?php } ?> 

            </div>
        </div>
    </div>
    <!-- course area end -->

    <!-- take toure area start -->
    <div class="take-toure-area ptb--120">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 white-title text-center">
                        <span>Take A Look</span>
                        <h2>Video Tour on Edification </h2>
                    </div>
                </div>
            </div>
            <div class="video-area">
                <a class="expand-video" href="https://www.youtube.com/watch?v=cdfMgotGKIM"><i class="fa fa-play"></i></a>
            </div>
        </div>
    </div>
    <!-- take toure area end -->

    <!-- course area start -->
    <div class="teacher-area pb--100" id="teachers">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 black-title title-tb text-center">
                        <span>Learn from the best</span>
                        <h2 class="primary-color">Our teachers</h2>
                    </div>
                </div>
            </div>
            <div class="commn-carousel owl-carousel card-deck"> 
                
            <?php
                include('db.php');
                $sql = "SELECT * FROM `teachers` WHERE status=1 ";
                $result = $conn->query($sql);
                ?>
                <?php while($row = $result->fetch_assoc()){?>

              <div class="card mb-5"> 
                <img src="assets/images/teacher/<?php echo $row['image'];?>" alt="image"> 
                <div class="card-body teacher-content p-25">  
                  <h4 class="card-title mb-4"><a href="teachers-detail.php?id=<?php echo $row['id'];?>"><?php echo $row['name'];?></a></h4>
                  <span class="primary-color d-block mb-4"><?php echo $row['course_name'];?></span>
                  <p class="card-text"><?php echo $row['short_description'];?></p>

                  <a href="teachers-detail.php?id=<?php echo $row['id'];?>" class="btn btn-primary btn-round btn-sm"><?php echo $row['button'];?></a>
                </div>
              </div><!-- card -->    

             <?php } ?>   
   
            </div>
        </div>
    </div>
    <!-- course area end -->

    <!-- events area start -->
    <div class="course-area  ptb--120" id="event">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 black-title title-tb text-center">
                        <span>Too Fresh Moments</span>
                        <h2 class="primary-color">Up Comming Events</h2>
                    </div>
                </div>
            </div>
  
            <div class="commn-carousel owl-carousel card-deck">
                
                            <?php
     							include('db.php');
     							$sql = "SELECT * FROM `events` WHERE status=1 ";
     							$result = $conn->query($sql);
     							?>
     							<?php while($row = $result->fetch_assoc()){?>

                    <div class="card mb-5">
                    <div class="course-thumb">
                        <img src="assets/images/blog/<?php echo $row['image'];?>" alt="image">
                    </div>
                    <div class="card-body  p-25"> 
                        <div class="course-meta-title mb-4">
                            <div class="course-meta-text">
                                <h4><a href="#"><?php echo $row['title'];?></a></h4>  
                            </div> 
                        </div>
                        <p><?php echo $row['sub_title'];?></p> 
                  </div><!-- card-body -->
                </div><!-- card -->
 
                  <?php } ?>
 
            </div> 
        </div>
    </div>
    <!-- events area end --> 
    
    <div class="testimonial-area ptb--120"><!-- testimonial area start -->
        <img class="tst-bg" src="assets/images/bg/tst-bg-shape.png" alt="image">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 text-center">
                    <div class="tst-carousel owl-carousel">
                        <div class="testimonial-content pb--40">
                            <div class="section-title sec-style-two">
                                <span class="text-uppercase primary-color mb-0">Happy students</span>
                                <h2>Testimonial</h2>
                            </div>
                            <h3>‘‘ Effective teachers possess a combination of skills, qualities, and characteristics that contribute to creating a positive and engaging learning environment. ‘‘</h3>
                            <h4>Muhammad Ahamad</h4>
                            <span>Application Designer</span>
                        </div>  
                        <div class="testimonial-content pb--40">
                            <div class="section-title sec-style-two">
                                <span class="text-uppercase primary-color mb-0">Happy students</span>
                                <h2>Testimonial</h2>
                            </div>
                            <h3>‘‘ Clear and articulate communication to convey ideas, instructions, and information in a way that students can understand. ‘‘</h3>
                            <h4>Ali Hassan</h4>
                            <span>Data structure</span>
                        </div>  
                        <div class="testimonial-content pb--40">
                            <div class="section-title sec-style-two">
                                <span class="text-uppercase primary-color mb-0">Happy students </span>
                                <h2>Testimonial</h2>
                            </div>
                            <h3>‘‘ Ability to adapt teaching methods to accommodate different learning styles and individual needs within the classroom. ‘‘</h3>
                            <h4>Tariq Ali</h4>
                            <span>Andriod App Developer</span>
                        </div> 
                    </div>
                </div><!-- row -->
            </div><!-- row -->
        </div><!-- container -->
    </div><!-- testimonial-area --> 

    <!-- blog area start -->
    <div class="feature-blog  ptb--120" id="blog">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 black-title title-tb text-center">
                        <span>Top stories</span>
                        <h2>Blog & News</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class=" card-deck">
                    
                <?php
                    include('db.php');
                    $sql = "SELECT * FROM `blog` WHERE status=1 ";
                    $result = $conn->query($sql);
                    ?>
                    <?php while($row = $result->fetch_assoc()){?>

                  <div class="card mb-5"> 
                    <img class="card-img-top" src="assets/images/blog/<?php echo $row['image'];?>" alt="image">
                    <div class="card-body p-25"> 
                        
                      <h4 class="card-title mb-4"><a href="blog-detail.php?id=<?php echo $row['id'];?>"><?php echo $row['name'];?></a></h4>
                      <p class="card-text"><?php echo $row['short_description'];?></p> 
                      <a class="btn btn-primary btn-round btn-sm" href="blog-detail.php?id=<?php echo $row['id'];?>"> <?php echo $row['button'];?> </a>
                    </div>
                  </div><!-- card -->                
                  
                  <?php } ?>
       
                </div><!-- blog-carousel -->
            </div><!-- blog-carousel -->

        </div>
    </div> <!-- blog area end -->

    <!-- cta area start -->
    <div class="cta-area secondary-bg has-color cta-area ptb--50 "> 
        <div class="container">
            <div class="row align-items-center" id="contact">
                <div class="col-md-9">
                    <div class="cta-content">
                        <p class="mb-2">Click to Join the Advance Workshop</p>
                        <h2>Training in advance networking</h2>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="cta-btn">
                        <a class="btn btn-light btn-round" href="#">Join Now</a>
                    </div>
                </div>
                </div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3366.770584432687!2d74.50127197549048!3d32.45207497380102!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391ec18f84590abf%3A0x2a90b0b1c7c521f5!2sThe%20EDIFICATION%20Academy!5e0!3m2!1sen!2s!4v1709831737014!5m2!1sen!2s" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
    <!-- cta area end -->
<br>
<br>
    <!-- footer area start -->
   
<?php include('footer.php');?>

    <!-- footer area end -->
 
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- others plugins -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>