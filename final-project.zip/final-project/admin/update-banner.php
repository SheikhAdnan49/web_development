<?php

include('db.php');
$id = $_GET['id'];

    $title = $_POST['title'];
    $sub_title = $_POST['sub_title'];
    $image = $_POST['image'];
    $show_on_home = $_POST['show_on_home'];

    $sql = "update `home_banner` set

        title = '" . $title . "',
        sub_title = '" . $sub_title . "',
        image = '" . $image . "',
        show_on_home = '" . $show_on_home . "' where id = $id";

    mysqli_query($conn, $sql);

    if($conn->query($sql) === TRUE){
        echo 'Record Updated succeccfully';
    }else{
        echo 'Error in updating Record';
    }
    header('location: view-all-banners.php');
    
    ?>