<?php

include('db.php');
if(isset($_POST['submit'])) {

$name = $_POST['name'];
$short_description = $_POST['short_description'];
$long_description = $_POST['long_description'];
$button = $_POST['button'];
$button_link = $_POST['button_link'];
$image = $_POST['image'];
$course_name = $_POST['course_name'];
$status = $_POST['status'];

$query = mysqli_query($conn, "insert into teachers (name, short_description, long_description, button, button_link,  image, course_name, status) value('$name', '$short_description', '$long_description', '$button', '$button_link', '$image', '$course_name', '$status')");

if ($query) {

echo "<script> alert('Teacher Created Successfully'); </script>";
} else {
echo "<script> alert('Error in Creating Teacher'); </script>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Gradient Able bootstrap admin template by codedthemes </title>
    <!-- HTML5 Shim and Respond.js IE9 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="description" content="Gradient Able Bootstrap admin template made using Bootstrap 4. The starter version of Gradient Able is completely free for personal project." />
    <meta name="keywords"
    content=", Flat ui, Admin , Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
    <meta name="author" content="codedthemes">
    <!-- Favicon icon -->
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
    <!-- Google font--><link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap/css/bootstrap.min.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
	<link rel="stylesheet" type="text/css" href="assets/icon/font-awesome/css/font-awesome.min.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/jquery.mCustomScrollbar.css">
</head>

<body>
	 
       <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <!-- Pre-loader end -->

    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

           <!-- header start -->

  <?php include('header.php');?>

        <!-- header end -->

        <hr>

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                    <!-- sidebar start -->

    <?php include('sidebar.php');?>

        <!-- sidebar end -->
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">

                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
									<!-- Page-header start -->
                                    <div class="page-header card">
                                        <div class="card-block">
                                            <h5 class="m-b-10">Add New Teacher</h5>
                                            
                                            <ul class="breadcrumb-title b-t-default p-t-10">
                                                <li class="breadcrumb-item">
                                                    <a href="dashboard.php">Dashboard</a>
                                                </li>
                                                        <li class="breadcrumb-item"><a href="#!">Add New Teacher</a>
                                                        </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Page-header end -->
                                    
                                    <!-- Page body start -->
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Basic Form Inputs card start -->
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Add New Teacher</h5>
                                                      
                                                        </div>
                                                        <div class="card-block">
                                                            
                                                        <form method="POST">
                                                            <div class="col-sm-12">
                                                                <div class="form-group row">
                                                                    <label class="form-label" for="name"> Name:</label>
                                                                        <input type="text" name="name" class="form-control" id="name">
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-12">
                                                                <div class="form-group row">
                                                                    <label class="form-label" for="short_description">Short_description:</label>
                                                                        <input type="text" name="short_description" class="form-control" id="short_description">
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-12">
                                                                <div class="form-group row">
                                                                    <label class="form-label" for="long_description">Long_description:</label>
                                                                        <input type="text" name="long_description" class="form-control" id="long_description">
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-12">
                                                                <div class="form-group row">
                                                                    <label class="form-label" for="button">Button:</label>
                                                                        <input type="text" name="button" class="form-control" id="button">
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-12">
                                                                <div class="form-group row">
                                                                    <label class="form-label" for="button_link">Button_link:</label>
                                                                        <input type="text" name="button_link" class="form-control" id="button_link">
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-12">
                                                                <div class="form-group row">
                                                                    <label class="form-label" for="image">Image:</label>
                                                                        <input type="text" name="image" class="form-control" id="image">
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-12">
                                                                <div class="form-group row">
                                                                    <label class="form-label" for="course_name">Course_name:</label>
                                                                        <input type="text" name="course_name" class="form-control" id="course_name">
                                                                    </div>
                                                                </div>


                                                                <div class="col-sm-12">
                                                                <div class="form-group row">
                                                                    <label class="form-label" for="status">Status:</label>
                                                                        <input type="text" name="status" class="form-control" id="status">
                                                                    </div>
                                                                </div>

                                                                <div class="form-group row">
                                                                    <div class="col-lg-8 ml-auto">
                                                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                                                    </div>
                                                                </div>

                                                            </div>                 
                                                        </form>
                                                                        
                                                                    </div>
                                                                </div>
                                                                <!-- Basic Form Inputs card end -->
                                                               
                                                                <!-- Main-body end -->
                                                                <div id="styleSelector">

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


 
<!-- Required Jquery -->
<script type="text/javascript" src="assets/js/jquery/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="assets/js/popper.js/popper.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap/js/bootstrap.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="assets/js/jquery-slimscroll/jquery.slimscroll.js"></script>
<!-- modernizr js -->
<script type="text/javascript" src="assets/js/modernizr/modernizr.js"></script>
<script type="text/javascript" src="assets/js/modernizr/css-scrollbars.js"></script>

<!-- Custom js -->
<script type="text/javascript" src="assets/js/script.js"></script>
<script src="assets/js/pcoded.min.js"></script>
<script src="assets/js/vartical-demo.js"></script>
<script src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>

</body>

</html>
