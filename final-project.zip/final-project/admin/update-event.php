<?php

include('db.php');
$id = $_GET['id'];

    $title = $_POST['title'];
    $sub_title = $_POST['sub_title'];
    $image = $_POST['image'];
    $status = $_POST['status'];

    $sql = "update `events` set

        title = '" . $title . "',
        sub_title = '" . $sub_title . "',
        image = '" . $image . "',
        status = '" . $status . "' where id = $id";

    mysqli_query($conn, $sql);

    if($conn->query($sql) === TRUE){
        echo 'Record Updated succeccfully';
    }else{
        echo 'Error in updating Record';
    }
    header('location: view-all-events.php');
    
    ?> 