<?php

include('db.php');
$id = $_GET['id'];

    $name = $_POST['name'];
    $short_description = $_POST['short_description'];
    $long_description = $_POST['long_description'];
    $button = $_POST['button'];
    $image = $_POST['image'];
    $status = $_POST['status'];

    $sql = "update `blog` set

        name = '" . $name . "',
        short_description = '" . $short_description . "',
        long_description = '" . $long_description . "',
        button = '" . $button . "',
        image = '" . $image . "',
        status = '" . $status . "' where id = $id";

    mysqli_query($conn, $sql);

    if($conn->query($sql) === TRUE){
        echo 'Record Updated succeccfully';
    }else{
        echo 'Error in updating Record';
    }
    header('location: view-all-blogs.php');
    
    ?>