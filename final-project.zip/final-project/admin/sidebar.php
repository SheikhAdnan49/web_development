<nav class="pcoded-navbar">
                       
                        <div class="pcoded-inner-navbar main-menu">
                          <ul class="pcoded-item pcoded-left-item">
                                <li class="active">
                                    <a href="dashboard.php">
                                        <span class="pcoded-micon"><i class="ti-star"></i><b>D</b></span>
                                        <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>

                                <div class="pcoded-navigatio-lavel" data-i18n="nav.category.forms"></div>

                                <li class="pcoded-hasmenu">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-home"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Banner settings</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class=" ">
                                            <a href="create-banner.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Create new banner</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" ">
                                            <a href="view-all-banners.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">View all banners</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        </ul>
                                

                                        <div class="pcoded-navigatio-lavel" data-i18n="nav.category.forms"></div>

                                        <li class="pcoded-hasmenu">
                                        <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-book"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">courses settings</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class=" ">
                                            <a href="add-course.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Add new course</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" ">
                                            <a href="view-all-courses.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">View all courses</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                    </ul>

                                    <div class="pcoded-navigatio-lavel" data-i18n="nav.category.forms"></div>

                                        <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)">
                                            <span class="pcoded-micon"><i class="ti-user"></i></span>
                                            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Teachers settings</span>
                                            <span class="pcoded-mcaret"></span>
                                            </a>
                                            <ul class="pcoded-submenu">
                                            <li class=" ">
                                                <a href="add-teacher.php">
                                                    <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                    <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Add new teacher</span>
                                                    <span class="pcoded-mcaret"></span>
                                                </a>
                                            </li>
                                            <li class=" ">
                                                <a href="view-all-teachers.php">
                                                    <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                    <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">View all teachers</span>
                                                    <span class="pcoded-mcaret"></span>
                                                </a>
                                            </li>
                                            </ul>

                                            <div class="pcoded-navigatio-lavel" data-i18n="nav.category.forms"></div>

                                        <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)">
                                            <span class="pcoded-micon"><i class="ti-heart"></i></span>
                                            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Events settings</span>
                                            <span class="pcoded-mcaret"></span>
                                            </a>
                                            <ul class="pcoded-submenu">
                                            <li class=" ">
                                                <a href="add-event.php">
                                                    <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                    <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Add new event</span>
                                                    <span class="pcoded-mcaret"></span>
                                                </a>
                                            </li>
                                            <li class=" ">
                                                <a href="view-all-events.php">
                                                    <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                    <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">View all events</span>
                                                    <span class="pcoded-mcaret"></span>
                                                </a>
                                            </li>
                                            </ul>

                                            <div class="pcoded-navigatio-lavel" data-i18n="nav.category.forms"></div>

                                        <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)">
                                            <span class="pcoded-micon"><i class="ti-eye"></i></span>
                                            <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Blogs settings</span>
                                            <span class="pcoded-mcaret"></span>
                                            </a>
                                            <ul class="pcoded-submenu">
                                            <li class=" ">
                                                <a href="create-new-blog.php">
                                                    <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                    <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Add new blog</span>
                                                    <span class="pcoded-mcaret"></span>
                                                </a>
                                            </li>
                                            <li class=" ">
                                                <a href="view-all-blogs.php">
                                                    <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                    <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">View all blogs</span>
                                                    <span class="pcoded-mcaret"></span>
                                                </a>
                                            </li>
                                            </ul>

                                        </div>
                                    </nav>