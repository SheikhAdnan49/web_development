<?php

     include('db.php');

     $query = "SELECT * FROM `courses` ORDER BY id DESC";
     $result = mysqli_query($conn, $query);

     ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Gradient Able bootstrap admin template by codedthemes </title>
    <!-- HTML5 Shim and Respond.js IE9 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <!-- Meta -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="description" content="Gradient Able Bootstrap admin template made using Bootstrap 4. The starter version of Gradient Able is completely free for personal project." />
      <meta name="keywords" content="free dashboard template, free admin, free bootstrap template, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
      <meta name="author" content="codedthemes">
      <!-- Favicon icon -->
      <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
      <!-- Google font--><link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600" rel="stylesheet">
      <!-- Required Fremwork -->
      <link rel="stylesheet" type="text/css" href="assets/css/bootstrap/css/bootstrap.min.css">
      <!-- themify-icons line icon -->
      <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
	  <link rel="stylesheet" type="text/css" href="assets/icon/font-awesome/css/font-awesome.min.css">
      <!-- ico font -->
      <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
      <!-- Style.css -->
      <link rel="stylesheet" type="text/css" href="assets/css/style.css">
      <link rel="stylesheet" type="text/css" href="assets/css/jquery.mCustomScrollbar.css">
  </head>

  <body>
  	  
        <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

            <!-- header start -->

  <?php include('header.php');?>

        <!-- header end -->
<hr>
            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                    
                    <!-- sidebar start -->

                    <?php include('sidebar.php');?>

                    <!-- sidebar end -->

                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
									<!-- Page-header start -->
                                    <div class="page-header card">
                                        <div class="card-block">
                                            <h5 class="m-b-10">View all Courses</h5>
                                           
                                            <ul class="breadcrumb-title b-t-default p-t-10">
                                                <li class="breadcrumb-item">
                                                    <a href="dashboard.php"> Dashboard</a>
                                                </li>
                                               
                                                        </li>
                                                        <li class="breadcrumb-item">View all Courses </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Page-header end -->
                                    
                                <!-- Page-body start -->
                                <div class="page-body">
                                  
                                    <!-- Contextual classes table starts -->
                                    <div class="card">
                                        <div class="card-header">
                                            <h4>View all Courses</h4>
                                            
                                        </div>
                                        <div class="card-block table-border-style">
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr class="table-active">
                                                            <th>Sr</th>
                                                            <th>Image</th>
                                                            <th>Course Name</th>
                                                            <th>Short description</th>
                                                            <th>Long description</th>
                                                            <th>Button</th>
                                                            <th>Button link</th>
                                                            <th>Trainer</th>
                                                            <th>Seats</th>
                                                            <th>Fees</th> 
                                                            <th>Duration</th>              
                                                            <th>Status</th>
                                                            <th>Edit</th>
                                                            <th>Delete</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php
                                                        if(mysqli_num_rows($result)>0){
                                                        $sn = 1;
                                                        while($data = mysqli_fetch_assoc($result)){
                                                        ?>

                                                        <tr>
                                                            <td><?php echo $sn;?></td>
                                                            <td><img src="../assets/images/course/<?php echo $data['image'];?>" width="60px" height="40px"></td>
                                                            <td><?php echo $data['name'];?></td>
                                                            <td><?php echo $data['short_description'];?></td>
                                                            <td><?php echo $data['long_description'];?></td>
                                                            <td><?php echo $data['button'];?></td>
                                                            <td><?php echo $data['button_link'];?></td>
                                                            <td><?php echo $data['trainer'];?></td>
                                                            <td><?php echo $data['seats'];?></td>
                                                            <td><?php echo $data['fees'];?></td>
                                                            <td><?php echo $data['duration'];?></td>
                                                            <td><?php echo $data['status'];?></td>
                                                            <th><a href="edit-course.php?id=<?php echo $data['id'];?>" class="btn btn-warning btn-sm">Edit</a></th>
                                                            <th><a href="delete-course.php?id=<?php echo $data['id'];?>" class="btn btn-danger btn-sm">Delete</a></th>
                                                            </tr>
                                                            <tr>

                                                            <?php
                                                            $sn++;}} else {?>
                                                            <tr>
                                                            <td>No Data Found...</td>
                                                            </tr>

                                                            <?php } ?>
                                                            </tr>
                                                        
                                                        
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Contextual classes table ends -->
                                    
                                </div>
                                <!-- Page-body end -->
                            </div>
                        </div>
                        <!-- Main-body end -->

                        <div id="styleSelector">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<!-- Required Jquery -->
<script type="text/javascript" src="assets/js/jquery/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="assets/js/popper.js/popper.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap/js/bootstrap.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="assets/js/jquery-slimscroll/jquery.slimscroll.js"></script>
<!-- modernizr js -->
<script type="text/javascript" src="assets/js/modernizr/modernizr.js"></script>
<script type="text/javascript" src="assets/js/modernizr/css-scrollbars.js"></script>

<!-- Custom js -->
<script type="text/javascript" src="assets/js/script.js"></script>
<script src="assets/js/pcoded.min.js"></script>
<script src="assets/js/vartical-demo.js"></script>
<script src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
</body>

</html>
