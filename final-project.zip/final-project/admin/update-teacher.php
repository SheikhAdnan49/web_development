<?php

include('db.php');
$id = $_GET['id'];

    $name = $_POST['name'];
    $short_description = $_POST['short_description'];
    $long_description = $_POST['long_description'];
    $button = $_POST['button'];
    $button_link = $_POST['button_link'];
    $image = $_POST['image'];
    $course_name = $_POST['course_name'];
    $status = $_POST['status'];

    $sql = "update `teachers` set

        name = '" . $name . "',
        short_description = '" . $short_description . "',
        long_description = '" . $long_description . "',
        button = '" . $button . "',
        button_link = '" . $button_link . "',
        image = '" . $image . "',
        course_name = '" . $course_name . "',
        status = '" . $status . "' where id = $id";

    mysqli_query($conn, $sql);

    if($conn->query($sql) === TRUE){
        echo 'Record Updated succeccfully';
    }else{
        echo 'Error in updating Record';
    }
    header('location: view-all-teachers.php');
    
    ?>