<?php

include('db.php');
$id = $_GET['id'];

$sql = "DELETE FROM `teachers` WHERE id = $id";
mysqli_query($conn,$sql);

if($conn->query($sql) === TRUE){
    echo "Record Deleted Successfully";
}else{
    echo "Error in Deleting Record";
}
header('location: view-all-teschers.php');

?>