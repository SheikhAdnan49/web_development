<?php

// array for JSON response
$response = array();


// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db
$db = new DB_CONNECT();

// get all products from products table
$result = mysql_query("SELECT *FROM blog") or die(mysql_error());

// check for empty result
if (mysql_num_rows($result) > 0) {
    // looping through all results
    // products node
    $response["blog"] = array();
    
    while ($row = mysql_fetch_array($result)) {
        // temp user array
        $blog = array();
        $blog["id"] = $row["id"];
        $blog["name"] = $row["name"];
        $blog["short_description"] = $row["short_description"];
        $blog["long_description"] = $row["long_description"];
        $blog["button"] = $row["button"];
        $blog["image"] = $row["image"];
        $blog["status"] = $row["status"];


        // push single product into final response array
        array_push($response["blog"], $blog);
    }
    // success
    $response["success"] = 1;

    // echoing JSON response
    echo json_encode($response);
} else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "No blog found";

    // echo no users JSON
    echo json_encode($response);
}
?>
