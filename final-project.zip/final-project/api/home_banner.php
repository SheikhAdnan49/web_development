<?php

// array for JSON response
$response = array();


// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db
$db = new DB_CONNECT();

// get all products from products table
$result = mysql_query("SELECT *FROM home_banner") or die(mysql_error());

// check for empty result
if (mysql_num_rows($result) > 0) {
    // looping through all results
    // products node
    $response["home_banner"] = array();
    
    while ($row = mysql_fetch_array($result)) {
        // temp user array
        $home_banner = array();
        $home_banner["id"] = $row["id"];
        $home_banner["title"] = $row["title"];
        $home_banner["sub_title"] = $row["sub_title"];
        $home_banner["image"] = $row["image"];
        $home_banner["show_on_home"] = $row["show_on_home"];


        // push single product into final response array
        array_push($response["home_banner"], $home_banner);
    }
    // success
    $response["success"] = 1;

    // echoing JSON response
    echo json_encode($response);
} else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "No banner found";

    // echo no users JSON
    echo json_encode($response);
}
?>
