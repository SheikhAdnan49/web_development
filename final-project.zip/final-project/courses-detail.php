<?php
    include('db.php');
    $sql = "SELECT * FROM `courses` WHERE id = ".$_GET['id'];
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);

if(!$result){
    echo 'Unable to get Data' . mysqli_error();
    exit;
}
 ?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Edification - Responsive Education HTML5 Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <!-- all css here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!--color css-->
    <link rel="stylesheet" id="triggerColor" href="assets/css/triggerplate/color-0.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- prealoader area end -->
    <!-- header area start -->
    
    <?php include('header.php');?>

    <!-- header area end -->
    <!-- offset search area start -->
    <div class="offset-search">
        <form action="#">
            <input type="text" name="search" placeholder="Sarch here...">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>
    </div>
    <!-- offset search area end -->
    <!-- body overlay area start -->
    <div class="body_overlay"></div>
    <!-- body overlay area end -->
    <!-- crumbs area start -->
    <div class="crumbs-area">
        <div class="container">
            <div class="crumb-content">
                <h4><span>Know About </span><?php echo $data['name']; ?>
                <?php $row = mysqli_fetch_row($result);
                 echo $row[1]; ?></h4>
            </div>
        </div>
    </div>
    <!-- crumbs area end -->
    <!-- course area start -->
    <div class="course-area ptb--120">
        <div class="container">
            <div class="row">
                <!-- course details start -->
                <div class="col-lg-8 col-md-8">
                    <div class="course-details">
                        <div class="cs-thumb mb-5">
                            <img src="assets/images/course/<?php echo $data['image']; ?>
                            <?php $row = mysqli_fetch_row($result);
                            echo $row[1]; ?>" alt="image">
                            <span class="cs-price">30% off</span>
                            <div class="csd-hv-info has-color align-items-center">
                                <div class="course-dt-info">
                                <ul class="course-meta-details list-inline  w-100">
                                   
                                    <li>
                                         <p>Trainer name</p>
                                          <span><?php echo $data['trainer']; ?>
                                        <?php $row = mysqli_fetch_row($result);
                                        echo $row[1]; ?></span>
                                    </li> 
                                    <li> 
                                         <p>Fees</p>
                                         <span><?php echo $data['fees']; ?>
                                        <?php $row = mysqli_fetch_row($result);
                                        echo $row[1]; ?></span>
                                    </li>
                                    <li>
                                         <p>Seats</p>
                                          <span><?php echo $data['seats']; ?>
                                        <?php $row = mysqli_fetch_row($result);
                                        echo $row[1]; ?></span>
                                    </li> 
                                    <li>
                                         <p>Duration</p>
                                          <span><?php echo $data['duration']; ?>
                                        <?php $row = mysqli_fetch_row($result);
                                        echo $row[1]; ?></span>
                                    </li>      
                                    </ul>  
                                </div>
                            </div>
                        </div>
                        <div class="cs-content"> 
                            <h3 class="mb-4"><?php echo $data['short_description']; ?>
                            <?php $row = mysqli_fetch_row($result);
                            echo $row[1]; ?></h3> 
                            <p><?php echo $data['long_description']; ?>
                                <?php $row = mysqli_fetch_row($result);
                                echo $row[1]; ?></p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- course area end -->

    

    <!-- footer area start -->
    
<?php include('footer.php');?>

    <!-- footer area end -->
 
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- others plugins -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>