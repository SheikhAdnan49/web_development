-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2024 at 05:35 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `final-project`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
`id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `para` text NOT NULL,
  `video_link` varchar(255) NOT NULL,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `title`, `para`, `video_link`, `status`) VALUES
(1, 'Welcome to ', 'In the bustling landscape of education, the Institute of Tomorrow stands as a beacon of learning and innovation, offering a transformative journey for students seeking to shape the future. Nestled amidst verdant surroundings, this esteemed institution is not merely a place of academia but a vibrant community where ideas flourish and dreams take flight.\r\n\r\nAt the heart of the Institute''s mission lies a commitment to excellence, fostering intellectual curiosity, critical thinking, and creative expression. Through a dynamic curriculum curated by seasoned educators and industry experts, students are empowered to embark on a journey of discovery, exploring diverse fields of study that transcend traditional boundaries.\r\n\r\nThe Institute''s state-of-the-art facilities provide a nurturing environment for holistic development, blending cutting-edge technology with timeless wisdom. From modern lecture halls equipped with interactive multimedia tools to sprawling libraries housing a wealth of knowledge, every corner of the campus serves as a canvas for intellectual exploration.', 'https://www.youtube.com/watch?v=cdfMgotGKIM', '1');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `short_description` varchar(255) NOT NULL,
  `long_description` text NOT NULL,
  `button` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `name`, `short_description`, `long_description`, `button`, `image`, `status`) VALUES
(1, ' A Nature Enchantment.', 'Nature, with its boundless beauty and intricate design, offers a sanctuary for the soul, a refuge from the hurried pace of modern life. ', 'In the early hours of dawn, the sun casts its gentle glow upon the landscape, unveiling a canvas painted in hues of soft pinks and warm oranges. The air is crisp, carrying the earthy fragrance of dew-kissed grass and the promise of a new day.\r\n\r\nAs the day unfolds, the rustle of leaves in the trees becomes a soothing melody, accompanied by the intermittent chatter of birds engaged in lively conversations. Each tree, a testament to resilience, stands tall, branches outstretched like reaching arms, providing shade and shelter to the creatures below.\r\n\r\nNature''s palette evolves with the passing hours, transitioning from the vibrant hues of daylight to the muted tones of dusk. The setting sun paints the sky with fiery reds and purples, casting a golden glow on the landscape. Night emerges, and the stars twinkle overhead, like diamonds scattered across a velvet canvas.', 'Read More', 'nature.jpg', '1'),
(2, 'A Harmony of Fragrance and Hue.', 'Beyond their visual allure, flowers bear the profound ability to evoke emotions. A single bloom can be a token of love.', 'In the delicate petals of a flower, nature unfolds a masterpiece that captivates hearts and transcends language. From the vibrant hues of a tulip to the gentle elegance of a rose, each bloom tells a story of life, growth, and the ever-renewing cycle of beauty.\r\n\r\nAs the morning sun kisses the earth, flowers awaken, their petals unfurling to greet the day. Each bloom carries a unique identity, a signature fragrance that lingers in the air and beckons bees and butterflies to partake in nature''s intricate dance.\r\n\r\nThe garden becomes a canvas painted with strokes of nature''s brilliance, as daffodils stand tall like rays of sunshine, while delicate cherry blossoms create a fleeting spectacle, reminiscent of a delicate pink snowfall. In the quiet corners, wildflowers dance in the breeze, adding a touch of spontaneity to the orchestrated symphony of colors.', 'Read More', 'flower.jpg', '1'),
(3, ' A Journey into Creative Expression.', 'Nature, with its boundless beauty and intricate design, offers a sanctuary for the soul, a refuge from the hurried pace of modern life.', 'In the early hours of dawn, the sun casts its gentle glow upon the landscape, unveiling a canvas painted in hues of soft pinks and warm oranges. The air is crisp, carrying the earthy fragrance of dew-kissed grass and the promise of a new day.\r\n\r\nAs the day unfolds, the rustle of leaves in the trees becomes a soothing melody, accompanied by the intermittent chatter of birds engaged in lively conversations. Each tree, a testament to resilience, stands tall, branches outstretched like reaching arms, providing shade and shelter to the creatures below.\r\n\r\nNature''s palette evolves with the passing hours, transitioning from the vibrant hues of daylight to the muted tones of dusk. The setting sun paints the sky with fiery reds and purples, casting a golden glow on the landscape. Night emerges, and the stars twinkle overhead, like diamonds scattered across a velvet canvas.', 'Read More', 'arts.jpg', '1'),
(4, 'Navigating the Night''s Silver Glow.', 'As the sun descends below the horizon, the moon emerges as the silent guardian of the night, casting its ethereal glow.', 'The moon, with its ever-changing phases, orchestrates a celestial ballet, a dance between light and shadow. During the waxing crescent, it appears as a delicate sliver, a silver thread in the tapestry of the night. As it waxes to full brilliance, the full moon unveils its captivating face, casting its gentle radiance upon the Earth below.\r\n\r\nBeneath the moon''s tranquil gaze, nocturnal creatures stir, and the landscape takes on a magical quality. Shadows elongate, and familiar surroundings acquire an enchanting allure, inviting us to explore the mysteries concealed in the lunar glow.\r\n\r\nOn cloudless nights, stars gather around the moon like celestial companions, forming constellations that have inspired myths and stories throughout human history. The moon, a silent witness to the passing of ages, carries the echoes of countless tales and the aspirations of poets and dreamers.', 'Read More', 'moon.jpg', '1'),
(6, 'new update', 'The health benefits of strawberries are plentiful. ', 'Apples are touted for their health benefits, containing plant chemicals like flavonoids and fiber, which can aid digestion, control symptoms of acid reflux, and promote heart health. Antioxidants in apples may slow cancer cell growth, protect against type 2 diabetes, and support lung, heart, and immune system health. ', 'Read More ', 'certificate.png', '0');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `short_description` varchar(255) NOT NULL,
  `long_description` text NOT NULL,
  `button` varchar(255) NOT NULL,
  `button_link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `trainer` varchar(255) NOT NULL,
  `seats` varchar(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`, `short_description`, `long_description`, `button`, `button_link`, `image`, `trainer`, `seats`, `fees`, `duration`, `status`) VALUES
(1, 'Application Design Course.', 'Application design courses are essential for individuals aspiring to become skilled and proficient in creating user-friendly and visually appealing software <b>applications</b>.', 'Understanding fundamental design principles such as balance, contrast, alignment, and proximity.\r\nExploring the importance of visual hierarchy in user interfaces.\r\nStudying the user-centered design process.\r\nConducting user research, creating user personas, and mapping user journeys.\r\nWireframing and prototyping techniques to design intuitive and efficient user experiences.\r\nLearning about color theory, typography, and iconography.\r\nCreating visually appealing and consistent user interfaces.\r\nImplementing responsive design for various devices and screen sizes.\r\nUnderstanding how users interact with applications.\r\nImplementing effective navigation and feedback systems.\r\nExploring micro-interactions and animations for a seamless user experience.', 'Read More', 'courses-detail.php', '1.jpg', 'Muhammad Ahmad', '20 ', '25,000', '2.5 months', '1'),
(2, 'Data structure Development', 'Data structures are fundamental concepts in computer science that organize and store data in a way that facilitates efficient retrieval and manipulation.', 'Data structures are fundamental concepts in computer science that organize and store data in a way that facilitates efficient retrieval and manipulation. Understanding various data structures is crucial for designing and implementing algorithms and solving complex computational problems.Understanding data structures is crucial for software development, as the choice of an appropriate data structure can significantly impact the efficiency and performance of algorithms. Mastery of these concepts empowers programmers to design robust and scalable solutions to computational problems.These courses often blend theoretical knowledge with practical, hands-on projects to ensure that students gain a comprehensive understanding of application design. Additionally, they may be offered through online platforms, universities, or specialized design schools.', 'Read More', 'courses-detail.php', '2.jpg', 'Ali Hassan', '25 ', '40,000', '3 months', '1'),
(3, 'Andriod App Development', 'Android app development is a dynamic and rewarding field, offering opportunities to create innovative and impactful applications for a diverse user base. ', 'Android app development is a dynamic and rewarding field, offering opportunities to create innovative and impactful applications for a diverse user base. Developers often collaborate with a broad range of technologies and frameworks to build feature-rich and high-performance Android apps.Android app development is the process of creating mobile applications for devices running the Android operating system. As one of the most popular mobile platforms, Android offers a vast user base and opportunities for developers.The Android platform supports a wide range of devices, including smartphones, tablets, smart TVs, and wearables.', 'Read More', 'courses-detail.php', '3.jpg', 'Tariq Ali', ' 15', ' 20,000', '2 months', '1'),
(5, 'fast food', 'The health benefits of strawberries are plentiful.', 'Breaking News: This category includes the latest and most urgent news stories. Breaking news often covers events that are currently unfolding and require immediate attention.  Politics: News related to government activities, elections, policy changes, and international relations. ', 'Apply now', 'http://google.com   ', '1.jpg ', 'Ali zaman ', '12', '25,000', '3 months ', '0');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
`id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `sub_title`, `image`, `status`) VALUES
(1, ' Academic Excellence Awards Ceremony', 'The Academic Excellence Awards Ceremony is a prestigious event that honors and celebrates the outstanding achievements of students who have demonstrated exceptional dedication, perseverance, and scholarly excellence throughout their academic journey.', 'award.jpg', '1'),
(2, ' The Student Projects Exhibition', 'The Student Projects Exhibition is an eagerly anticipated event that showcases the innovative and imaginative work of students across various disciplines. It serves as a platform for budding scholars, creators, and innovators to present their projects.', 'exhibition.jpg', '1'),
(3, 'Exploring Frontiers of Knowledge', 'Exploring Frontiers of Knowledge is a captivating endeavor that takes us on a journey into the uncharted territories of human understanding, pushing the boundaries of what we know and delving into the mysteries that lie beyond.', 'knowledge.jpg', '1'),
(4, ' Exploring Frontiers of Knowledge', 'Get rewarded for your travels - unlock instant savings of 10% or more with a free Geairinfo.com account ', 'blog-details.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `home_banner`
--

CREATE TABLE IF NOT EXISTS `home_banner` (
`id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `show_on_home` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home_banner`
--

INSERT INTO `home_banner` (`id`, `title`, `sub_title`, `image`, `show_on_home`) VALUES
(1, 'Future with Edification', 'Find Your Preferred Courses & Improve Your Skills', '1.jpg', '0'),
(2, 'Today for tomorrow', 'Capturing the Essence of the Outdoors.', '6.jpg', '1'),
(3, 'Build your Successful', 'Find Your Preferred Courses & Improve Your Skills  Enter your keyword...', '1.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `navbar`
--

CREATE TABLE IF NOT EXISTS `navbar` (
`id` int(11) NOT NULL,
  `nav_items` varchar(255) NOT NULL,
  `nav_link` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `navbar`
--

INSERT INTO `navbar` (`id`, `nav_items`, `nav_link`) VALUES
(1, 'home', 'index.php'),
(2, 'about us', 'about.php'),
(3, 'courses', '#courses'),
(4, 'blog', '#blog'),
(6, 'Teachers', '#teachers'),
(7, 'events', '#event'),
(8, 'contact us', '#contact');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `button` varchar(255) NOT NULL,
  `button_link` varchar(255) NOT NULL,
  `long_description` text NOT NULL,
  `short_description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `name`, `course_name`, `button`, `button_link`, `long_description`, `short_description`, `image`, `status`) VALUES
(1, 'Muhammad Ahmad', 'Application design Course', 'Read More', 'teachers-detail.php', 'Passion for Teaching:\r\n\r\nEnthusiasm and genuine love for the subject matter and the act of teaching itself.\r\n\r\nEffective Communication:\r\n\r\nClear and articulate communication to convey ideas, instructions, and information in a way that students can understand.\r\n\r\nAdaptability:\r\n\r\nAbility to adapt teaching methods to accommodate different learning styles and individual needs within the classroom.', 'Effective teachers possess a combination of skills, qualities, and characteristics that contribute to creating a positive.', 'img 2.jpg', '1'),
(2, 'Ali Hassan', 'Data structure', 'Read More', 'teachers-detail.php', 'Patience:\r\n\r\nTolerance and understanding when dealing with challenges or repeated questions, recognizing that each student learns at their own pace.\r\n\r\nEmpathy:\r\n\r\nThe capacity to understand and share the feelings of students, creating a supportive and inclusive classroom environment.\r\n\r\nOrganizational Skills:\r\n\r\nEffective planning and organization of lessons, materials, and classroom activities to maximize learning opportunities.', 'Clear and articulate communication to convey ideas, instructions, and information in a way that students can understand.', 'img 3.jpg', '1'),
(3, 'Tariq Ali', 'Andriod App development', 'Read More', 'teachers-detail.php', 'Creativity:\r\n\r\nInnovative approaches to make learning engaging and memorable, incorporating creative activities and varied teaching methods.\r\n\r\nMotivational Skills:\r\n\r\nInspiring and encouraging students to strive for excellence, fostering a positive attitude towards learning.\r\nProblem-Solving Abilities:\r\n\r\nQuick thinking and adaptability to address unexpected challenges or disruptions in the classroom.\r\n\r\nRespect and Fairness:\r\n\r\nTreating all students with respect and fairness, fostering a sense of equality and inclusivity in the classroom.\r\n\r\nKnowledge of Subject Matter:\r\n\r\nA deep understanding of the subject being taught, along with a continuous commitment to staying informed about new developments in the field.', 'A deep understanding of the subject being taught, along with a continuous commitment to staying informed about new developments in the field.', 'img 12.jpg', '1'),
(6, 'Babar Muneeb ', 'data science  ', 'Read More  ', 'http://google.com   ', 'Breaking News: This category includes the latest and most urgent news stories. Breaking news often covers events that are currently unfolding and require immediate attention.  Politics: News related to government activities, elections, policy changes, and international relations. ', 'Flowers consist of a combination of vegetative organs  sepals that enclose and protect the developing flower, petals that attract pollinators, and reproductive organs that produce gametophytes, which in flowering plants produce gametes.', '1.jpg ', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_banner`
--
ALTER TABLE `home_banner`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navbar`
--
ALTER TABLE `navbar`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `home_banner`
--
ALTER TABLE `home_banner`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `navbar`
--
ALTER TABLE `navbar`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
